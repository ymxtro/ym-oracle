# Profit Guard (final-17c = v2.7.1 guard + smart layer)

Server-side. Admin console -> **Plan & risk** -> **Profit Guard**. **Everything is OFF by default.** No bot or manager reflash needed.

## What it does
1. **Lock profit.** Watches the master account's open trades every ~5 s. Only ever RAISES a stop toward profit, never loosens it. The stop always lives on Bybit, so if Render sleeps the trade keeps its last stop. Copy users get the same stop.
2. **Bank a slice (scale-out, optional, off).** Closes a small share at set R levels, always leaves a runner.
3. **Re-entry recorder.** Notes when a "pullback then resume" entry would have appeared after a winner closed. Never trades.
4. **Scorecard.** Each closed trade: best point, Bybit's real exit, how much it gave back, mode, slices.

Modes: **Off / Shadow / Live**, overall and per profile (fast, swing). Shadow records what it WOULD do and touches nothing. Anything that starts acting on real money asks for **Confirm**. The profile comes from the trade's own `eng` tag.

## Lock rule (R = distance from entry to the trade's ORIGINAL stop)
At 1R the stop moves to entry +0.1%. Then a ladder keeps a share of the best profit:

| | Breakeven | Step 1 | Step 2 | Step 3 |
|---|---|---|---|---|
| Fast | 1R | 1.5R keep 45% | 3R keep 60% | 6R keep 70% |
| Swing | 1R | 2R keep 35% | 4R keep 55% | 8R keep 65% |

Never closer to the price than 0.25%. A bot's looser stop is held at the guard's floor (on both the manager route and the web route).

## Smart mode (new in final-17c)
Each part has its own switch; with all of it off the plain rules above apply. They only make a stop tighter or later, never looser.

- **Breathing room.** The trade's own largest pullback from its best price is remembered. A stop is not raised closer to the price than that (x1.0, capped at 1.5R). It matters most for the first lock: a trade that already wobbled 12 points is not stopped at breakeven 10 points under the price; the stop goes 12 under the price instead (still tighter than before), and moves up as the price clears the wobble.
- **Stall tightening.** A trade in profit (past breakeven) that has made no new best for a quiet period (fast 30 min, swing 6 h) keeps +10 points more of its best profit per period, up to +20. A new best resets it.
- **Self-tuning.** From the scorecard of trades that ran **Live** (at least 20 that reached the first step), per profile:
  - they gave back more than 50% of their best profit on average -> suggests keeping 5 points more at every rung;
  - they gave back under 20% AND at least 10 re-entries after the guard exit show 60%+ winners averaging 0.5R+ -> suggests keeping 5 points less (the guard may be leaving too early);
  - otherwise no change. Always between 15% and 85%, rungs stay in order.
  - **Suggest only** (default): shows the suggestion with an Apply button (asks to Confirm if the profile is Live). **Apply automatically**: needs a Confirm to switch on, acts at most once per 10 new live trades, logs every change and sends an alert. **Off**: nothing.
  - Shadow trades are not used for tuning, because in Shadow the ladder never ran.

## Suggested rollout
1. Overall **Shadow**, all smart parts on, tuning on Suggest only. Let it watch real trades for a week or two. Read "Recent activity" and the scorecard.
2. Try it on a **demo** account first: confirm the stop really moves on Bybit with the relay's trailing stop also set (see below).
3. Fast: Live. Swing: Shadow a bit longer if you want a clean with/without comparison.
4. Leave Suggest only until you trust the numbers; consider Auto last.

## Safety
- Off by default; Shadow touches nothing real. Does nothing when the relay is not in live mode or trading is halted (the stop clamp itself still holds).
- Needs the bot's reported original stop and engine tag (from its `open` event) to measure R; without them it does nothing for that trade.
- Settings, each trade's best/floor/pullback/stall clock and the re-entry watches are saved, so a Render restart forgets nothing.
- The guard needs the server awake to keep ratcheting. In this build the manager's 10 s check-in keeps it awake; with the manager off, Render's free tier may sleep and the guard pauses (the last stop stays on Bybit).

## Open items to verify on demo before Live
- The relay sets Bybit's trailing stop when a trade opens. The guard then sets a hard stop-loss on the same position. Confirm on demo how Bybit treats both together.
- The guard does not take `tradeexec`'s per-symbol lock; a guard update could in theory land while a trade on that pair is opening.
- If the guard closes a trade at its stop while the bot still thinks it is open, the bot's own web ledger can differ from Bybit's real result; the bot's later close is answered "already closed".
