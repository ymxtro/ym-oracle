// END-TO-END PIPELINE CHECK: bot firmware text -> /api/trade request -> server trade execution (against a pretend Bybit) -> reply -> bot's verdict.
// The bot half is the REAL code: the RELAY-HTTPS block is cut out of the fleet .ino files and compiled with g++. The server half is the
// REAL tradeexec.js. Only Bybit is pretend. Run:  node tests/pipeline.test.js   (needs g++ and node; no npm packages)
const fs = require('fs'), path = require('path'), assert = require('assert'), { execFileSync } = require('child_process');
const root = path.resolve(__dirname, '..');
const T = require(path.join(root, 'relay', 'tradeexec.js'));
const fleet = ['oracle1_lf_final16', 'oracle2_lf_final16', 'oracle3_lf_final16', 'oracle4_lf_final16'].map(n => path.join(root, 'fleet', n, n + '.ino'));
let n = 0; const ok = m => console.log('  ok', ++n, m);

// ---- build the bot-side tool from the shipped firmware text; all four bots must carry the identical block
const cut = f => { const s = fs.readFileSync(f, 'utf8').replace(/\r\n/g, '\n'); const a = s.indexOf('// ===== RELAY-HTTPS-BEGIN'), b = s.indexOf('// ===== RELAY-HTTPS-END ====='); assert(a > 0 && b > a, f + ': RELAY-HTTPS block missing'); return s.slice(a, b + '// ===== RELAY-HTTPS-END ====='.length); };
const blocks = fleet.map(cut);
assert(blocks.every(b => b === blocks[0]), 'the RELAY-HTTPS block differs between bots'); ok('all 4 bots carry the identical RELAY-HTTPS block');
const tmp = fs.mkdtempSync('/tmp/pipe-'); fs.writeFileSync(path.join(tmp, 'relay_https_block.h'), blocks[0]); fs.copyFileSync(path.join(__dirname, 'botside.cpp'), path.join(tmp, 'botside.cpp'));
execFileSync('g++', ['-std=c++14', '-Wall', '-o', path.join(tmp, 'botside'), path.join(tmp, 'botside.cpp')], { stdio: 'inherit' });
const bot = (...a) => execFileSync(path.join(tmp, 'botside'), a).toString().trim();

// ---- the server half with a pretend Bybit
function world(o) {
  o = Object.assign({ available: 1000, price: 100, qtyStep: 0.1, minQty: 0.1, minNotional: 5, maxLev: 50, mode: 'live' }, o || {});
  const w = { positions: {}, orders: [], stops: [], reports: [], o };
  const rest = {
    getWalletBalance: async () => ({ retCode: 0, result: { list: [{ totalAvailableBalance: String(o.available), coin: [{ coin: 'USDT' }] }] } }),
    getPositionInfo: async ({ symbol }) => { const p = w.positions[symbol]; return { retCode: 0, result: { list: p ? [{ symbol, side: p.side, size: p.size, markPrice: String(o.price) }] : [] } }; },
    getInstrumentsInfo: async () => ({ retCode: 0, result: { list: [{ status: 'Trading', lotSizeFilter: { qtyStep: String(o.qtyStep), minOrderQty: String(o.minQty), minNotionalValue: String(o.minNotional) }, leverageFilter: { maxLeverage: String(o.maxLev) } }] } }),
    getTickers: async () => ({ retCode: 0, result: { list: [{ lastPrice: String(o.price) }] } }),
    setLeverage: async () => ({ retCode: 0 }),
    setTradingStop: async b => { w.stops.push(b); return { retCode: 0 }; },
  };
  const ex = T.create({ rest: () => rest, mode: () => o.mode, halted: () => !!o.halted, sleep: () => Promise.resolve(),
    placeOrder: async b => { w.orders.push(b); if (o.mode === 'paper') return { paper: true, retCode: 0 }; if (b.reduceOnly) delete w.positions[b.symbol]; else w.positions[b.symbol] = { side: b.side, size: b.qty }; return { retCode: 0, result: {} }; },
    fanOutLeverage: () => {}, fanOutTradingStop: () => {}, report: r => w.reports.push(r) });
  w.send = async text => {                       // one full round trip, exactly as a bot's queued command would travel
    const json = bot('build', text); assert.notStrictEqual(json, 'REJECTED', 'bot refused to build: ' + text);
    const r = await ex.run(JSON.parse(json));    // = POST /api/trade
    return { json, http: r.http, body: JSON.stringify(r.body), verdict: bot('reply', String(r.http), JSON.stringify(r.body)) };
  };
  return w;
}
const TRADE = id => 'TRADEQ,' + id + ',BUY,SOLUSDT,20.00,5,110.000000,95.000000,104.000000,1.50';

(async () => {
  let w = world(), r = await w.send(TRADE('T0000000101'));
  assert.strictEqual(r.verdict, 'FINAL O OK'); assert.strictEqual(w.orders.length, 1); assert.strictEqual(w.orders[0].orderLinkId, 'ym-T0000000101'); assert.strictEqual(w.stops.length, 1);
  ok('open: bot command -> server places ONE order with orderLinkId ym-<id> + the trailing stop -> bot concludes FINAL O OK');
  assert(w.reports.length === 1 && w.reports[0].id === 'T0000000101' && w.reports[0].kind === 'TRADE' && w.reports[0].ok === true);
  ok('the dashboard report carries the SAME id the bot uses (so the trade-log row and the web ledger line up)');

  const again = await w.send(TRADE('T0000000101'));
  assert.strictEqual(again.verdict, 'FINAL O OK'); assert.strictEqual(w.orders.length, 1);
  ok('bot retransmits the same id (lost reply): same answer, still exactly ONE order');

  const held = await w.send('TRADEQ,T0000000102,SELL,SOLUSDT,20.00,5,90.0,105.0,0.000000,0.00');
  assert.strictEqual(held.verdict, 'FINAL F HELD'); assert.strictEqual(w.orders.length, 1);
  ok('second bot, same pair, different id: refused HELD, nothing sent to Bybit');

  w = world({ available: 15 });
  r = await w.send(TRADE('T0000000103')); assert.strictEqual(r.verdict, 'FINAL O SCALED'); ok('low balance: scaled down, bot sees FINAL O SCALED (7-char codes fit)');
  w = world({ available: 4 });
  r = await w.send(TRADE('T0000000104')); assert.strictEqual(r.verdict, 'FINAL F BAL'); assert.strictEqual(w.orders.length, 0); ok('balance under half of the request: FINAL F BAL, no order');
  w = world({ mode: 'paper' });
  r = await w.send(TRADE('T0000000105')); assert.strictEqual(r.verdict, 'FINAL O PAPER'); ok('paper mode: FINAL O PAPER');

  w = world(); await w.send(TRADE('T0000000106'));
  r = await w.send('SLTPQ,S000000001,BUY,SOLUSDT,97.5,112.0'); assert.strictEqual(r.verdict, 'FINAL O OK'); assert(w.stops.length >= 2); ok('stop/target update on the held position: FINAL O OK');
  r = await w.send('SLTPQ,S000000002,SELL,SOLUSDT,97.5,112.0'); assert.strictEqual(r.verdict, 'FINAL F SIDE'); ok('stop update for the wrong side: FINAL F SIDE (position left alone)');
  r = await w.send('CLOSEQ,C000000001,BUY,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL O OK'); assert(!w.positions.SOLUSDT); ok('close: position closed, FINAL O OK');
  r = await w.send('CLOSEQ,C000000002,BUY,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL O NOPOS'); ok('close when already flat: FINAL O NOPOS (not an error)');
  r = await w.send('SLTPQ,S000000003,BUY,SOLUSDT,97.5,112.0'); assert.strictEqual(r.verdict, 'FINAL F NOPOS');
  for (const f of fleet) assert(fs.readFileSync(f, 'utf8').includes('if (!ok && kind == \'S\' && strcmp(c, "NOPOS") == 0) ok = true;'), f + ': relayReport no longer treats a stop update on a vanished position as done');
  ok('stop update after the position is gone: server says F NOPOS and every bot\'s relayReport turns that into "done" (Bybit\'s own stop/target closed it first)');

  w = world({ halted: true });
  r = await w.send(TRADE('T0000000107')); assert.strictEqual(r.verdict, 'FINAL F HALT'); assert.strictEqual(w.orders.length, 0); ok('trading halted on the server: FINAL F HALT, no order');

  // transport-level answers the bot must NOT treat as final
  for (const [http, body, why] of [[500, '{"success":false,"error":"x"}', 'server error'], [502, '<html>bad gateway</html>', 'Render proxy page'], [503, '', 'Render waking up'], [401, '{"success":false}', 'wrong device key'], [429, '{}', 'rate limited'], [-1, '', 'timeout'], [-9999, '', 'no WiFi / low heap'], [200, '<html>cold start</html>', '200 but not our JSON']])
    assert.strictEqual(bot('reply', String(http), body), 'RETRY', why);
  ok('every transport failure (5xx, proxy page, 401, 429, timeout, no WiFi, non-JSON 200) means RETRY with the same id');
  assert.strictEqual(bot('reply', '400', '{"success":false,"code":"BAD"}'), 'FINAL F BAD'); ok('400 from the server: FINAL F BAD (retrying a refused request would never help)');

  // the bot never sends something the server would have to refuse
  for (const bad of ['TRADEQ,T1,BUY,SOL"USDT,5,10', 'TRADEQ,T1,BUY,SOLUSDT,0,10', 'TRADEQ,T1,BUY,SOLUSDT,5,300', 'CLOSEQ,C1,UP,SOLUSDT']) assert.strictEqual(bot('build', bad), 'REJECTED');
  ok('malformed commands are rejected on the bot, never sent');

  // ---- manual close from a bot's Manual Trade page: it names only the pair (side ANY), the server closes whichever side is open
  w = world(); await w.send(TRADE('T0000000201'));
  r = await w.send('CLOSEQ,C000000201,ANY,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL O OK'); assert(!w.positions.SOLUSDT);
  await w.send('TRADEQ,T0000000202,SELL,SOLUSDT,20.00,5,90.0,105.0,0.000000,0.00');
  assert.strictEqual(w.positions.SOLUSDT.side, 'Sell');
  r = await w.send('CLOSEQ,C000000202,ANY,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL O OK'); assert(!w.positions.SOLUSDT);
  r = await w.send('CLOSEQ,C000000203,ANY,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL O NOPOS');
  await w.send(TRADE('T0000000204'));
  r = await w.send('CLOSEQ,C000000204,SELL,SOLUSDT'); assert.strictEqual(r.verdict, 'FINAL F SIDE'); assert(w.positions.SOLUSDT, 'an explicit wrong side still leaves the position alone');
  assert.strictEqual(w.reports.filter(x => x.kind === 'CLOSE' && x.side === 'ANY').length, 3);
  ok('manual close with no side: closes a long and a short, NOPOS when flat, and an explicit wrong side is still refused');
  for (const bad of ['TRADEQ,T1,ANY,SOLUSDT,5,10', 'SLTPQ,S1,ANY,SOLUSDT,1.5,2.5']) assert.strictEqual(bot('build', bad), 'REJECTED');
  assert.notStrictEqual(bot('build', 'CLOSEQ,C1,ANY,SOLUSDT'), 'REJECTED');
  ok('side ANY is accepted for CLOSE only (an open or a stop update must still name its side)');

  // ---- the bot's own check-ins with the server (replace the manager's heartbeat bridge and fleet ping)
  assert.strictEqual(bot('pingid', '{"success":true,"pingId":"ping-1760000000000"}'), 'ping-1760000000000');
  for (const body of ['{"success":true,"pingId":null}', '', '{"success":true}', '{"pingId":"bad id"}', '{"pingId":"a<b"}', '{"pingId":""}', '<html>502</html>', '{"pingId":"' + 'x'.repeat(60) + '"}'])
    assert.strictEqual(bot('pingid', body), 'NONE', 'not a round for this bot: ' + body.slice(0, 30));
  ok('poll answer: a waiting round is picked up; "nothing waiting", junk, odd characters and over-long ids are all ignored');
  const pr = JSON.parse(bot('pingres', 'ping-1760000000000', 'YM ORACLE II', '842'));
  assert.deepStrictEqual(pr, { pingId: 'ping-1760000000000', name: 'YM ORACLE II', ms: 842 });
  ok('ping answer: valid JSON with the bot\'s own measured round trip');
  const hb = JSON.parse(bot('hb'));
  assert.deepStrictEqual(hb, { name: 'YM ORACLE III', uptimeMin: 72, freeHeap: 118000, resetReason: 'CRASH', build: 'final-16-direct', relayOn: 1, relayMarginUsd: 20, swingRelayOn: 0 });
  ok('heartbeat: valid JSON carrying uptime, memory, reset reason, build and the relay switches (what the server\'s alerts read)');
  for (const f of fleet) {
    const src = fs.readFileSync(f, 'utf8');
    assert(src.includes('#define RELAY_MANAGER_FALLBACK 0'), f + ': the manager fallback is not switched off');
    assert(src.includes('        sendHeartbeatToServer();') && src.includes('        sendHeartbeatToManager();'), f + ': the heartbeat loop must send BOTH the server heartbeat and the small ESP-NOW one to the manager');
    assert(src.includes('    botPollTick();'), f + ': the poll is not called');
    assert(!/sendManualEspNowCommand\(String\(cmdBuf\)\)|sendManualEspNowCommand\(cmd\)/.test(src), f + ': the Manual Trade page still sends over ESP-NOW');
    assert(src.includes('manualRelaySubmit(\'T\'') && src.includes('manualRelaySubmit(\'C\''), f + ': Manual Trade does not use the queue');
  }
  ok('all 4 bots: manager fallback off, heartbeat goes to the server AND the manager, poll goes to the server, Manual Trade open and close use the retried queue');

  console.log('\nALL ' + n + ' PIPELINE CHECKS PASSED');
})().catch(e => { console.error('PIPELINE FAILED:', e.message); process.exit(1); });
