// Bot side of the pipeline test. Includes the RELAY-HTTPS block exactly as it is in a fleet .ino (extracted by pipeline.test.js).
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstdint>
#include "relay_https_block.h"
int main(int argc, char** argv) {
  if (argc >= 3 && !strcmp(argv[1], "build")) {          // botside build "<queued command text>"  -> JSON for POST /api/trade
    char out[420], id[14];
    bool r = relayBuildHttpsJson(argv[2], "YM ORACLE III", out, sizeof(out), id);
    printf("%s\n", r ? out : "REJECTED"); return 0;
  }
  if (argc >= 4 && !strcmp(argv[1], "reply")) {          // botside reply <http> '<body>'  -> what the bot concludes
    bool ok; char code[8];
    int f = relayParseHttpsReply(atoi(argv[2]), argv[3], &ok, code, sizeof(code));
    if (f == 1) printf("FINAL %s %s\n", ok ? "O" : "F", code); else printf("RETRY\n");
    return 0;
  }
  if (argc >= 3 && !strcmp(argv[1], "pingid")) {         // botside pingid '<body of GET /api/bot-poll>'  -> the round this bot would answer
    char id[48]; printf("%s\n", botParsePingId(argv[2], id, sizeof(id)) ? id : "NONE"); return 0;
  }
  if (argc >= 5 && !strcmp(argv[1], "pingres")) {        // botside pingres <id> <name> <ms>  -> JSON for POST /api/ping-result
    char out[160]; int n = botBuildPingResultJson(out, sizeof(out), argv[2], argv[3], atol(argv[4])); printf("%s\n", n > 0 ? out : "REJECTED"); return 0;
  }
  if (argc >= 2 && !strcmp(argv[1], "hb")) {             // botside hb  -> JSON for POST /api/heartbeat (fixed sample values)
    char out[260]; int n = botBuildHeartbeatJson(out, sizeof(out), "YM ORACLE III", 72UL, 118000UL, "CRASH", "final-16-direct", 1, 20.0, 0); printf("%s\n", n > 0 ? out : "REJECTED"); return 0;
  }
  return 2;
}
