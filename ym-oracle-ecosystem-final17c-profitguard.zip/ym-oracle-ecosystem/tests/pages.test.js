'use strict';
// Every inline <script> in relay/public/*.html must at least parse. A single stray apostrophe in one string literal makes the WHOLE page's script
// fail, and the page then loads but does nothing. Run: node tests/pages.test.js   (needs node only)
const fs = require('fs'), path = require('path'), os = require('os'), { spawnSync } = require('child_process');
const dir = path.join(__dirname, '..', 'relay', 'public'); let bad = 0, n = 0;
for (const f of fs.readdirSync(dir).filter(x => x.endsWith('.html'))) {
  const h = fs.readFileSync(path.join(dir, f), 'utf8');
  const re = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g; let m, i = 0;
  while ((m = re.exec(h))) { const p = path.join(os.tmpdir(), `pg-${f}-${i++}.js`); fs.writeFileSync(p, m[1]); const r = spawnSync(process.execPath, ['--check', p], { encoding: 'utf8' }); n++; if (r.status !== 0) { bad++; console.log('SYNTAX ERROR in ' + f + ' (script ' + (i - 1) + '):\n' + r.stderr.split('\n').slice(0, 4).join('\n')); } else console.log('  ok ' + f + ' script ' + (i - 1)); }
}
if (bad) { console.log('\n' + bad + ' PAGE SCRIPT(S) BROKEN'); process.exit(1); }
console.log('\nALL ' + n + ' PAGE SCRIPTS PARSE');
