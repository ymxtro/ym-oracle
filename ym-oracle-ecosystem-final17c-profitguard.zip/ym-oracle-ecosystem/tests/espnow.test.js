'use strict';
// Tests the bots' manager route (RELAY_VIA_HTTPS 0): the REAL RELAY-PROTOCOL block is cut out of each fleet .ino and compiled with g++
// against tiny stand-ins for millis()/Serial/the radio. Run:  node tests/espnow.test.js   (needs g++ and node)
const fs = require('fs'), path = require('path'), os = require('os'), assert = require('assert');
const { execFileSync } = require('child_process');
const root = path.join(__dirname, '..');
const fleet = ['1', '2', '3', '4'].map(i => path.join(root, 'fleet', `oracle${i}_lf_final16`, `oracle${i}_lf_final16.ino`));
let n = 0; const ok = m => console.log('  ok ' + (++n) + ' ' + m);
const cut = f => { const s = fs.readFileSync(f, 'utf8').replace(/\r\n/g, '\n'); const a = s.indexOf('// ===== RELAY-PROTOCOL-BEGIN'), b = s.indexOf('// ===== RELAY-PROTOCOL-END ====='); assert(a > 0 && b > a, f + ': markers'); return s.slice(a, b); };
const blocks = fleet.map(cut);
assert(blocks.every(b => b === blocks[0]), 'the RELAY-PROTOCOL block differs between bots'); ok('all 4 bots carry the identical RELAY-PROTOCOL block');
for (const f of fleet) assert(/#define RELAY_VIA_HTTPS 0\b/.test(fs.readFileSync(f, 'utf8')), f + ': not on the manager route');
ok('all 4 bots are set to the manager route (RELAY_VIA_HTTPS 0)');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'espnow-'));
const cpp = `
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cstdint>
#include <string>
#include <vector>
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) ((void)0)
#define portEXIT_CRITICAL(x) ((void)0)
static unsigned long g_ms = 0; unsigned long millis() { return g_ms; }
uint32_t esp_random() { static uint32_t s = 0x1234ABCD; s = s * 1664525u + 1013904223u; return s; }
struct SerialT { void println(const char*) {} template <typename... A> void printf(const char*, A...) {} } Serial;
#define RELAY_VIA_HTTPS 0
#define RELAY_MANAGER_FALLBACK 0
#define RELAY_HTTPS_FALLBACK_AFTER 3
static std::vector<std::string> radio; static int httpsCalls = 0, alerts = 0;
${blocks[0]}
bool relayRadioSend(const char* t) { radio.push_back(t); return true; }
void relayDeliver(const char*, uint8_t) { httpsCalls++; }
static std::vector<std::string> alertCodes;
void relayEmitAlert(char, const char*, bool, bool, const char* code, bool) { alerts++; alertCodes.push_back(code); }
void relayLogOutcome(const char*, unsigned long, const char*, const char*, long) {}
bool swingLogTradeRelayResult(const char*, unsigned long, const char*, long) { return true; }
void webLogRelayResult(const char*, bool, unsigned long, bool, const char*, bool, const char*, long) {}
static void out(const char* k, const std::string& v) { printf("%s=%s\\n", k, v.c_str()); }
static void dump(const char* k) { std::string s; for (auto& x : radio) s += x + "|"; out(k, s); radio.clear(); }
int main() {
  relayInit();
  char id[14];
  g_ms = 1000;
  int slot = manualRelaySubmitLike('T', true, "BTCUSDT", "BUY,BTCUSDT,10.00,10,,,,", id);
  out("slot_ok", slot >= 0 ? "1" : "0"); out("id", id); dump("first_send");         // the frame leaves at once
  g_ms = 2000; relayTick(); dump("tick_at_1s");                                     // nothing due yet (resend is 2 s after the first send)
  g_ms = 3000; relayTick(); dump("tick_at_2s");                                     // first resend, same id
  char ack[40]; snprintf(ack, sizeof(ack), "ACK,%s", id); relayOnMessage(ack);
  g_ms = 20000; relayTick(); dump("tick_after_ack");                                 // acknowledged: no fast resend
  char res[40]; snprintf(res, sizeof(res), "RES,%s,O,OK", id); relayOnMessage(res);
  g_ms = 70000; relayTick(); dump("tick_after_res");                                 // finished: silence
  out("last_line", relayState->lastLine);
  char cid[14]; manualRelaySubmitLike('C', true, "BTCUSDT", "ANY,BTCUSDT", cid); out("close_id", cid); dump("close_send");
  char eid[14]; manualRelaySubmitLike('T', true, "ETHUSDT", "BUY,ETHUSDT,10.00,10,,,,", eid); radio.clear();
  char bad[40]; snprintf(bad, sizeof(bad), "RES,%s,F,BAL", eid); relayOnMessage(bad);
  out("eth_flagged_failed", relayTradeFailed("ETHUSDT") ? "1" : "0");
  out("https_calls", std::to_string(httpsCalls));
  // --- SYNC-17 scenarios ---
  out("manual_id_tag", std::string(1, eid[0]));                                                       // manual open ids start with M
  // an AUTOMATIC open (id starts with T) that fails DOES flag the pair
  char aid[14]; relaySubmit('T', true, "SOLUSDT", "BUY,SOLUSDT,10.00,10,,,,", 0UL, false, aid); radio.clear();
  char abad[40]; snprintf(abad, sizeof(abad), "RES,%s,F,BAL", aid); relayOnMessage(abad);
  out("auto_flagged_failed", relayTradeFailed("SOLUSDT") ? "1" : "0"); out("auto_id_tag", std::string(1, aid[0]));
  // a failed MANUAL open on the same pair after a SUCCESS elsewhere must not flag anything new
  out("eth_flagged_after_fix", relayTradeFailed("ETHUSDT") ? "1" : "0");
  // a manual open that is never ACKed expires after 90 s; an automatic one keeps going
  { char cres[40]; snprintf(cres, sizeof(cres), "RES,%s,O,OK", cid); relayOnMessage(cres); } // finish the earlier un-ACKed close so it does not count here
  g_ms = 100000; alertCodes.clear(); alerts = 0;
  char mid[14]; manualRelaySubmitLike('T', true, "XRPUSDT", "BUY,XRPUSDT,10.00,10,,,,", mid);
  char tid[14]; relaySubmit('T', true, "ADAUSDT", "BUY,ADAUSDT,10.00,10,,,,", 0UL, false, tid); radio.clear();
  for (unsigned long t = 100000; t <= 129000; t += 1000) { g_ms = t; relayTick(); }                  // 29 s of silence: no alert yet
  out("alerts_at_29s", std::to_string(alerts));
  g_ms = 131000; relayTick();                                                                         // 31 s: the silent-manager alert
  out("alerts_at_31s", std::to_string(alerts)); out("alert_code", alertCodes.empty() ? "" : alertCodes[0]);
  for (unsigned long t = 132000; t <= 189000; t += 1000) { g_ms = t; relayTick(); }
  out("alerts_total_before_expiry", std::to_string(alerts));                                          // still just the one (5-minute cooldown, one per command)
  for (unsigned long t = 190000; t <= 192000; t += 500) { g_ms = t; relayTick(); }                  // the manual open passes its 90 s here
  // the manual open is gone after 90 s (NOANS); the automatic one is still being resent
  out("manual_alive_at_100s", relayFindById(mid) >= 0 ? "1" : "0");
  out("auto_alive_at_100s", relayFindById(tid) >= 0 ? "1" : "0");
  out("noans_line", relayState->lastLine);
  return 0;
}
`;
// manualRelaySubmit lives outside the block (it just calls relaySubmit); mirror it exactly here
const cpp2 = cpp.replace('int main() {', 'int manualRelaySubmitLike(char k, bool l, const char* s, const char* b, char* o) { return relaySubmit(k, l, s, b, 0UL, false, o, k == \'T\' ? \'M\' : (char)0); }\nint main() {');
const src = fs.readFileSync(fleet[0], 'utf8');
assert(/int manualRelaySubmit\([^)]*\) \{\s*return relaySubmit\(kind, isLong, symbol, body, 0UL, false, outId, kind == 'T' \? 'M' : \(char\)0\);/.test(src), 'manualRelaySubmit no longer matches the mirror in this test');
ok('manualRelaySubmit is a plain call of relaySubmit (so the test mirrors it exactly)');
// the harness uses manualRelaySubmitLike before its definition: forward-declare
const cpp3 = cpp2.replace('static void out(', 'int manualRelaySubmitLike(char, bool, const char*, const char*, char*);\nstatic void out(');
fs.writeFileSync(path.join(tmp, 'e.cpp'), cpp3);
execFileSync('g++', ['-std=c++14', '-Wall', '-Wno-unused-function', '-o', path.join(tmp, 'e'), path.join(tmp, 'e.cpp')], { stdio: 'inherit' });
const o = Object.fromEntries(execFileSync(path.join(tmp, 'e')).toString().trim().split('\n').map(l => { const i = l.indexOf('='); return [l.slice(0, i), l.slice(i + 1)]; }));
assert.strictEqual(o.slot_ok, '1');
assert.strictEqual(o.first_send, `TRADEQ,${o.id},BUY,BTCUSDT,10.00,10,,,,|`); ok('a manual open leaves over ESP-NOW immediately as TRADEQ with its id');
assert.strictEqual(o.tick_at_1s, ''); ok('no resend before 2 s');
assert.strictEqual(o.tick_at_2s, `TRADEQ,${o.id},BUY,BTCUSDT,10.00,10,,,,|`); ok('an unanswered command is resent with the SAME id (the manager refuses a repeat as a duplicate)');
assert.strictEqual(o.tick_after_ack, ''); ok('after the manager\'s ACK the fast resends stop');
assert.strictEqual(o.tick_after_res, ''); assert(/order: done \(OK\)/.test(o.last_line), o.last_line); ok('the manager\'s RES finishes the command and the result line says done (OK)');
assert.strictEqual(o.close_send, `CLOSEQ,${o.close_id},ANY,BTCUSDT|`); ok('a manual close names only the pair (ANY) over ESP-NOW');
assert.strictEqual(o.https_calls, '0'); ok('nothing goes over HTTPS from the bot in this mode (no network lock held by trades)');
assert.strictEqual(o.manual_id_tag, 'M'); assert.strictEqual(o.auto_id_tag, 'T'); ok('a manual open gets an id starting with M, an automatic one with T');
assert.strictEqual(o.eth_flagged_failed, '0'); ok('a FAILED manual open no longer flags its pair, so the bot keeps mirroring stops/closes for its own trade on that pair');
assert.strictEqual(o.auto_flagged_failed, '1'); ok('a failed AUTOMATIC open still flags its pair (unchanged safety behaviour)');
assert.strictEqual(o.alerts_at_29s, '0'); assert.strictEqual(o.alerts_at_31s, '1'); assert.strictEqual(o.alert_code, 'NOACK'); ok('a command the manager has not ACKed for 30 s raises one NOACK alert (none before)');
assert.strictEqual(o.alerts_total_before_expiry, '1'); ok('the silent-manager alert is rate-limited: two silent commands, still only one alert');
assert.strictEqual(o.manual_alive_at_100s, '0'); assert.strictEqual(o.auto_alive_at_100s, '1'); ok('an un-ACKed manual open expires after 90 s; an automatic order keeps being resent');
assert(/NO ANSWER from the manager/.test(o.noans_line), o.noans_line); ok('the give-up line names the manager on the manager route (it used to say web server)');
// the manager must accept that ANY close
const mgr = fs.readFileSync(path.join(root, 'manager', 'bybit_manager_fixed', 'bybit_manager_fixed.ino'), 'utf8').replace(/\r\n/g, '\n');
assert(mgr.includes('side != "SELL" && side != "ANY"') && mgr.includes('""); // "" = close whichever side is open'), 'the manager does not accept CLOSEQ,<id>,ANY,<symbol>');
ok('the manager accepts CLOSEQ with ANY and closes whichever side is open');
for (const f of fleet) {
  const t = fs.readFileSync(f, 'utf8').replace(/\r\n/g, '\n');
  assert(/#define BOT_ONLY_MANAGER_REPLIES 1/.test(t) && /memcmp\(recv_info->src_addr, bybitManagerMac, 6\) != 0\) \{ relayRxForeign\+\+; return; \}/.test(t), f + ': the bot does not filter ESP-NOW senders');
  assert(t.includes('        sendHeartbeatToManager();') && t.includes('#define BUILD_TAG "final-17b-sync"'), f + ': heartbeat/build tag');
}
for (const f of fleet) { const u = fs.readFileSync(f, 'utf8'); assert(/#define BOT_POLL_ENABLED 0/.test(u) && u.includes('setConnectTimeout(2500);   // SYNC-17b') , f + ': poll not off / timeouts not shortened'); }
ok('no bot polls the server any more (BOT_POLL_ENABLED 0) and the heartbeat call holds the network lock for at most 6 s');
ok('all 4 bots accept ACK/RES/PING only from the manager MAC, send the ESP-NOW heartbeat again, and carry build final-17b-sync');
assert(/#define MGR_SENDER_CHECK 1/.test(mgr) && mgr.includes('if (!isKnownOracleMac(src)) {') && mgr.includes('#if MGR_SENDER_CHECK >= 2\n    return;'), 'manager sender check missing');
ok('the manager checks every frame\'s sender against the four bot MACs (ships log-only; 2 = enforce)');
const srv = fs.readFileSync(path.join(root, 'relay', 'server.js'), 'utf8');
assert(srv.includes('managerOwnsPing') && srv.includes('!(timeout && prev && prev.ms !== undefined)'), 'server ping ownership missing');
ok('the server lets the manager own fleet-ping rounds while it polls, and a late timeout can never overwrite a real answer');
console.log('\nALL ' + n + ' MANAGER-ROUTE CHECKS PASSED');
