'use strict';
/*
 * Multi-user layer for the Bybit relay.
 *
 * Needs two env vars, otherwise it stays OFF and the relay behaves exactly as before:
 *   DATABASE_URL           Postgres connection string (Neon free tier works)
 *   KEY_ENCRYPTION_SECRET  64 hex chars (32 bytes)
 *
 * Optional:
 *   DASHBOARD_PASSWORD         REQUIRED for any /admin access (admin routes refuse to work without it)
 *   ADMIN_TOTP_SECRET          base32 secret; if set, admin login also needs the 6-digit authenticator code
 *   ALERT_TELEGRAM_BOT_TOKEN / ALERT_TELEGRAM_CHAT_ID   admin alerts, user Telegram alerts, daily CSV backup
 *   TELEGRAM_BOT_USERNAME      only needed if the bot's username can't be fetched automatically
 *   MAX_USER_LEVERAGE          cap leverage applied to users' accounts (0 / unset = no cap)
 *   PUBLIC_OUTBOUND_IPS        shown on the signup page so users can whitelist your server on their key
 *   MULTIUSER_MAX_RATIO        cap on (user equity / admin equity) when scaling size, default 10
 *   DATABASE_SSL=false         only for a local Postgres
 */
const crypto = require('crypto');
const path = require('path');
const { RestClientV5 } = require('bybit-api');
const sec = require('./security');

const SESSION_DAYS = 30;
const ADMIN_SESSION_HOURS = 12;
const AUTH_RET_CODES = new Set([10003, 10004, 10005, 10010, 33004]); // bad/expired key, bad IP, no permission
const BAL_RET_CODES = new Set([110004, 110007, 110012, 110045]);      // insufficient balance / margin
const SYNC_INTERVAL_MS = 5 * 60 * 1000;
const QUIET_CODES = new Set(['DUP', 'HELD', 'NOPOS', 'PAPER', 'FILT', 'MAXT', 'DRY']);       // never worth pinging a user about
const CODE_TEXT = {
  BAL: 'not enough free money for this trade', MINQ: "this trade is smaller than the smallest order Bybit allows for this coin", PAIR: 'pair not tradable',
  LEV: 'Bybit rejected the leverage', NET: "couldn't reach Bybit", BYBIT: 'Bybit refused the order', HALT: 'trading is halted for you right now',
  SIDE: 'your position is on the other side', AUTH: 'your API key stopped working',
  FILT: 'skipped by your coin or direction settings', MAXT: 'you already have your maximum number of open trades',
};

// Only these fields are ever forwarded to users' accounts -- a request can never smuggle extra parameters into someone else's order.
const ORDER_FIELDS = ['category', 'symbol', 'isLeverage', 'side', 'orderType', 'qty', 'marketUnit', 'price', 'triggerDirection', 'orderFilter', 'triggerPrice', 'triggerBy',
  'timeInForce', 'positionIdx', 'takeProfit', 'stopLoss', 'tpTriggerBy', 'slTriggerBy', 'reduceOnly', 'closeOnTrigger', 'smpType', 'tpslMode', 'tpLimitPrice', 'slLimitPrice', 'tpOrderType', 'slOrderType'];
const STOP_FIELDS = ['symbol', 'positionIdx', 'takeProfit', 'stopLoss', 'trailingStop', 'activePrice', 'tpTriggerBy', 'slTriggerBy', 'tpslMode', 'tpSize', 'slSize', 'tpLimitPrice', 'slLimitPrice', 'tpOrderType', 'slOrderType'];
const NUMERIC_FIELDS = ['qty', 'price', 'triggerPrice', 'takeProfit', 'stopLoss', 'tpLimitPrice', 'slLimitPrice', 'tpSize', 'slSize', 'trailingStop', 'activePrice'];
const SYMBOL_RE = /^[A-Z0-9]{2,20}USDT$/;

// ---------- pure helpers (unit-testable) ----------
function sha1(s) { return crypto.createHash('sha1').update(String(s)).digest('hex'); }
function sha256(s) { return crypto.createHash('sha256').update(String(s)).digest('hex'); }

function encrypt(plain, keyBuf) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', keyBuf, iv);
  const enc = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map(b => b.toString('base64')).join('.');
}
function decrypt(blob, keyBuf) {
  const [iv, tag, enc] = String(blob).split('.').map(x => Buffer.from(x, 'base64'));
  const d = crypto.createDecipheriv('aes-256-gcm', keyBuf, iv);
  d.setAuthTag(tag);
  return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
}

function scryptAsync(pw, salt) {
  return new Promise((resolve, reject) => crypto.scrypt(pw, salt, 64, (e, k) => (e ? reject(e) : resolve(k))));
}
async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = await scryptAsync(pw, salt);
  return 'scrypt$' + salt.toString('base64') + '$' + key.toString('base64');
}
async function verifyPassword(pw, stored) {
  try {
    const [, saltB64, keyB64] = String(stored).split('$');
    const expected = Buffer.from(keyB64, 'base64');
    const actual = await scryptAsync(pw, Buffer.from(saltB64, 'base64'));
    return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
  } catch { return false; }
}

function decimalsOf(step) {
  const s = String(step);
  if (s.includes('e-')) return parseInt(s.split('e-')[1], 10);
  const i = s.indexOf('.');
  return i < 0 ? 0 : s.length - i - 1;
}

// Same % of equity as the admin account: userQty = adminQty * (userEquity / adminEquity) * multiplier.
// ---- per-user Bybit environment helpers (pure, tested directly) ----
const normEnv = e => (e === 'demo' ? 'demo' : 'live');
// Which environment the relay itself (the master account) was running in. Used once, to label users that existed before v1.7.
function defaultEnvFor(base) {
  base = base || {};
  return (base.demoTrading || /api-demo\./i.test(String(base.baseUrl || ''))) ? 'demo' : 'live';
}
// Client options for a user's own environment. The master's baseUrl / demoTrading never leak into a user's client.
function envOptsFor(base, env) {
  const o = { ...(base || {}) };
  delete o.baseUrl; delete o.demoTrading;
  if (normEnv(env) === 'demo') { delete o.testnet; o.demoTrading = true; }
  return o;
}

function scaleQty({ adminQty, adminEquity, userEquity, mult, qtyStep, minQty, maxRatio }) {
  adminQty = Number(adminQty); adminEquity = Number(adminEquity); userEquity = Number(userEquity);
  if (!(adminQty > 0) || !(adminEquity > 0) || !(userEquity > 0)) return { qty: null, code: 'BAL' };
  let ratio = userEquity / adminEquity;
  const capped = ratio > (maxRatio || 10);
  if (capped) ratio = maxRatio || 10;
  const raw = adminQty * ratio * (Number(mult) > 0 ? Number(mult) : 1);
  const step = qtyStep > 0 ? qtyStep : 0.000001;
  const qty = Number((Math.floor(raw / step + 1e-9) * step).toFixed(decimalsOf(step)));
  if (!(qty > 0) || qty < (minQty || 0)) return { qty: null, code: 'MINQ' };
  return { qty, code: 'OK', capped };
}

const SIZE_MODES = ['fixed', 'percent'];   // 'match' (copy the master's share) was retired in Standard v1; old rows are converted on startup
// Standard v1 numbers (one place, so the docs, the screens and the code agree)
const STD = { pct: 20, userPctMax: 30, userPctConfirmAbove: 20, maxTradeUsd: 500, maxOpen: 3, adminMaxOpen: 5, dailyLossPct: 10, drawdownPct: 30, floorMult: 1.5, floorBalanceShare: 0.35, legacyMatchPct: 10, minLiveBalance: 50 };
const DIRECTIONS = ['both', 'long', 'short'];

// ---------- Master Plan (universal settings the admin sets for every autopilot account) ----------
// Standard v1: every account sizes trades from ITS OWN balance. The plan supplies the starting percent for new sign-ups plus the safety rails
// and signal rules that apply to everyone. Leverage is not a setting: it is exactly what the signal says (maxLeverage is kept only so old stored plans still load).
const PLAN_DEFAULT = { sizeMode: 'percent', sizeMult: 1, sizeUsd: null, sizePct: STD.pct, maxOpenTrades: STD.maxOpen, symbols: null, direction: 'both',
  maxLeverage: null, dailyLossLimitUsd: null, dailyLossPct: STD.dailyLossPct, dailyProfitTargetUsd: null, drawdownStopPct: STD.drawdownPct, maxTradeUsd: STD.maxTradeUsd, allowManual: true };
const CONTROL_KEYS = ['sizeMode', 'sizeMult', 'sizeUsd', 'sizePct', 'maxOpenTrades', 'symbols', 'direction', 'maxLeverage', 'dailyLossLimitUsd', 'dailyLossPct', 'dailyProfitTargetUsd', 'drawdownStopPct', 'maxTradeUsd'];
const MANUAL_KEYS = ['sizeMode', 'sizeUsd', 'sizePct', 'dailyLossLimitUsd']; // what a user may change on their own account (their own size and loss limit)

// The plan as it was before Standard v1 (used only to read old stored plans and by the one-time migration)
const LEGACY_PLAN = { sizeMode: 'match', sizeMult: 1, sizeUsd: null, sizePct: null, maxOpenTrades: null, symbols: null, direction: 'both',
  maxLeverage: null, dailyLossLimitUsd: null, dailyProfitTargetUsd: null, drawdownStopPct: null, allowManual: true };
// an old stored plan that still says sizeMode:'match' is read as the Standard sizing, so it always validates
function normalizeStoredPlan(stored) {
  const o = { ...(stored || {}) };
  if (o.sizeMode === 'match') { o.sizeMode = PLAN_DEFAULT.sizeMode; o.sizePct = PLAN_DEFAULT.sizePct; o.sizeUsd = null; }
  return o;
}

const posOrNull = (v, max) => { if (v === null || v === '' || v === undefined) return null; const n = Number(v); return Number.isFinite(n) && n > 0 && n <= max ? n : NaN; };

// Validates a controls body (admin master plan or a manual user). o = { current, allowed, ceilUsd, levCeil, sizeMultMax }
// Returns { error } or { values } (only the keys that were sent).
function parseControls(b, o) {
  const bad = m => ({ error: m });
  const cur = o.current || {}, allowed = o.allowed || CONTROL_KEYS;
  b = b || {};
  for (const k of CONTROL_KEYS.concat(['allowManual'])) if (b[k] !== undefined && !allowed.includes(k)) return bad('That setting is managed by the admin plan.');
  const v = {};
  if (b.dailyLossLimitUsd !== undefined) {
    const n = b.dailyLossLimitUsd === null || b.dailyLossLimitUsd === '' ? null : Number(b.dailyLossLimitUsd);
    if (n !== null && !(n >= 0 && Number.isFinite(n))) return bad('Daily loss limit must be a positive number or empty.');
    v.dailyLossLimitUsd = n;
  }
  if (b.dailyProfitTargetUsd !== undefined) { const n = posOrNull(b.dailyProfitTargetUsd, 1e9); if (Number.isNaN(n)) return bad('Daily profit target must be a positive number or empty.'); v.dailyProfitTargetUsd = n; }
  if (b.drawdownStopPct !== undefined) { const n = posOrNull(b.drawdownStopPct, 90); if (Number.isNaN(n) || (n !== null && n < 1)) return bad('Drawdown stop must be between 1 and 90 percent, or empty.'); v.drawdownStopPct = n; }
  if (b.sizeMult !== undefined) {
    const n = Number(b.sizeMult), max = o.sizeMultMax || 20;
    if (!(n > 0) || n > max) return bad('Size multiplier must be above 0 and at most ' + max + '.');
    v.sizeMult = n;
  }
  if (b.dailyLossPct !== undefined) { const n = posOrNull(b.dailyLossPct, 50); if (Number.isNaN(n) || (n !== null && n < 1)) return bad('Daily loss limit must be between 1 and 50 percent of the balance, or empty.'); v.dailyLossPct = n; }
  if (b.maxTradeUsd !== undefined) { const n = posOrNull(b.maxTradeUsd, 1e7); if (Number.isNaN(n)) return bad('The most any trade can use must be a positive number, or empty for no cap.'); v.maxTradeUsd = n; }
  if (b.sizeMode !== undefined) {
    if (b.sizeMode === 'match') return bad('Copying the master account\'s share is retired. Choose a percent of balance or a fixed amount.');
    if (!SIZE_MODES.includes(b.sizeMode)) return bad('Unknown trade size mode.');
    v.sizeMode = b.sizeMode;
  }
  if (b.sizeUsd !== undefined) {
    const n = posOrNull(b.sizeUsd, 1e7); if (Number.isNaN(n)) return bad('Trade amount must be a positive number.');
    if (n !== null && o.ceilUsd && n > o.ceilUsd) return bad('Your trade amount can be at most $' + o.ceilUsd + ' (the limit set for your account).');
    v.sizeUsd = n;
  }
  if (b.sizePct !== undefined) { const n = posOrNull(b.sizePct, o.pctMax || 100); if (Number.isNaN(n)) return bad('Percent of balance must be above 0 and at most ' + (o.pctMax || 100) + '.'); v.sizePct = n; }
  if (b.maxOpenTrades !== undefined) {
    const n = b.maxOpenTrades === null || b.maxOpenTrades === '' ? null : Number(b.maxOpenTrades);
    if (n !== null && !(Number.isInteger(n) && n >= 1 && n <= (o.openMax || 50))) return bad('Max open trades must be a whole number from 1 to ' + (o.openMax || 50) + ', or empty.');
    v.maxOpenTrades = n;
  }
  if (b.direction !== undefined) { if (!DIRECTIONS.includes(b.direction)) return bad('Direction must be both, long or short.'); v.direction = b.direction; }
  if (b.symbols !== undefined) {
    if (b.symbols === null) v.symbols = null;
    else {
      if (!Array.isArray(b.symbols) || b.symbols.length > 60) return bad('Coin list is not valid.');
      const list = Array.from(new Set(b.symbols.map(x => String(x).toUpperCase().trim()).filter(Boolean).map(x => (x.endsWith('USDT') ? x : x + 'USDT'))));
      if (list.some(x => !SYMBOL_RE.test(x))) return bad('One of the coins is not valid.');
      v.symbols = list.length ? list : null;
    }
  }
  if (b.maxLeverage !== undefined) {
    const n = posOrNull(b.maxLeverage, 125); if (Number.isNaN(n)) return bad('Max leverage must be between 1 and 125, or empty.');
    if (n !== null && o.levCeil && n > o.levCeil) return bad('Your leverage can be at most ' + o.levCeil + 'x (the limit set for your account).');
    v.maxLeverage = n;
  }
  if (b.allowManual !== undefined) { if (typeof b.allowManual !== 'boolean') return bad('allowManual must be true or false.'); v.allowManual = b.allowManual; }
  const merged = { ...cur, ...v };
  if (merged.sizeMode === 'fixed' && !(merged.sizeUsd > 0)) return bad('Enter the USD amount to use for each trade.');
  if (merged.sizeMode === 'percent' && !(merged.sizePct > 0)) return bad('Enter the percent of the balance to use for each trade.');
  return { values: v };
}

// How closely a manual user's settings track the master plan: 100 = identical. (join.html has a copy of this formula for its live gauge.)
function planMatch(plan, e) {
  const amt = x => (x.sizeMode === 'fixed' ? Number(x.sizeUsd) : x.sizeMode === 'percent' ? Number(x.sizePct) : Number(x.sizeMult));
  const sim = (a, b) => (!Number.isFinite(a) || !Number.isFinite(b) ? 0 : a === b ? 1 : 1 - Math.min(1, Math.abs(a - b) / Math.max(Math.abs(a), Math.abs(b))));
  const sizing = plan.sizeMode === e.sizeMode ? sim(amt(plan), amt(e)) : 0.3;
  const pl = plan.dailyLossLimitUsd, el = e.dailyLossLimitUsd;
  const loss = (pl == null && el == null) ? 1 : (pl == null || el == null) ? 0.4 : sim(Number(pl), Number(el));
  return Math.max(0, Math.min(100, Math.round(70 * sizing + 30 * loss)));
}

// smallest positive number among the arguments, 0 if none is positive (0 = "no cap")
function minPositive(...vals) {
  const p = vals.map(Number).filter(v => Number.isFinite(v) && v > 0);
  return p.length ? Math.min(...p) : 0;
}

// Works out the quantity for one user's new position (Standard v1).
//  percent -> margin is `sizePct` % of THEIR OWN balance;  fixed -> margin is `sizeUsd`
//  margin is capped by the plan's per-trade ceiling (`maxTradeUsd`) and must fit in their free balance
//  position = margin x leverage / price, rounded DOWN to Bybit's step. Leverage is whatever the signal set; it is never changed here.
//  Floor rule: if rounding leaves less than Bybit's minimum order but the minimum is close to what they chose
//  (<= 1.5x their margin) and still a modest part of their balance (<= 35%), the minimum order is used instead of skipping.
// `mode:'match'` (retired) is still understood so a row that was missed by the migration keeps trading at 10% x its multiplier.
function sizeForUser(p) {
  const step = p.qtyStep > 0 ? p.qtyStep : 0.000001;
  const price = Number(p.price), lev = Number(p.leverage);
  const haveMath = price > 0 && lev > 0;
  const ceil = Number(p.maxTradeUsd) > 0 ? Number(p.maxTradeUsd) : 0;
  let mode = p.mode, pct = Number(p.sizePct);
  if (mode === 'match') { mode = 'percent'; pct = Math.min(STD.userPctMax, Math.max(1, STD.legacyMatchPct * (Number(p.mult) > 0 ? Number(p.mult) : 1))); }
  if (!haveMath) return { qty: null, code: 'NET', detail: "Couldn't read the price or leverage needed to size your trade" };
  const equity = Number(p.userEquity);
  if (!(equity > 0)) return { qty: null, code: 'BAL', detail: 'No usable balance' };
  let margin = mode === 'fixed' ? Number(p.sizeUsd) : equity * pct / 100;
  if (!(margin > 0)) return { qty: null, code: 'BAL', detail: 'No usable trade amount' };
  let capped = false;
  if (ceil && margin > ceil) { margin = ceil; capped = true; }
  const avail = Number(p.available);
  const hasAvail = Number.isFinite(avail);
  if (hasAvail && margin > avail) {
    return { qty: null, code: 'BAL', detail: 'This trade needs about $' + margin.toFixed(2) + ' of free money but only $' + avail.toFixed(2) + ' is free (other trades are using the rest)' };
  }
  const toQty = m => Number((Math.floor(m * lev / price / step + 1e-9) * step).toFixed(decimalsOf(step)));
  let qty = toQty(margin), floored = false;
  const minQty = p.minQty || 0;
  if (!(qty > 0) || qty < minQty) {
    const need = minQty * price / lev; // margin the smallest allowed order needs at this leverage
    const ok = minQty > 0 && need <= margin * STD.floorMult + 1e-9 && need <= equity * STD.floorBalanceShare + 1e-9 && (!hasAvail || need <= avail) && (!ceil || need <= ceil * STD.floorMult);
    if (!ok) {
      return { qty: null, code: 'MINQ', detail: 'Your ' + (mode === 'fixed' ? '$' + margin.toFixed(2) : pct + '% (about $' + margin.toFixed(2) + ')') + ' is below the smallest order Bybit allows for this coin. The smallest order needs about $' + need.toFixed(2) + ' at ' + lev + 'x, ' + (need > equity * STD.floorBalanceShare ? 'which is more than ' + Math.round(STD.floorBalanceShare * 100) + '% of your balance, so it was skipped to protect you.' : 'which is too far above your amount, so it was skipped. Raise your amount to trade this coin.') };
    }
    qty = Number(minQty.toFixed(decimalsOf(step))); floored = true;
  }
  return { qty, code: 'OK', capped, floored, marginUsd: qty * price / lev };
}

function classifyRet(retCode) {
  if (AUTH_RET_CODES.has(retCode)) return 'AUTH';
  if (BAL_RET_CODES.has(retCode)) return 'BAL';
  return 'BYBIT';
}

function permissionProblem(info) {
  const perms = (info && info.permissions) || {};
  const all = [].concat(...Object.values(perms).map(v => (Array.isArray(v) ? v : [])));
  if (all.some(p => /withdraw/i.test(p))) return 'This API key has withdrawal permission. Create a new key with trade-only permissions (no withdrawals).';
  if (Number(info && info.readOnly) === 1) return 'This API key is read-only. It needs Contract/Derivatives trade permission.';
  const trade = (perms.ContractTrade || []).length + (perms.Derivatives || []).length;
  if (!trade) return 'This API key has no Contract/Derivatives trading permission.';
  return null;
}

function pick(body, fields) {
  const out = {};
  for (const k of fields) if (body[k] !== undefined && body[k] !== null && body[k] !== '') out[k] = body[k];
  return out;
}
function numbersOk(o) {
  for (const k of NUMERIC_FIELDS) if (o[k] !== undefined && !(Number.isFinite(Number(o[k])) && Number(o[k]) >= 0)) return false;
  return true;
}
function sanitizeOrder(body) {
  if (!body || typeof body !== 'object') return null;
  const o = pick(body, ORDER_FIELDS);
  o.category = 'linear';
  if (!SYMBOL_RE.test(String(o.symbol || ''))) return null;
  if (o.side !== 'Buy' && o.side !== 'Sell') return null;
  o.orderType = o.orderType || 'Market';
  if (o.orderType !== 'Market' && o.orderType !== 'Limit') return null;
  if (!numbersOk(o) || !(Number(o.qty) > 0)) return null;
  if (o.reduceOnly !== undefined) o.reduceOnly = o.reduceOnly === true || o.reduceOnly === 'true';
  return o;
}
function sanitizeStop(body) {
  if (!body || typeof body !== 'object') return null;
  const o = pick(body, STOP_FIELDS);
  if (!SYMBOL_RE.test(String(o.symbol || ''))) return null;
  if (!numbersOk(o)) return null;
  if (o.takeProfit === undefined && o.stopLoss === undefined && o.trailingStop === undefined) return null;
  return o;
}
function sanitizeLeverage(body, cap) {
  if (!body || typeof body !== 'object' || !SYMBOL_RE.test(String(body.symbol || ''))) return null;
  let b = Number(body.buyLeverage), s = Number(body.sellLeverage);
  if (!(b > 0 && b <= 125) || !(s > 0 && s <= 125)) return null;
  if (cap > 0) { b = Math.min(b, cap); s = Math.min(s, cap); }
  return { category: 'linear', symbol: body.symbol, buyLeverage: String(b), sellLeverage: String(s) };
}

function csvCell(v) {
  if (v === null || v === undefined) return '';
  let s = v instanceof Date ? v.toISOString() : String(v);
  // neutralise spreadsheet formula injection in text cells, but leave real numbers (including negatives) untouched
  if (/^[=+\-@\t\r]/.test(s) && !/^-?\d+(\.\d+)?(e[+-]?\d+)?$/i.test(s)) s = "'" + s;
  return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

// ---------- module ----------
function init(deps) {
  const noop = async () => {};
  const off = { enabled: false, canPersist: false, loadMasterCreds: async () => null, saveMasterCreds: async () => ({ ok: false, reason: 'no database' }), clearMasterCreds: async () => ({ ok: false, reason: 'no database' }), fanOutOrder: noop, fanOutTradingStop: noop, guardClamp: b => b, guardFitClose: async b => b, fanOutLeverage: noop, recordExec: noop, recordBotEvent: async () => ({ status: 200 }), verifyAdminToken: async () => false, sizeMasterOrder: async () => null,
    _test: { envOptsFor, defaultEnvFor, encrypt, decrypt, scaleQty, sizeForUser, minPositive, parseControls, planMatch, PLAN_DEFAULT, hashPassword, verifyPassword, classifyRet, permissionProblem, sanitizeOrder, sanitizeStop, sanitizeLeverage, csvCell } };

  const DATABASE_URL = process.env.DATABASE_URL || '';
  const SECRET_HEX = process.env.KEY_ENCRYPTION_SECRET || '';
  let Pool;
  try { ({ Pool } = require('pg')); } catch { Pool = null; }
  if (!DATABASE_URL || !/^[0-9a-fA-F]{64}$/.test(SECRET_HEX) || !Pool) {
    console.log('[multiuser] OFF (needs DATABASE_URL, a 64-hex KEY_ENCRYPTION_SECRET, and the pg package). Single-account mode unchanged.');
    return off;
  }

  const { app, restClient, getMode, breakerIsTripped, sendAlert, baseOpts } = deps;
  const PG = require('./profitguard.js');
  let pgCfg = PG.defaults();            // Profit Guard settings (off until switched on from the admin console)
  const pgWatch = new Map();            // re-entry watches (recording only); filled and used further down
  const pgState = new Map();            // 'SYMBOL|Buy' -> { entry, initialSl, peak, floor, shadowSl, profile, ... } for every trade being watched
  // deliverAlert (optional dep) = async text => { ok, configured, telegram, email }: waits for the real result. Falls back to fire-and-forget sendAlert.
  const deliverAlert = deps.deliverAlert || (async (t, _o) => { if (!sendAlert) return { ok: false, configured: false }; sendAlert(t); return { ok: true, configured: true, telegram: 'sent' }; });
  const getSecurityInfo = deps.getSecurityInfo || (() => ({}));
  const alertRouter = deps.alertRouter || null;   // { state, route, envChats, tokenSet }: where Telegram alerts go (see alertroute.js)
  const getMasterSync = deps.getMasterSync || (() => ({}));
  const getExecReports = deps.getExecReports || (() => []);
  const getFleet = deps.getFleet || (() => ({ last: {}, info: {}, offlineMs: 0 }));
  const KEY = Buffer.from(SECRET_HEX, 'hex');
  const MAX_RATIO = Number(process.env.MULTIUSER_MAX_RATIO) || 10;
  const MAX_USER_LEVERAGE = Number(process.env.MAX_USER_LEVERAGE) || 0;
  const MIN_LIVE_BALANCE = process.env.MIN_LIVE_BALANCE !== undefined && process.env.MIN_LIVE_BALANCE !== '' ? Math.max(0, Number(process.env.MIN_LIVE_BALANCE) || 0) : STD.minLiveBalance; // live sign-ups only; demo has no minimum
  const demoLike = !!(baseOpts && (baseOpts.demoTrading || baseOpts.baseUrl || baseOpts.testnet));
  // ---- per-user environment (v1.7): each user's key is either a LIVE key or a Bybit DEMO-trading key ----
  // The relay's own BYBIT_DEMO / BYBIT_TESTNET / BYBIT_BASE_URL settings describe the MASTER account only. A user's client is
  // built from that user's own choice, so a base URL pointing at api-demo.bybit.com can never drag a live user onto demo.
  const DEMO_KEYS_ALLOWED = process.env.DISABLE_DEMO_KEYS !== 'true';
  const DEFAULT_ENV = defaultEnvFor(baseOpts); // what users that existed before v1.7 are treated as
  const envOpts = env => envOptsFor(baseOpts, env);
  const TG_TOKEN = process.env.ALERT_TELEGRAM_BOT_TOKEN || '';
  const TG_ADMIN_CHAT = process.env.ALERT_TELEGRAM_CHAT_ID || '';
  const tgOn = !!TG_TOKEN;
  let tgBotUsername = process.env.TELEGRAM_BOT_USERNAME || '';

  app.set('trust proxy', 1);

  const pool = new Pool({
    connectionString: DATABASE_URL,
    ssl: process.env.DATABASE_SSL === 'false' ? false : { rejectUnauthorized: false },
    max: 5,
    idleTimeoutMillis: 10000,
  });
  pool.on('error', e => console.error('[multiuser] db pool error:', e.message));
  const q = (text, params) => pool.query(text, params);

  const ready = q(`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username TEXT UNIQUE NOT NULL,
      pass_hash TEXT NOT NULL,
      key_enc TEXT,
      key_hash TEXT UNIQUE,
      key_status TEXT NOT NULL DEFAULT 'ok',
      key_error TEXT,
      ips_unrestricted BOOLEAN DEFAULT FALSE,
      active BOOLEAN NOT NULL DEFAULT TRUE,
      paused BOOLEAN NOT NULL DEFAULT FALSE,
      size_mult NUMERIC NOT NULL DEFAULT 1,
      daily_loss_limit_usd NUMERIC,
      last_equity NUMERIC,
      last_pnl_sync_ms BIGINT,
      last_synced_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      expires_at TIMESTAMPTZ NOT NULL
    );
    CREATE TABLE IF NOT EXISTS invites (
      code TEXT PRIMARY KEY,
      used_by INT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS pnl_ledger (
      id BIGSERIAL PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      order_id TEXT NOT NULL,
      symbol TEXT, side TEXT, qty NUMERIC,
      entry_price NUMERIC, exit_price NUMERIC,
      closed_pnl NUMERIC NOT NULL,
      open_fee NUMERIC, close_fee NUMERIC, leverage NUMERIC,
      closed_at TIMESTAMPTZ NOT NULL,
      UNIQUE (user_id, order_id)
    );
    CREATE TABLE IF NOT EXISTS equity_snap (
      user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      day DATE NOT NULL,
      equity NUMERIC NOT NULL,
      PRIMARY KEY (user_id, day)
    );
    CREATE TABLE IF NOT EXISTS order_log (
      id BIGSERIAL PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      kind TEXT NOT NULL,
      order_link_id TEXT,
      symbol TEXT, side TEXT, qty NUMERIC,
      code TEXT, ok BOOLEAN, detail TEXT, bybit_order_id TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE UNIQUE INDEX IF NOT EXISTS order_log_link_uq ON order_log(user_id, order_link_id) WHERE order_link_id IS NOT NULL;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS share_token TEXT UNIQUE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS share_show_balance BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_secret_enc TEXT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_enabled BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS totp_last_counter BIGINT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_logins INT NOT NULL DEFAULT 0;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until TIMESTAMPTZ;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS tg_chat_id TEXT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS tg_link_code TEXT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS tg_link_expires TIMESTAMPTZ;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS tg_notify BOOLEAN NOT NULL DEFAULT TRUE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS size_mult_max NUMERIC NOT NULL DEFAULT 1;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS last_funding_sync_ms BIGINT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS size_mode TEXT NOT NULL DEFAULT 'match';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS size_usd NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS size_pct NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS max_open_trades INT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS symbols_allow TEXT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS direction TEXT NOT NULL DEFAULT 'both';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS user_max_lev NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_profit_target_usd NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS drawdown_stop_pct NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS equity_peak NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS max_trade_usd NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS max_lev_ceiling NUMERIC;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS control_mode TEXT NOT NULL DEFAULT 'auto';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS manual_ack_at TIMESTAMPTZ;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS dry_run BOOLEAN NOT NULL DEFAULT FALSE;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS key_env TEXT NOT NULL DEFAULT 'live';
    ALTER TABLE users ALTER COLUMN size_mode SET DEFAULT 'percent';
    ALTER TABLE users ADD COLUMN IF NOT EXISTS notice TEXT;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS notice_at TIMESTAMPTZ;
    ALTER TABLE users ADD COLUMN IF NOT EXISTS risk_ack_at TIMESTAMPTZ;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS plan_version INT;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS signal_key TEXT;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS risk_usd NUMERIC;
    CREATE INDEX IF NOT EXISTS order_log_signal_idx ON order_log(signal_key) WHERE signal_key IS NOT NULL;
    CREATE TABLE IF NOT EXISTS signals (
      k TEXT PRIMARY KEY,
      bot TEXT NOT NULL DEFAULT '', symbol TEXT, side TEXT, eng TEXT, bot_t BIGINT,
      opened_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      entry NUMERIC, sl NUMERIC, tp NUMERIC, lev NUMERIC, margin NUMERIC,
      relay_flag TEXT, rid TEXT,
      relay_ok BOOLEAN, relay_code TEXT, relay_secs NUMERIC, relay_at TIMESTAMPTZ,
      closed_at TIMESTAMPTZ, won BOOLEAN, exit_price NUMERIC, pct NUMERIC, relayed BOOLEAN, close_why TEXT,
      order_seen_at TIMESTAMPTZ, alarm_at TIMESTAMPTZ,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    ALTER TABLE signals ADD COLUMN IF NOT EXISTS alert_open_at TIMESTAMPTZ;
    ALTER TABLE signals ADD COLUMN IF NOT EXISTS alert_close_at TIMESTAMPTZ;
    ALTER TABLE signals ADD COLUMN IF NOT EXISTS alert_tries INT NOT NULL DEFAULT 0;
    CREATE INDEX IF NOT EXISTS signals_opened_idx ON signals(opened_at DESC);
    CREATE INDEX IF NOT EXISTS signals_rid_idx ON signals(rid) WHERE rid IS NOT NULL AND rid <> '';
    CREATE TABLE IF NOT EXISTS bot_msgs (
      k TEXT PRIMARY KEY, bot TEXT NOT NULL DEFAULT '', kind TEXT NOT NULL DEFAULT 'other', sym TEXT, priv BOOLEAN NOT NULL DEFAULT FALSE,
      text TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), claimed_at TIMESTAMPTZ, sent_at TIMESTAMPTZ, tries INT NOT NULL DEFAULT 0, last_result TEXT
    );
    CREATE INDEX IF NOT EXISTS bot_msgs_recent_idx ON bot_msgs(created_at DESC);
    CREATE TABLE IF NOT EXISTS bot_status (
      bot TEXT PRIMARY KEY, payload TEXT NOT NULL, at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    CREATE TABLE IF NOT EXISTS plan_versions (
      id SERIAL PRIMARY KEY,
      plan TEXT NOT NULL,
      changed_by TEXT,
      summary TEXT,
      restored_from INT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );
    UPDATE users SET size_mult_max = size_mult WHERE size_mult > size_mult_max;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS ref_price NUMERIC;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS fill_price NUMERIC;
    ALTER TABLE order_log ADD COLUMN IF NOT EXISTS slippage_bps NUMERIC;
    CREATE TABLE IF NOT EXISTS audit_log (
      id BIGSERIAL PRIMARY KEY,
      at TIMESTAMPTZ NOT NULL DEFAULT now(),
      actor TEXT, action TEXT NOT NULL, target TEXT, ip TEXT, detail TEXT
    );
    CREATE TABLE IF NOT EXISTS admin_sessions (
      token_hash TEXT PRIMARY KEY,
      expires_at TIMESTAMPTZ NOT NULL
    );
    CREATE TABLE IF NOT EXISTS funding_ledger (
      id BIGSERIAL PRIMARY KEY,
      user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      tx_key TEXT NOT NULL,
      symbol TEXT, amount NUMERIC NOT NULL, at TIMESTAMPTZ NOT NULL,
      UNIQUE (user_id, tx_key)
    );
    CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT);
    CREATE TABLE IF NOT EXISTS profit_guard_log (
      id BIGSERIAL PRIMARY KEY, at TIMESTAMPTZ NOT NULL DEFAULT now(),
      symbol TEXT, side TEXT, mode TEXT, profile TEXT, event TEXT,
      entry NUMERIC, mark NUMERIC, old_sl NUMERIC, new_sl NUMERIC, peak_r NUMERIC, lock_pct NUMERIC, detail TEXT
    );
    CREATE INDEX IF NOT EXISTS profit_guard_log_at_idx ON profit_guard_log(at DESC);
    ALTER TABLE profit_guard_log ADD COLUMN IF NOT EXISTS result_r NUMERIC;
    CREATE TABLE IF NOT EXISTS pg_trades (
      id BIGSERIAL PRIMARY KEY, at TIMESTAMPTZ NOT NULL DEFAULT now(), symbol TEXT, side TEXT, profile TEXT, mode TEXT,
      entry NUMERIC, initial_sl NUMERIC, peak_price NUMERIC, exit_price NUMERIC, peak_pct NUMERIC, exit_pct NUMERIC, giveback_pct NUMERIC,
      peak_r NUMERIC, exit_r NUMERIC, guard_floor NUMERIC, scaled INT, pnl NUMERIC
    );
    -- when a user switches between a demo key and a live key, the results of the environment they leave are moved here
    -- (kept, never mixed into their current numbers or the admin totals)
    CREATE TABLE IF NOT EXISTS pnl_ledger_old (LIKE pnl_ledger);
    ALTER TABLE pnl_ledger_old ADD COLUMN IF NOT EXISTS env TEXT;
    ALTER TABLE pnl_ledger_old ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ NOT NULL DEFAULT now();
    CREATE TABLE IF NOT EXISTS funding_ledger_old (LIKE funding_ledger);
    ALTER TABLE funding_ledger_old ADD COLUMN IF NOT EXISTS env TEXT;
    ALTER TABLE funding_ledger_old ADD COLUMN IF NOT EXISTS archived_at TIMESTAMPTZ NOT NULL DEFAULT now();
    CREATE TABLE IF NOT EXISTS master_log (
      id BIGSERIAL PRIMARY KEY,
      exec_id TEXT NOT NULL, bot TEXT NOT NULL DEFAULT '', kind TEXT, symbol TEXT, side TEXT,
      ok BOOLEAN, code TEXT, detail TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
      UNIQUE (exec_id, bot)
    );
  `).then(() => console.log('[multiuser] ON. Database schema ready.'))
    .catch(e => { console.error('[multiuser] schema setup FAILED:', e.message); throw e; });

  // admin "pause all users": blocks NEW trades for every user (closes still go through). Stored in the meta table so it survives restarts.
  let pausedAll = false;
  let masterPlan = { ...PLAN_DEFAULT };
  let planVersion = null; // id of the plan_versions row the live plan came from (stamped on every order log row)
  let dryAll = false;     // admin 'dry run' switch: work out every user's trade, send nothing
  ready.then(async () => {
    // one-time: users that existed before per-user environments take the relay-wide environment they were trading in
    const m = await q(`INSERT INTO meta(k,v) VALUES('key_env_migrated','1') ON CONFLICT DO NOTHING RETURNING k`);
    if (m.rows[0] && DEFAULT_ENV === 'demo') await q(`UPDATE users SET key_env='demo'`);
  }).catch(e => console.error('[multiuser] key_env migration:', e.message));
  const globalReady = ready.then(async () => {
    const r = await q(`SELECT v FROM meta WHERE k='users_paused_all'`);
    pausedAll = !!(r.rows[0] && r.rows[0].v === '1');
    if (alertRouter) {                                   // the saved Telegram routing (group / DM / dev / off); defaults apply if nothing is saved or it cannot be read
      try { const ar = await q(`SELECT v FROM meta WHERE k='alert_routes'`); if (ar.rows[0]) alertRouter.state.cfg = alertRouter.route.normalize(JSON.parse(ar.rows[0].v)); }
      catch (e) { console.error('[multiuser] alert routes not loaded, using defaults:', e.message); }
    }
    try {                                                // Profit Guard: saved settings and the peaks/floors of trades that were open (so a restart forgets nothing)
      const pg = await q(`SELECT k, v FROM meta WHERE k IN ('profit_guard','profit_guard_state','profit_guard_watch')`);
      for (const row of pg.rows) {
        if (row.k === 'profit_guard') pgCfg = PG.normalize(JSON.parse(row.v));
        else if (row.k === 'profit_guard_watch') { const st = JSON.parse(row.v); for (const [k, v] of Object.entries(st || {})) pgWatch.set(k, v); }
        else { const st = JSON.parse(row.v); for (const [k, v] of Object.entries(st || {})) pgState.set(k, v); }
      }
    } catch (e) { console.error('[multiuser] profit guard settings not loaded, it stays off:', e.message); }
    const dr = await q(`SELECT v FROM meta WHERE k='dry_run_all'`);
    dryAll = !!(dr.rows[0] && dr.rows[0].v === '1');
    const mp = await q(`SELECT v FROM meta WHERE k='master_plan'`);
    let legacyPlan = null; // the plan as it was before Standard v1 (only needed by the one-time migration below)
    if (mp.rows[0]) {
      try {
        const stored = JSON.parse(mp.rows[0].v);
        legacyPlan = { ...LEGACY_PLAN, ...stored };
        const ok = parseControls(normalizeStoredPlan(stored), { current: PLAN_DEFAULT, allowed: CONTROL_KEYS.concat(['allowManual']) });
        if (!ok.error) masterPlan = { ...PLAN_DEFAULT, ...ok.values };
        else console.error('[multiuser] stored master plan is invalid, using defaults:', ok.error);
      } catch (e) { console.error('[multiuser] could not read master plan:', e.message); }
    }
    await migrateToStandardV1(legacyPlan || LEGACY_PLAN, !!mp.rows[0]);
    // plan history: the newest version is the live one; a fresh database (or one from before v1.4) gets a baseline row
    const lv = await q('SELECT id, plan FROM plan_versions ORDER BY id DESC LIMIT 1');
    if (lv.rows[0]) {
      planVersion = lv.rows[0].id;
      try { if (JSON.stringify(JSON.parse(lv.rows[0].plan)) !== JSON.stringify(masterPlan)) planVersion = await saveVersion('system', 'Plan loaded from settings', null); } catch { /* keep the id */ }
    } else planVersion = await saveVersion('system', 'Baseline', null);
  }).catch(e => { console.error('[multiuser] global state load failed:', e.message); });

  // ---------- Standard v1 migration (one time, safe to re-run: guarded by a meta flag) ----------
  // Old plan: "match" (copy the master's share of balance) x a multiplier. New: every account sizes from its own balance.
  //  - users that were on "match" become 10% x their multiplier (clamped 1-30) and get a one-time notice on their page
  //  - users already on fixed / percent keep exactly their amount
  //  - the stored plan moves to the Standard (20%, max 3 open, 10% daily loss, 30% drawdown, $500 cap); rails the admin had set are kept
  async function migrateToStandardV1(oldPlan, hadStoredPlan) {
    const done = await q(`SELECT 1 FROM meta WHERE k='std_v1_migrated'`);
    if (done.rows[0]) return;
    const users = (await q('SELECT * FROM users ORDER BY id')).rows;
    let converted = 0;
    for (const u of users) {
      const manual = u.control_mode === 'manual' && oldPlan.allowManual !== false;
      const mode = manual ? u.size_mode : oldPlan.sizeMode, mult = Number(manual ? u.size_mult : oldPlan.sizeMult) || 1;
      const usd = manual ? u.size_usd : oldPlan.sizeUsd, pct = manual ? u.size_pct : oldPlan.sizePct;
      const loss = manual ? u.daily_loss_limit_usd : oldPlan.dailyLossLimitUsd;
      if (mode === 'match') {
        const np = Math.min(STD.userPctMax, Math.max(1, Math.round(STD.legacyMatchPct * mult * 100) / 100));
        const text = 'Your trade size changed. Before, trades copied the master account\'s share of its balance. Now every trade uses a percent of YOUR own balance. Your new setting is ' + np + '% per trade. You can change it any time under Trade size.';
        await q(`UPDATE users SET size_mode='percent', size_pct=$2, size_usd=NULL, daily_loss_limit_usd=$3, control_mode='auto', notice=$4, notice_at=now() WHERE id=$1`, [u.id, np, loss, text]);
        converted++;
      } else {
        await q(`UPDATE users SET size_mode=$2, size_usd=$3, size_pct=$4, daily_loss_limit_usd=$5, control_mode='auto' WHERE id=$1`, [u.id, mode, usd, pct, loss]);
      }
    }
    // the plan itself
    const next = { ...PLAN_DEFAULT };
    if (hadStoredPlan) {
      const was = oldPlan;
      if (was.sizeMode === 'fixed' || was.sizeMode === 'percent') Object.assign(next, { sizeMode: was.sizeMode, sizeUsd: was.sizeUsd, sizePct: was.sizePct });
      for (const k of ['maxOpenTrades', 'symbols', 'direction', 'dailyLossLimitUsd', 'dailyProfitTargetUsd', 'drawdownStopPct']) if (was[k] !== null && was[k] !== undefined) next[k] = was[k];
      next.allowManual = true;
    }
    masterPlan = next;
    await q(`INSERT INTO meta(k,v) VALUES('master_plan',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(masterPlan)]);
    planVersion = await saveVersion('system', 'Standard v1 applied (' + converted + ' account(s) moved off "match" sizing)', null);
    await q(`INSERT INTO meta(k,v) VALUES('std_v1_migrated','1') ON CONFLICT DO NOTHING`);
    console.log('[multiuser] Standard v1 migration done: ' + users.length + ' account(s), ' + converted + ' converted from "match" sizing.');
  }

  async function saveVersion(by, summary, restoredFrom) {
    const r = await q('INSERT INTO plan_versions(plan,changed_by,summary,restored_from) VALUES($1,$2,$3,$4) RETURNING id', [JSON.stringify(masterPlan), by, String(summary || '').slice(0, 300), restoredFrom || null]);
    return r.rows[0].id;
  }
  const isDry = u => dryAll || !!u.dry_run;
  const PLAN_LABEL = { sizeMode: 'default amount mode', sizeUsd: 'default USD per trade', sizePct: 'default % of balance', maxOpenTrades: 'max open trades', symbols: 'coins', direction: 'direction',
    dailyLossLimitUsd: 'daily loss limit (USD)', dailyLossPct: 'daily loss limit (% of balance)', dailyProfitTargetUsd: 'daily profit target', drawdownStopPct: 'drawdown stop', maxTradeUsd: 'most any trade can use (USD)' };
  const showVal = v => (v === null || v === undefined ? 'none' : Array.isArray(v) ? v.map(x => x.replace('USDT', '')).join(',') : String(v));
  function planDiff(from, to) {
    return Object.keys(PLAN_LABEL).filter(k => JSON.stringify(from[k] === undefined ? null : from[k]) !== JSON.stringify(to[k] === undefined ? null : to[k]))
      .map(k => ({ key: k, label: PLAN_LABEL[k], from: from[k] === undefined ? null : from[k], to: to[k] === undefined ? null : to[k], text: PLAN_LABEL[k] + ' ' + showVal(from[k]) + ' → ' + showVal(to[k]) }));
  }

  // The settings that actually apply to a user's trades. Autopilot users follow the master plan. Manual users override only
  // their trade amount and loss limit; everything else (coins, direction, max open trades, leverage, profit target, drawdown stop) is always the plan.
  // Returns an object shaped like a users row, so the order code can read the usual columns.
  function effective(u) {
    const p = masterPlan;
    let mode = u.size_mode, pct = u.size_pct === null ? null : Number(u.size_pct), usd = u.size_usd === null ? null : Number(u.size_usd);
    if (mode === 'match') { mode = 'percent'; pct = Math.min(STD.userPctMax, Math.max(1, STD.legacyMatchPct * (Number(u.size_mult) > 0 ? Number(u.size_mult) : 1))); }
    if (mode === 'fixed' && !(usd > 0)) { mode = p.sizeMode === 'fixed' && p.sizeUsd > 0 ? 'fixed' : 'percent'; usd = p.sizeUsd; pct = pct > 0 ? pct : (p.sizePct || STD.pct); }
    if (mode === 'percent' && !(pct > 0)) pct = p.sizePct > 0 ? Number(p.sizePct) : STD.pct;
    return { ...u,
      control_mode: 'manual', // every account has its own settings now; kept so older screens keep working
      size_mode: mode, size_usd: usd, size_pct: pct,
      daily_loss_limit_usd: minPositive(u.daily_loss_limit_usd, p.dailyLossLimitUsd) || null, daily_loss_pct: p.dailyLossPct, // the admin's optional USD limit and the user's own both apply (the lower wins)
      max_trade_usd: minPositive(u.max_trade_usd, p.maxTradeUsd) || null,
      max_open_trades: p.maxOpenTrades, symbols_allow: p.symbols && p.symbols.length ? p.symbols.join(',') : null, direction: p.direction,
      user_max_lev: null, // leverage is always exactly what the signal says
      daily_profit_target_usd: p.dailyProfitTargetUsd, drawdown_stop_pct: p.drawdownStopPct };
  }
  const ownView = u => ({ sizeMode: u.size_mode, sizeMult: Number(u.size_mult), sizeUsd: u.size_usd === null ? null : Number(u.size_usd), sizePct: u.size_pct === null ? null : Number(u.size_pct),
    dailyLossLimitUsd: u.daily_loss_limit_usd === null ? null : Number(u.daily_loss_limit_usd) });

  // Express 4 does not catch errors thrown in async handlers; this wrapper makes every route fail cleanly instead of hanging.
  const h = fn => async (req, res, next) => {
    try { await fn(req, res, next); }
    catch (e) { console.error('[multiuser] route error', req.method, req.path, e.message); if (!res.headersSent) res.status(500).json({ success: false, message: 'Server error' }); }
  };

  async function audit(actor, action, target, req, detail) {
    try { await q('INSERT INTO audit_log(actor,action,target,ip,detail) VALUES($1,$2,$3,$4,$5)', [actor, action, target || null, (req && req.ip) || null, String(detail || '').slice(0, 300)]); }
    catch (e) { console.error('[multiuser] audit failed:', e.message); }
  }

  // ---------- Telegram (optional) ----------
  async function tgApi(method, body) {
    const r = await fetch('https://api.telegram.org/bot' + TG_TOKEN + '/' + method, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    return r.json();
  }
  async function tgSend(chatId, text) {
    if (!tgOn || !chatId) return false;
    try { const j = await tgApi('sendMessage', { chat_id: chatId, text }); if (!j.ok) console.error('[multiuser] telegram rejected message:', j.description); return !!j.ok; }
    catch (e) { console.error('[multiuser] telegram send failed:', e.message); return false; }
  }
  async function tgSendDoc(chatId, filename, content) {
    if (!tgOn || !chatId) return false;
    try {
      const fd = new FormData();
      fd.append('chat_id', String(chatId));
      fd.append('document', new Blob([content], { type: 'text/csv' }), filename);
      const r = await fetch('https://api.telegram.org/bot' + TG_TOKEN + '/sendDocument', { method: 'POST', body: fd });
      const j = await r.json();
      if (!j.ok) console.error('[multiuser] telegram rejected document:', j.description);
      return !!j.ok;
    } catch (e) { console.error('[multiuser] telegram document failed:', e.message); return false; }
  }
  const notify = (u, text) => { if (tgOn && u && u.tg_chat_id && u.tg_notify !== false) tgSend(u.tg_chat_id, (u.key_env === 'demo' ? '[DEMO] ' : '') + text).catch(() => {}); };
  let tgOffset = 0;
  async function tgPollOnce() {
    if (!tgOn) return;
    const j = await tgApi('getUpdates', { offset: tgOffset, timeout: 0, allowed_updates: ['message'] });
    if (!j.ok) return;
    for (const up of j.result || []) {
      tgOffset = up.update_id + 1;
      const m = up.message;
      if (!m || !m.text || !m.chat || m.chat.type !== 'private') continue;
      const code = (m.text.match(/\b[0-9A-Fa-f]{8}\b/) || [])[0];
      if (!code) { await tgSend(m.chat.id, 'To connect alerts, open your YM Oracle page, tap "Connect Telegram", and send me the 8-character code it shows.'); continue; }
      const r = await q('UPDATE users SET tg_chat_id=$2, tg_link_code=NULL, tg_link_expires=NULL WHERE tg_link_code=$1 AND tg_link_expires > now() RETURNING username', [code.toUpperCase(), String(m.chat.id)]);
      await tgSend(m.chat.id, r.rows[0] ? '✅ Connected. You will now get alerts for ' + r.rows[0].username + '.' : "That code isn't valid or has expired. Generate a new one on your page.");
    }
  }
  async function loadBotName() {
    if (!tgOn || tgBotUsername) return;
    try { const j = await tgApi('getMe'); if (j.ok) tgBotUsername = j.result.username || ''; } catch { /* optional */ }
  }

  // ---------- Bybit helpers ----------
  const userClient = u => {
    const { k, s } = JSON.parse(decrypt(u.key_enc, KEY));
    return new RestClientV5({ key: k, secret: s, ...envOpts(u.key_env) });
  };
  const bybitErr = r => { const e = new Error(r.retMsg || 'Bybit error'); e.retCode = r.retCode; return e; };

  async function getEquity(client) {
    const r = await client.getWalletBalance({ accountType: 'UNIFIED', coin: 'USDT' });
    if (r.retCode !== 0) throw bybitErr(r);
    const acct = (r.result.list || [])[0] || {};
    const c = (acct.coin || []).find(x => x.coin === 'USDT') || {};
    const equity = parseFloat(c.equity || c.walletBalance || 0);
    let available = parseFloat(acct.totalAvailableBalance);
    if (!Number.isFinite(available)) available = equity;
    return { equity, available };
  }
  async function getPositionState(client, symbol) {
    const r = await client.getPositionInfo({ category: 'linear', symbol });
    if (r.retCode !== 0) throw bybitErr(r);
    const list = r.result.list || [];
    const lev = parseFloat((list.find(p => parseFloat(p.size) > 0) || list[0] || {}).leverage);
    return { open: list.find(p => parseFloat(p.size) > 0) || null, leverage: lev > 0 ? lev : null };
  }
  async function getOpenPosition(client, symbol) { return (await getPositionState(client, symbol)).open; }
  async function listOpenPositions(client) {
    const out = [];
    let cursor;
    do {
      const r = await client.getPositionInfo({ category: 'linear', settleCoin: 'USDT', limit: 200, cursor });
      if (r.retCode !== 0) throw bybitErr(r);
      for (const p of (r.result.list || [])) if (parseFloat(p.size) > 0) out.push(p);
      cursor = r.result.nextPageCursor || undefined;
    } while (cursor);
    return out;
  }

  // Reads from the MASTER account / Bybit market data that every user's order depends on. A single failed read used to make
  // every user's copy of that trade fail with "could not read the master account"; now each read is tried up to 3 times, and if
  // Bybit stays unreachable a recent known value is used instead (equity up to 15 min old, an instrument's rules of any age).
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function withRetry(fn, tries) {
    let last;
    for (let i = 0; i < (tries || 3); i++) {
      try { return await fn(); } catch (e) { last = e; if (i < (tries || 3) - 1) await sleep(400 * (i + 1)); }
    }
    throw last;
  }
  let adminEq = { at: 0, v: null };
  // The master account's own Bybit key can be changed from the dashboard. It is stored encrypted (same AES-GCM key as users' keys)
  // in the meta table and overrides the BYBIT_API_KEY / BYBIT_API_SECRET environment variables until reset.
  const MASTER_META = 'master_creds';
  async function loadMasterCreds() {
    await ready;
    const r = await q(`SELECT v FROM meta WHERE k=$1`, [MASTER_META]);
    if (!r.rows[0]) return null;
    try { const o = JSON.parse(decrypt(r.rows[0].v, KEY)); return o && o.k && o.s ? o : null; } catch { return null; }
  }
  async function saveMasterCreds(o) {
    await ready;
    await q(`INSERT INTO meta(k,v) VALUES($1,$2) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [MASTER_META, encrypt(JSON.stringify({ k: o.k, s: o.s, env: normEnv(o.env) === 'demo' ? 'demo' : 'live', at: Date.now() }), KEY)]);
    adminEq = { at: 0, v: null };
    return { ok: true };
  }
  async function clearMasterCreds() {
    await ready;
    await q(`DELETE FROM meta WHERE k=$1`, [MASTER_META]);
    adminEq = { at: 0, v: null };
    return { ok: true };
  }
  async function getAdminEquity() {
    if (Date.now() - adminEq.at < 60000 && adminEq.v) return adminEq.v;
    try {
      const v = (await withRetry(() => getEquity(restClient))).equity;
      adminEq = { at: Date.now(), v };
      return v;
    } catch (e) {
      if (adminEq.v && Date.now() - adminEq.at < 15 * 60000) { console.warn('[multiuser] master equity unreadable, using the value from ' + Math.round((Date.now() - adminEq.at) / 1000) + 's ago'); return adminEq.v; }
      throw e;
    }
  }
  const instCache = new Map();
  async function getInstrument(symbol) {
    const hit = instCache.get(symbol);
    if (hit && Date.now() - hit.at < 600000) return hit.v;
    try {
      const r = await withRetry(() => restClient.getInstrumentsInfo({ category: 'linear', symbol }));
      if (r.retCode !== 0 || !(r.result.list || []).length) return null;
      const i = r.result.list[0];
      const v = { qtyStep: parseFloat(i.lotSizeFilter.qtyStep), minQty: parseFloat(i.lotSizeFilter.minOrderQty), status: i.status, tickSize: parseFloat((i.priceFilter || {}).tickSize) || 0 };
      instCache.set(symbol, { at: Date.now(), v });
      return v;
    } catch (e) {
      if (hit) { console.warn('[multiuser] instrument lookup failed for ' + symbol + ', using the cached rules'); return hit.v; }
      throw e;
    }
  }
  async function getRefPrice(symbol) {
    try { const r = await withRetry(() => restClient.getTickers({ category: 'linear', symbol }), 2); const p = parseFloat(r.result.list[0].lastPrice); return p > 0 ? p : null; }
    catch { return null; }
  }

  async function validateKey(apiKey, apiSecret, env) {
    env = normEnv(env);
    const opts = envOpts(env);
    const client = new RestClientV5({ key: apiKey, secret: apiSecret, ...opts });
    const warnings = [];
    let ipsUnrestricted = false;
    // demo keys, testnet and a fake base URL have no permission/IP restrictions worth checking
    if (env === 'live' && !opts.baseUrl && !opts.testnet) {
      const info = await client.getQueryApiKey();
      if (info.retCode !== 0) return { ok: false, message: 'Bybit rejected this key: ' + (info.retMsg || 'unknown error') };
      const problem = permissionProblem(info.result);
      if (problem) return { ok: false, message: problem };
      const ips = String(info.result.ips || '');
      ipsUnrestricted = !ips || ips.includes('*');
      if (ipsUnrestricted) warnings.push('This key is not IP-restricted. Strongly recommended: whitelist the server IP on the key.');
    }
    let eq;
    try { eq = await getEquity(client); } catch (e) { return { ok: false, message: 'Could not read the account balance with this key: ' + e.message + (env === 'demo' ? ' (Is this a Bybit DEMO-trading key? Create it while in Demo Trading mode.)' : ' (If this is a demo-trading key, choose Demo.)') }; }
    return { ok: true, equity: eq.equity, warnings, ipsUnrestricted };
  }

  // ---------- logging / alerts ----------
  async function logOrder(row) {
    await ready;
    try {
      const r = await q(
        `INSERT INTO order_log(user_id,kind,order_link_id,symbol,side,qty,code,ok,detail,bybit_order_id,plan_version,signal_key,risk_usd)
         VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT DO NOTHING RETURNING id`,
        [row.userId, row.kind, row.link || null, row.symbol || null, row.side || null, row.qty || null, row.code, row.ok, String(row.detail || '').slice(0, 300), row.bybitOrderId || null, planVersion, row.signalKey || null, row.riskUsd ?? null]);
      return r.rows[0] ? r.rows[0].id : null;
    } catch (e) { console.error('[multiuser] logOrder failed:', e.message); return null; }
  }
  async function markKeyError(u, detail) {
    const r = await q(`UPDATE users SET key_status='error', key_error=$2 WHERE id=$1 AND key_status<>'error' RETURNING username`, [u.id, String(detail || '').slice(0, 200)]);
    if (r.rows[0]) {
      if (sendAlert) sendAlert('⚠️ User ' + r.rows[0].username + ': Bybit API key stopped working (' + detail + '). Their trading is paused until it is fixed.');
      notify(u, '⚠️ Your Bybit API key stopped working (' + String(detail || '').slice(0, 80) + '). Trading on your account is off until you replace the key on your page.');
      await audit('system', 'key_error', u.username, null, detail);
    }
  }

  // ---------- fan-out ----------
  const queues = new Map(); // per-user serial queue so leverage -> order -> stops never overlap or reorder
  function enqueue(userId, fn) {
    const prev = queues.get(userId) || Promise.resolve();
    const next = prev.catch(() => {}).then(fn);
    queues.set(userId, next);
    next.finally(() => { if (queues.get(userId) === next) queues.delete(userId); }).catch(() => {});
    return next;
  }
  async function runLimited(items, limit, fn) {
    for (let i = 0; i < items.length; i += limit) await Promise.allSettled(items.slice(i, i + limit).map(fn));
  }
  async function tradableUsers({ forOpen }) {
    await ready; await globalReady;
    if (forOpen && pausedAll) return [];
    const r = await q(`SELECT * FROM users WHERE active AND key_enc IS NOT NULL AND key_status='ok' ${forOpen ? 'AND NOT paused' : ''} ORDER BY id`);
    return r.rows;
  }
  async function todaysPnl(userId) {
    const r = await q(`SELECT COALESCE(SUM(closed_pnl),0) AS p FROM pnl_ledger WHERE user_id=$1 AND closed_at >= (date_trunc('day', now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC')`, [userId]);
    return Number(r.rows[0].p);
  }
  function failFrom(e) {
    if (e && e.retCode !== undefined) return { code: classifyRet(e.retCode), detail: e.message, auth: AUTH_RET_CODES.has(e.retCode) };
    return { code: 'NET', detail: (e && e.message) || 'network error', auth: false };
  }
  async function recordFill(client, rowId, link, side, ref) {
    try {
      const r = await client.getHistoricOrders({ category: 'linear', orderLinkId: link, limit: 1 });
      const o = ((r.result && r.result.list) || [])[0];
      const fill = o ? parseFloat(o.avgPrice) : NaN;
      if (!(fill > 0)) return;
      const bps = ref > 0 ? ((fill - ref) / ref) * 10000 * (side === 'Buy' ? 1 : -1) : null; // positive = the user paid more than the reference
      await q('UPDATE order_log SET fill_price=$2, ref_price=$3, slippage_bps=$4 WHERE id=$1', [rowId, fill, ref > 0 ? ref : null, bps]);
    } catch { /* slippage tracking is best-effort */ }
  }

  async function orderForUser(u, o, ctx) {
    u = effective(u); // autopilot users get the master plan; manual users only override amount + loss limit
    const link = ('u' + u.id + '-' + sha1(ctx.signalKey)).slice(0, 36);
    const base = { userId: u.id, kind: 'ORDER', link: null, symbol: o.symbol, side: o.side, signalKey: ctx.signalKeyRaw || null };
    const finish = async (code, ok, detail, extra) => {
      const id = await logOrder({ ...base, ...(extra || {}), code, ok, detail });
      const friendly = code === 'MINQ' || code === 'BAL' || (code === 'HALT' && detail !== 'Global halt is on'); // these carry a specific, user-readable explanation
      if (!ok && !QUIET_CODES.has(code)) notify(u, '⚠️ ' + o.symbol.replace('USDT', '') + ': ' + (friendly ? detail : (CODE_TEXT[code] || detail)));
      return id;
    };
    if (breakerIsTripped()) return finish('HALT', false, 'Global halt is on');
    if (ctx.mode === 'paper') return finish('PAPER', true, 'Paper mode, nothing sent');
    try {
      const client = userClient(u);
      let qty;
      if (ctx.reduceOnly) {
        const pos = await getOpenPosition(client, o.symbol);
        if (!pos) return finish('NOPOS', true, 'No open position to close');
        const closes = (pos.side === 'Buy' && o.side === 'Sell') || (pos.side === 'Sell' && o.side === 'Buy');
        if (!closes) return finish('SIDE', false, 'Their position is on the other side');
        qty = pos.size;
      } else {
        // the user's own filters (no Bybit call needed)
        const isLong = o.side === 'Buy';
        if ((u.direction === 'long' && !isLong) || (u.direction === 'short' && isLong)) return finish('FILT', true, 'Skipped: you only copy ' + u.direction + ' trades');
        if (u.symbols_allow) {
          const allowed = String(u.symbols_allow).split(',').filter(Boolean);
          if (allowed.length && !allowed.includes(o.symbol)) return finish('FILT', true, 'Skipped: ' + o.symbol.replace('USDT', '') + ' is not in your coin list');
        }
        const pstate = await getPositionState(client, o.symbol);
        if (pstate.open) return finish('HELD', false, 'Already holding this pair');
        if (u.max_open_trades > 0) {
          const open = await listOpenPositions(client);
          if (open.length >= u.max_open_trades) return finish('MAXT', true, 'Skipped: you already have ' + open.length + ' open trade(s) and the limit is ' + u.max_open_trades + '. This protects your balance');
        }
        if (u.daily_loss_limit_usd !== null && Number(u.daily_loss_limit_usd) > 0 || u.daily_profit_target_usd !== null && Number(u.daily_profit_target_usd) > 0) {
          const today = await todaysPnl(u.id);
          if (u.daily_loss_limit_usd !== null && Number(u.daily_loss_limit_usd) > 0 && today <= -Number(u.daily_loss_limit_usd)) return finish('HALT', false, 'Daily loss limit reached: you are down $' + (-today).toFixed(2) + ' today. New trades start again tomorrow');
          if (u.daily_profit_target_usd !== null && Number(u.daily_profit_target_usd) > 0 && today >= Number(u.daily_profit_target_usd)) return finish('HALT', true, 'Daily profit target reached (+' + today.toFixed(2) + ' USD today). New trades resume tomorrow');
        }
        if (!ctx.inst) return finish('PAIR', false, 'Pair not tradable');
        const bal = await getEquity(client);
        // drawdown stop: remember the highest balance we have seen, and pause the user if they fall too far below it
        const peak = Math.max(Number(u.equity_peak) || 0, bal.equity);
        if (peak !== Number(u.equity_peak)) await q('UPDATE users SET equity_peak=$2 WHERE id=$1', [u.id, peak]);
        if (u.drawdown_stop_pct !== null && Number(u.drawdown_stop_pct) > 0 && peak > 0 && bal.equity <= peak * (1 - Number(u.drawdown_stop_pct) / 100)) {
          await q('UPDATE users SET paused=TRUE WHERE id=$1', [u.id]);
          return finish('HALT', false, 'Drawdown stop hit: your balance is ' + (((peak - bal.equity) / peak) * 100).toFixed(1) + '% below its peak (limit ' + Number(u.drawdown_stop_pct) + '%). Trading is paused until you resume it on your page');
        }
        // daily loss limit as a share of the balance the day started with (the admin's USD limit, if any, still applies above)
        if (Number(u.daily_loss_pct) > 0) {
          const today = await todaysPnl(u.id);
          if (today < 0) {
            const sn = await q(`SELECT equity FROM equity_snap WHERE user_id=$1 AND day=(now() AT TIME ZONE 'UTC')::date`, [u.id]);
            const opening = sn.rows[0] ? Number(sn.rows[0].equity) : bal.equity - today;
            const limit = opening * Number(u.daily_loss_pct) / 100;
            if (opening > 0 && -today >= limit) return finish('HALT', false, 'Daily loss limit reached: you are down $' + (-today).toFixed(2) + ' today (limit ' + Number(u.daily_loss_pct) + '% of the $' + opening.toFixed(2) + ' you started the day with). New trades start again tomorrow');
          }
        }
        const levCap = minPositive(MAX_USER_LEVERAGE, u.max_lev_ceiling, u.user_max_lev);
        const lev = pstate.leverage && levCap ? Math.min(pstate.leverage, levCap) : pstate.leverage;
        const s = sizeForUser({ mode: u.size_mode, adminQty: o.qty, adminEquity: ctx.adminEquity, userEquity: bal.equity, available: bal.available, mult: u.size_mult,
          sizeUsd: u.size_usd, sizePct: u.size_pct, maxTradeUsd: u.max_trade_usd, leverage: lev, price: ctx.refPrice,
          qtyStep: ctx.inst.qtyStep, minQty: ctx.inst.minQty, maxRatio: MAX_RATIO });
        if (!s.qty) return finish(s.code, false, s.detail);
        qty = s.qty;
        // what this trade would lose if the signal's stop is hit (an estimate from the market price at signal time)
        const stopPx = Number(o.stopLoss);
        if (stopPx > 0 && ctx.refPrice > 0) base.riskUsd = Math.round(qty * Math.abs(ctx.refPrice - stopPx) * 100) / 100;
        await q('UPDATE users SET last_equity=$2 WHERE id=$1', [u.id, bal.equity]);
        // dry run: everything above ran for real (filters, limits, sizing); stop here and only record what would have been sent
        if (isDry(u)) return finish('DRY', true, 'Dry run: would ' + (o.side === 'Buy' ? 'buy' : 'sell') + ' ' + qty + ' ' + o.symbol.replace('USDT', '') + (lev ? ' at ' + lev + 'x' : '') + (ctx.refPrice ? ' (about $' + (qty * ctx.refPrice / (lev || 1)).toFixed(2) + ' margin)' : ''), { link: 'dry-' + link, qty });
      }
      // claim the idempotency slot BEFORE sending, so a retransmitted signal can never double-trade this user
      const claimed = await logOrder({ ...base, link, qty, code: 'PENDING', ok: false, detail: 'Sending' });
      if (!claimed) return;
      const orderBody = { ...o, qty: String(qty), orderLinkId: link };
      let res;
      // a dropped connection says nothing about whether Bybit got it; the same orderLinkId makes every retry safe (a duplicate is refused)
      for (let attempt = 0; ; attempt++) {
        try { res = await client.submitOrder(orderBody); break; }
        catch (e1) { if (attempt >= 2) throw e1; await sleep(500 * (attempt + 1)); }
      }
      if (res.retCode === 110072) res = { ...res, retCode: 0, result: res.result || {} }; // duplicate = our earlier try did land
      if (res.retCode === 0) {
        await q(`UPDATE order_log SET code='OK', ok=true, detail='Placed', bybit_order_id=$2 WHERE id=$1`, [claimed, (res.result && res.result.orderId) || null]);
        if (!ctx.reduceOnly) {
          notify(u, '✅ Opened ' + o.symbol.replace('USDT', '') + ' ' + (o.side === 'Buy' ? 'long' : 'short') + ' (' + qty + ')');
          const t = setTimeout(() => recordFill(client, claimed, link, o.side, ctx.refPrice), 3000);
          if (t.unref) t.unref();
        }
      } else {
        const f = failFrom({ retCode: res.retCode, message: res.retMsg });
        await q(`UPDATE order_log SET code=$2, ok=false, detail=$3 WHERE id=$1`, [claimed, f.code, res.retMsg]);
        if (f.auth) await markKeyError(u, res.retMsg); else notify(u, '⚠️ ' + o.symbol.replace('USDT', '') + ': ' + (CODE_TEXT[f.code] || res.retMsg));
      }
    } catch (e) {
      const f = failFrom(e);
      await logOrder({ ...base, code: f.code, ok: false, detail: f.detail });
      if (f.auth) await markKeyError(u, f.detail);
    }
  }

  async function fanOutOrder(body) {
    const o = sanitizeOrder(body);
    if (!o) { console.warn('[multiuser] fan-out skipped: order failed validation'); return; }
    const reduceOnly = o.reduceOnly === true;
    await markOrderSeen(body && body.orderLinkId).catch(() => {});   // the bot's signal reached the relay: stops the "never arrived" alarm
    const users = await tradableUsers({ forOpen: !reduceOnly }); // pause stops NEW trades only; closes always go through
    if (!users.length) return;
    const mode = getMode();
    const minute = Math.floor(Date.now() / 60000);
    const signalKey = (body && body.orderLinkId) || [o.symbol, o.side, o.qty, reduceOnly, minute].join('|');
    const ctx = { mode, reduceOnly, signalKey, signalKeyRaw: (body && typeof body.orderLinkId === 'string' && body.orderLinkId.slice(0, 40)) || null, adminEquity: null, inst: null, refPrice: null };
    if (mode === 'live' && !reduceOnly) {
      let sizingErr = null;
      try { ctx.adminEquity = await getAdminEquity(); ctx.inst = await getInstrument(o.symbol); }
      catch (e) { sizingErr = e; console.error('[multiuser] could not size order (admin equity / instrument):', e.message); }
      if (!ctx.adminEquity || (sizingErr && !ctx.inst)) {
        await Promise.allSettled(users.map(u => logOrder({ userId: u.id, kind: 'ORDER', symbol: o.symbol, side: o.side, code: 'NET', ok: false, detail: 'Could not read the master account to size this order' })));
        return;
      }
      ctx.refPrice = await getRefPrice(o.symbol);
    }
    await runLimited(users, 5, u => enqueue(u.id, () => orderForUser(u, o, ctx)));
  }

  async function fanOutTradingStop(body) {
    const st = sanitizeStop(body);
    if (!st || getMode() === 'paper' || breakerIsTripped()) return;
    const users = await tradableUsers({ forOpen: false });
    await runLimited(users, 5, u => enqueue(u.id, async () => {
      if (isDry(u)) return;
      const base = { userId: u.id, kind: 'SLTP', symbol: st.symbol };
      try {
        const client = userClient(u);
        const pos = await getOpenPosition(client, st.symbol);
        if (!pos) return;
        const res = await client.setTradingStop({ category: 'linear', ...st });
        if (res.retCode === 0 || res.retCode === 34040) return logOrder({ ...base, side: pos.side, code: 'OK', ok: true, detail: 'Stops updated' });
        const f = failFrom({ retCode: res.retCode, message: res.retMsg });
        await logOrder({ ...base, side: pos.side, code: f.code, ok: false, detail: res.retMsg });
        if (f.auth) await markKeyError(u, res.retMsg);
      } catch (e) {
        const f = failFrom(e);
        await logOrder({ ...base, code: f.code, ok: false, detail: f.detail });
        if (f.auth) await markKeyError(u, f.detail);
      }
    }));
  }

  // Closes every open USDT position (and cancels resting orders) on one user's account. Used by the user's own
  // "close all" button, "pause and close everything", and the admin's emergency close-all.
  async function closeAllForUser(u, why) {
    const out = { closed: 0, failed: 0, error: null };
    try {
      const client = userClient(u);
      const positions = await listOpenPositions(client);
      try { await client.cancelAllOrders({ category: 'linear', settleCoin: 'USDT' }); } catch { /* best effort */ }
      for (const p of positions) {
        const side = p.side === 'Buy' ? 'Sell' : 'Buy';
        try {
          const res = await client.submitOrder({ category: 'linear', symbol: p.symbol, side, orderType: 'Market', qty: String(p.size), reduceOnly: true, positionIdx: Number(p.positionIdx) || 0 });
          if (res.retCode === 0) { out.closed++; await logOrder({ userId: u.id, kind: 'CLOSE', symbol: p.symbol, side, qty: Number(p.size), code: 'OK', ok: true, detail: 'Closed: ' + why }); }
          else { out.failed++; await logOrder({ userId: u.id, kind: 'CLOSE', symbol: p.symbol, side, code: classifyRet(res.retCode), ok: false, detail: res.retMsg }); }
        } catch (e) { out.failed++; await logOrder({ userId: u.id, kind: 'CLOSE', symbol: p.symbol, side, code: failFrom(e).code, ok: false, detail: e.message }); }
      }
    } catch (e) { out.error = e.message; out.failed++; if (failFrom(e).auth) await markKeyError(u, e.message); }
    return out;
  }

  async function fanOutLeverage(body) {
    if (!sanitizeLeverage(body, 0) || getMode() === 'paper' || breakerIsTripped()) return;
    const users = await tradableUsers({ forOpen: true });
    await runLimited(users, 5, u => enqueue(u.id, async () => {
      // each user's leverage is capped by the global cap, the admin's ceiling for them, and their own setting (lowest wins)
      if (isDry(u)) return; // dry run never touches an account
      const lv = sanitizeLeverage(body, minPositive(MAX_USER_LEVERAGE, u.max_lev_ceiling, effective(u).user_max_lev));
      const base = { userId: u.id, kind: 'LEV', symbol: lv.symbol };
      try {
        const res = await userClient(u).setLeverage(lv);
        if (res.retCode === 0 || res.retCode === 110043) return;
        const f = failFrom({ retCode: res.retCode, message: res.retMsg });
        await logOrder({ ...base, code: 'LEV', ok: false, detail: res.retMsg });
        if (f.auth) await markKeyError(u, res.retMsg);
      } catch (e) {
        const f = failFrom(e);
        await logOrder({ ...base, code: f.code, ok: false, detail: f.detail });
        if (f.auth) await markKeyError(u, f.detail);
      }
    }));
  }

  // ---------- master account journal + interrupted-order recovery (v1.6) ----------
  // What the manager reported for each signal on the MASTER account. Kept in the database (the relay's own files are wiped
  // by a Render restart), so "why did nothing happen for that trade" can always be answered afterwards.
  async function recordExec(rec) {
    await ready;
    await q(`INSERT INTO master_log(exec_id,bot,kind,symbol,side,ok,code,detail) VALUES($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (exec_id, bot) DO UPDATE SET ok=EXCLUDED.ok, code=EXCLUDED.code, detail=EXCLUDED.detail, created_at=now()`,
      [rec.id, rec.bot || '', rec.kind, rec.symbol, rec.side, rec.ok === true, rec.code, rec.detail]);
    await markOrderSeen('ym-' + rec.id).catch(() => {});
  }

  // ---------- master account sizing (v3, OFF by default) ----------
  // Until now the master account traded whatever margin the bot/manager asked for ($100), while every user was sized from their own
  // balance. With MASTER_FOLLOWS_PLAN=true the relay sizes the master's open orders with the SAME rule as everyone else (balance x plan
  // percent, capped, at the leverage already set for the pair). The manager keeps working unchanged: it just sends its usual order and the
  // relay replaces the quantity. If anything can't be worked out the manager's own quantity is used, so a trade is never lost to this.
  const masterFollows = () => process.env.MASTER_FOLLOWS_PLAN === 'true';
  async function sizeMasterOrder(body) {
    if (!masterFollows()) return null;
    const o = sanitizeOrder(body);
    if (!o || o.reduceOnly === true || getMode() !== 'live') return null;
    try {
      const [bal, inst, ref, ps] = await Promise.all([withRetry(() => getEquity(restClient)), getInstrument(o.symbol), getRefPrice(o.symbol), getPositionState(restClient, o.symbol)]);
      if (!inst || ps.open || !ps.leverage) return null;   // unknown pair / already holding it: the normal rules handle it
      const sz = sizeForUser({ mode: masterPlan.sizeMode, sizePct: masterPlan.sizePct, sizeUsd: masterPlan.sizeUsd, maxTradeUsd: masterPlan.maxTradeUsd, leverage: ps.leverage, price: ref,
        userEquity: bal.equity, available: bal.available, qtyStep: inst.qtyStep, minQty: inst.minQty });
      if (!sz.qty) return { skipped: sz.code, detail: sz.detail };
      return { qty: sz.qty, marginUsd: sz.marginUsd, leverage: ps.leverage, from: Number(o.qty) };
    } catch (e) { console.warn('[multiuser] master sizing skipped:', e.message); return null; }
  }

  // ---------- signal ledger (v2): what each bot says it did, matched to what actually reached the relay ----------
  // Every bot posts open / relay / close / status events to /api/bot-event (firmware 'WEBLEDGER'). They are stored by the bot's own key
  // `k`, so a retransmit (the bots resend until they get a 2xx) can never create a second row or change an earlier one.
  let lastBotTestAt = 0;
  const KEY_RE = /^[\w.\-]{1,60}$/;
  const clip = (v, n) => String(v === undefined || v === null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').slice(0, n);
  const numOr = v => (v === null || v === undefined || v === '' || !Number.isFinite(Number(v)) ? null : Number(v));
  const sideOf = v => (String(v).toUpperCase() === 'BUY' ? 'BUY' : String(v).toUpperCase() === 'SELL' ? 'SELL' : null);
  async function markOrderSeen(orderLinkId) {
    if (typeof orderLinkId !== 'string') return;
    const rid = orderLinkId.replace(/^ym-/, '');
    if (!rid) return;
    await ready;
    await q(`UPDATE signals SET order_seen_at=now() WHERE rid=$1 AND order_seen_at IS NULL`, [rid]);
  }
  async function recordBotEvent(b) {
    await ready;
    if (!b || typeof b !== 'object' || Number(b.v) !== 1) return { status: 400, message: 'unsupported event' };
    const bot = clip(b.bot, 30);
    if (!bot) return { status: 400, message: 'bot is required' };
    const ev = String(b.ev || '');
    // Abuse guard: while DEVICE_KEY_MODE is 'warn' anyone who knows the URL can post here, so alerts and new ledger rows are capped. A bot that is capped
    // gets a 429, which it treats as "try again later" (it keeps the report), so a real alert is delayed, never lost.
    if (ev === 'msg') {
      const rc = await q(`SELECT COUNT(*) FILTER (WHERE bot=$1)::int AS mine, COUNT(*)::int AS total FROM bot_msgs WHERE created_at > now() - interval '10 minutes'`, [bot]);
      if (rc.rows[0].mine >= 40 || rc.rows[0].total >= 120) return { status: 429, message: 'too many alerts, try again shortly' };
    }
    if (ev === 'test') {
      if (Date.now() - lastBotTestAt < 15000) return { status: 429, message: 'one test at a time' };
      lastBotTestAt = Date.now();
    }
    if (ev === 'test') { // the "test alert" button on a bot: proves bot -> relay -> Telegram/email works end to end
      const r = await deliverAlert('✅ Test alert from ' + bot.replace('YM ORACLE ', 'Oracle ') + '. The bot reached Render and Render can reach you. Trade alerts will arrive the same way.', { cat: 'tests' });
      return { status: 200, message: r.muted ? 'delivered (muted by the alert settings: ' + (r.reason || 'see the console') + ')' : r.ok ? 'delivered' : (r.configured === false ? 'alerts are not configured on Render' : 'delivery failed') };
    }
    if (ev === 'msg') { // an alert the bot composed itself (zone found, trade management, daily summary, the full entry/result text): stored first, then delivered with retries
      const k = String(b.k || '');
      if (!KEY_RE.test(k)) return { status: 400, message: 'bad key' };
      const text = String(b.text === undefined || b.text === null ? '' : b.text).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, ' ').slice(0, 3800);
      if (!text.trim()) return { status: 400, message: 'empty message' };
      const kind = ['entry', 'result', 'daily', 'zone', 'mgmt', 'ops', 'other'].includes(b.kind) ? b.kind : 'other';
      const sym = String(b.sym || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 20) || null;
      await q(`INSERT INTO bot_msgs(k,bot,kind,sym,priv,text) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT (k) DO NOTHING`, [k, bot, kind, sym, b.priv === true || b.priv === 1, text]);
      pushBotMsgs().then(() => (kind === 'entry' || kind === 'result') ? pushSignalAlerts() : 0).catch(e => console.error('[multiuser] bot msg:', e.message));
      return { status: 200 };
    }
    if (ev === 'status') {
      await q(`INSERT INTO bot_status(bot,payload,at) VALUES($1,$2,now()) ON CONFLICT (bot) DO UPDATE SET payload=EXCLUDED.payload, at=now()`, [bot, JSON.stringify(b).slice(0, 4000)]);
      return { status: 200 };
    }
    if (!['open', 'relay', 'close'].includes(ev)) return { status: 400, message: 'unknown event' };
    const k = String(b.k || '');
    if (!KEY_RE.test(k)) return { status: 400, message: 'bad key' };
    const sym = String(b.sym || '').toUpperCase();
    if (sym && !SYMBOL_RE.test(sym)) return { status: 400, message: 'bad symbol' };
    const side = sideOf(b.side), eng = ['fast', 'swing'].includes(b.eng) ? b.eng : null;
    const known = await q(`SELECT 1 FROM signals WHERE k=$1`, [k]);
    if (!known.rows[0]) {                                               // a brand-new ledger row: cap how many can appear in a short time
      const nr = await q(`SELECT COUNT(*)::int AS n FROM signals WHERE opened_at > now() - interval '10 minutes'`);
      if (nr.rows[0].n >= 200) return { status: 429, message: 'too many new signals, try again shortly' };
    }
    // make sure the row exists (events can arrive out of order: a close before its open, etc.)
    await q(`INSERT INTO signals(k,bot,symbol,side,eng,bot_t) VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT (k) DO NOTHING`, [k, bot, sym || null, side, eng, numOr(b.t)]);
    if (ev === 'open') {
      const rid = clip(b.rid, 16);
      await q(`UPDATE signals SET symbol=COALESCE(symbol,$2), side=COALESCE(side,$3), eng=COALESCE(eng,$4), entry=COALESCE(entry,$5), sl=COALESCE(sl,$6), tp=COALESCE(tp,$7),
          lev=COALESCE(lev,$8), margin=COALESCE(margin,$9), relay_flag=COALESCE(relay_flag,$10), rid=COALESCE(NULLIF(rid,''),$11), bot_t=COALESCE(bot_t,$12), updated_at=now() WHERE k=$1`,
        [k, sym || null, side, eng, numOr(b.entry), numOr(b.sl), numOr(b.tp), numOr(b.lev), numOr(b.m), ['SENT', 'NOT_SENT'].includes(b.relay) ? b.relay : null, rid || null, numOr(b.t)]);
      // the order may have reached the relay before this (late) report did: then there is nothing to alarm about
      if (rid) await q(`UPDATE signals SET order_seen_at=now() WHERE k=$1 AND order_seen_at IS NULL AND (
          EXISTS (SELECT 1 FROM master_log WHERE exec_id=$2) OR EXISTS (SELECT 1 FROM order_log WHERE signal_key=$3))`, [k, rid, 'ym-' + rid]);
    } else if (ev === 'relay') {
      const rid = clip(b.rid, 16);
      await q(`UPDATE signals SET relay_ok=COALESCE(relay_ok,$2), relay_code=COALESCE(relay_code,$3), relay_secs=COALESCE(relay_secs,$4), relay_at=COALESCE(relay_at,now()),
          rid=COALESCE(NULLIF(rid,''),$5), updated_at=now() WHERE k=$1`, [k, b.ok === true, clip(b.code, 12) || null, numOr(b.secs), rid || null]);
    } else {
      await q(`UPDATE signals SET closed_at=COALESCE(closed_at,now()), won=COALESCE(won,$2), exit_price=COALESCE(exit_price,$3), pct=COALESCE(pct,$4), relayed=COALESCE(relayed,$5),
          close_why=COALESCE(close_why,$6), updated_at=now() WHERE k=$1`, [k, b.won === true, numOr(b.exit), numOr(b.pct), b.relayed === true, clip(b.why, 64) || null]);
    }
    if (ev === 'open' || ev === 'close') pushSignalAlerts().catch(e => console.error('[multiuser] trade alert:', e.message));
    return { status: 200 };
  }

  // ---------- trade alerts pushed from here (so the bots no longer need their own email/Telegram for trades) ----------
  // One message when a bot opens a trade and one when it closes it, each sent once: the row is claimed first, and given back if every channel
  // failed so the 20-second sweep tries again (up to 8 times). Only recent signals are considered, so a restart never replays old trades.
  const tradeAlertsOn = () => String(process.env.TRADE_ALERTS || '').toLowerCase() !== 'off';
  const coinOf = x => String(x.symbol || '').replace('USDT', '');
  const whoOf = x => String(x.bot || '').replace('YM ORACLE ', 'Oracle ');
  const fnum = v => (v === null || v === undefined ? '?' : String(Number(Number(v).toPrecision(6))));
  function openAlertText(x) {
    const dir = x.side === 'BUY' ? 'LONG' : 'SHORT', head = whoOf(x) + ' ' + coinOf(x) + ' ' + dir + (x.eng ? ' (' + x.eng + ')' : '');
    const lines = [(x.relay_flag === 'NOT_SENT' ? '⚠️ ' : '🟢 ') + head + ' opened', 'Entry ' + fnum(x.entry) + ' · SL ' + fnum(x.sl) + ' · TP ' + fnum(x.tp) + (x.lev ? ' · ' + fnum(x.lev) + 'x' : '') + (x.margin ? ' · $' + fnum(x.margin) + ' margin' : '')];
    lines.push(x.relay_flag === 'NOT_SENT' ? 'The bot did NOT send this one to Bybit (relay switch off or not sent). No copy trades.' : 'Sent to the relay for Bybit and your users.');
    return lines.join('\n');
  }
  function closeAlertText(x) {
    const dir = x.side === 'BUY' ? 'long' : 'short', pct = x.pct === null || x.pct === undefined ? '' : ' ' + (Number(x.pct) >= 0 ? '+' : '') + Number(x.pct).toFixed(2) + '%';
    return (x.won ? '✅ ' : '🔴 ') + whoOf(x) + ' ' + coinOf(x) + ' ' + dir + ' closed: ' + (x.won ? 'WIN' : 'LOSS') + pct + (x.close_why ? ' (' + x.close_why + ')' : '') + (x.relayed === false ? '\nThis trade was not relayed, so nothing was closed on Bybit.' : '');
  }
  const stripTags = t => String(t).replace(/<[^>]*>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
  const symKey = v => String(v || '').toUpperCase().replace(/USDT$/, '').replace(/[^A-Z0-9]/g, '');
  const HOLD_S = () => (process.env.TRADE_ALERT_HOLD_S !== undefined && Number.isFinite(Number(process.env.TRADE_ALERT_HOLD_S)) ? Number(process.env.TRADE_ALERT_HOLD_S) : 45);
  // Alerts the bot composed itself. Stored on arrival (the bot gets its 200 at once and drops its copy), then delivered here, retried up to 8 times.
  // Which alert category a bot message belongs to (the firmware tags entry/result/zone/mgmt/daily/ops; an untagged one from older firmware is guessed from where it was addressed).
  const catOfMsg = m => (m.kind === 'entry' || m.kind === 'result') ? 'signals' : m.kind === 'zone' ? 'zones' : m.kind === 'daily' ? 'daily' : m.kind === 'mgmt' ? 'updates' : m.kind === 'ops' ? 'ops'
    : m.priv ? (/zone/i.test(stripTags(m.text)) ? 'zones' : 'ops') : 'updates';
  async function pushBotMsgs() {
    if (!tradeAlertsOn()) return 0;
    await ready;
    let sent = 0;
    const r = await q(`SELECT k FROM bot_msgs WHERE sent_at IS NULL AND tries < 8 AND created_at > now() - interval '2 hours' ORDER BY created_at LIMIT 10`);
    for (const row of r.rows) {
      const c = await q(`UPDATE bot_msgs SET claimed_at=now() WHERE k=$1 AND sent_at IS NULL AND (claimed_at IS NULL OR claimed_at < now() - interval '40 seconds') RETURNING *`, [row.k]);
      const m = c.rows[0]; if (!m) continue;
      let res; try { res = await deliverAlert(m.text, { html: true, priv: m.priv, email: m.kind === 'daily', cat: catOfMsg(m) }); } catch (e) { res = { ok: false, configured: true }; }
      if (res && res.ok) { sent++; await q(`UPDATE bot_msgs SET sent_at=now(), last_result=$2 WHERE k=$1`, [m.k, [res.telegram && 'telegram ' + res.telegram, res.email && res.email !== 'off' && 'email ' + res.email].filter(Boolean).join(', ')]); continue; }
      const cfgd = !(res && res.configured === false);
      await q(`UPDATE bot_msgs SET claimed_at=NULL, tries=tries+$2, last_result=$3 WHERE k=$1`, [m.k, cfgd ? 1 : 0, res ? [res.telegram, res.email].filter(x => x && x !== 'off').join(', ') || 'not configured' : 'failed']);
      if (!cfgd) return sent;
    }
    return sent;
  }
  const alertSweep = () => pushBotMsgs().then(() => pushSignalAlerts());   // run every 20 s: retries failed deliveries, sends the short safety-net alerts
  async function pushSignalAlerts() {
    if (!tradeAlertsOn()) return 0;
    await ready;
    let sent = 0;
    for (const [col, kind] of [['alert_open_at', 'open'], ['alert_close_at', 'close']]) {
      const cond = kind === 'open' ? 'relay_flag IS NOT NULL' : 'closed_at IS NOT NULL';
      const r = await q(`SELECT k, bot, symbol, opened_at, closed_at FROM signals WHERE ${cond} AND ${col} IS NULL AND alert_tries < 8 AND opened_at > now() - interval '2 hours' ORDER BY opened_at LIMIT 10`);
      for (const row of r.rows) {
        // A bot running the new firmware also sends its own detailed text for the same trade. When that arrives, the short ledger alert is not sent as well.
        // If the bot is new-firmware but its detailed text has not arrived yet, the ledger alert waits TRADE_ALERT_HOLD_S seconds, then goes out as the safety net.
        const msgKind = kind === 'open' ? 'entry' : 'result';
        const since = kind === 'open' ? row.opened_at : row.closed_at;
        const m = await q(`SELECT sym, created_at >= $3::timestamptz - interval '3 minutes' AS fresh FROM bot_msgs WHERE bot=$1 AND kind=$2 AND created_at > now() - interval '2 hours'`, [row.bot, msgKind, since]);
        if (m.rows.some(x => x.fresh && symKey(x.sym) === symKey(row.symbol))) { await q(`UPDATE signals SET ${col}=now() WHERE k=$1 AND ${col} IS NULL`, [row.k]); continue; }
        const cap = await q(`SELECT 1 FROM bot_msgs WHERE bot=$1 AND created_at > now() - interval '24 hours' LIMIT 1`, [row.bot]);
        if (cap.rows[0] && (Date.now() - new Date(since).getTime()) / 1000 < HOLD_S()) continue;
        const c = await q(`UPDATE signals SET ${col}=now() WHERE k=$1 AND ${col} IS NULL RETURNING *`, [row.k]);
        const x = c.rows[0];
        if (!x) continue;                                    // another call took it
        let res;
        try { res = await deliverAlert(kind === 'open' ? openAlertText(x) : closeAlertText(x), { cat: 'signals' }); } catch (e) { res = { ok: false, configured: true }; }
        if (res && res.ok) { sent++; continue; }
        await q(`UPDATE signals SET ${col}=NULL, alert_tries=alert_tries+(CASE WHEN $2 THEN 1 ELSE 0 END) WHERE k=$1`, [x.k, !(res && res.configured === false)]);
        if (res && res.configured === false) return sent;    // nothing is set up: don't spin
      }
    }
    return sent;
  }

  // Alarm: a bot said it SENT a trade, over a minute passed, and no order for it ever reached the relay. This is the failure that
  // used to be invisible (the bot's own screen says "relayed", Bybit shows nothing). One alert per signal.
  const ALARM_AFTER_S = Number(process.env.SIGNAL_ALARM_SECONDS) || 60;
  async function checkSignalAlarms() {
    await ready;
    const r = await q(`SELECT k, bot, symbol, side, opened_at FROM signals WHERE relay_flag='SENT' AND order_seen_at IS NULL AND alarm_at IS NULL
        AND opened_at < now() - ($1 || ' seconds')::interval AND opened_at > now() - interval '3 hours' AND closed_at IS NULL ORDER BY opened_at LIMIT 20`, [String(ALARM_AFTER_S)]);
    for (const x of r.rows) {
      const c = await q(`UPDATE signals SET alarm_at=now() WHERE k=$1 AND alarm_at IS NULL RETURNING k`, [x.k]);
      if (!c.rows[0]) continue;
      const who = String(x.bot || '').replace('YM ORACLE ', 'Oracle ');
      if (sendAlert) sendAlert('🚨 ' + who + ' ' + String(x.symbol || '').replace('USDT', '') + ' ' + (x.side === 'BUY' ? 'long' : 'short') + ': the bot says it sent this trade over ' + ALARM_AFTER_S + ' seconds ago, but no order has reached the relay. Nothing was placed on Bybit or copied to users. Check the manager ESP32 (power, Wi-Fi, serial log).');
    }
    return r.rows.length;
  }

  // A copy that was claimed (PENDING) but never finished means the relay restarted or lost its connection mid-order. Ask Bybit
  // by orderLinkId what really happened and make the log tell the truth. An order that never reached Bybit is NOT re-sent:
  // by now the price has moved, and opening late is a different trade than the one the bot signalled.
  let settling = false;
  async function settlePending() {
    if (settling) return { settled: 0 };
    settling = true;
    let settled = 0;
    try {
      await ready;
      const r = await q(`SELECT id, user_id, order_link_id, symbol, side FROM order_log
        WHERE code='PENDING' AND created_at < now() - interval '60 seconds' AND created_at > now() - interval '2 days' ORDER BY id LIMIT 50`);
      for (const row of r.rows) {
        const ur = await q('SELECT * FROM users WHERE id=$1', [row.user_id]);
        const u = ur.rows[0];
        const sym = String(row.symbol || '').replace('USDT', '');
        const done = async (code, ok, detail, orderId) => {
          await q(`UPDATE order_log SET code=$2, ok=$3, detail=$4, bybit_order_id=COALESCE($5, bybit_order_id) WHERE id=$1 AND code='PENDING'`, [row.id, code, ok, detail, orderId || null]);
          settled++;
        };
        if (!u || !u.key_enc || !row.order_link_id) { await done('NET', false, 'Interrupted before it finished'); continue; }
        try {
          const client = userClient(u);
          let o = null;
          for (const fn of ['getActiveOrders', 'getHistoricOrders']) {
            const res = await client[fn]({ category: 'linear', symbol: row.symbol, orderLinkId: row.order_link_id, limit: 1 });
            if (res.retCode !== 0) throw bybitErr(res);
            o = ((res.result && res.result.list) || [])[0];
            if (o) break;
          }
          if (o && /^(Filled|PartiallyFilled|New|Untriggered|Triggered)$/.test(o.orderStatus)) await done('OK', true, 'Placed (confirmed after an interruption)', o.orderId);
          else if (o) await done('BYBIT', false, 'Bybit did not accept it (' + o.orderStatus + ')', o.orderId);
          else {
            await done('NET', false, 'Interrupted before it reached Bybit. It was not retried because the price has moved on');
            if (!QUIET_CODES.has('NET')) notify(u, '⚠️ ' + sym + ': the copy of this trade was interrupted and was not placed.');
          }
        } catch (e) {
          if (e && e.retCode !== undefined && AUTH_RET_CODES.has(e.retCode)) await markKeyError(u, e.message);
          // anything else (Bybit unreachable): leave it PENDING and look again next round
        }
      }
    } catch (e) { console.error('[multiuser] settlePending:', e.message); }
    finally { settling = false; }
    return { settled };
  }

  // ---------- PnL ledger sync (pulled from Bybit into OUR database, so history survives withdrawals / key removal) ----------
  const num = v => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
  async function insertLedger(u, c) {
    const r = await q(
      `INSERT INTO pnl_ledger(user_id,order_id,symbol,side,qty,entry_price,exit_price,closed_pnl,open_fee,close_fee,leverage,closed_at)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,to_timestamp($12/1000.0)) ON CONFLICT (user_id, order_id) DO NOTHING`,
      [u.id, c.orderId, c.symbol, c.side, num(c.qty), num(c.avgEntryPrice), num(c.avgExitPrice), num(c.closedPnl) || 0, num(c.openFee), num(c.closeFee), num(c.leverage), parseInt(c.updatedTime, 10)]);
    if (r.rowCount && Date.now() - parseInt(c.updatedTime, 10) < 2 * 3600 * 1000) {
      const p = num(c.closedPnl) || 0; // only fresh closes ping the user, never a first-time history backfill
      notify(u, (p >= 0 ? '🟢 ' : '🔴 ') + 'Closed ' + String(c.symbol || '').replace('USDT', '') + ': ' + (p >= 0 ? '+$' : '-$') + Math.abs(p).toFixed(2));
    }
    return r.rowCount;
  }
  async function syncFunding(u, client, now) {
    try {
      const WEEK = 7 * 24 * 3600 * 1000 - 1000;
      const prev = u.last_funding_sync_ms ? Number(u.last_funding_sync_ms) : new Date(u.created_at).getTime();
      let start = prev;
      while (start < now) {
        const end = Math.min(start + WEEK, now);
        let cursor;
        do {
          const r = await client.getTransactionLog({ accountType: 'UNIFIED', category: 'linear', type: 'SETTLEMENT', startTime: start, endTime: end, limit: 50, cursor });
          if (r.retCode !== 0) throw bybitErr(r);
          for (const t of (r.result.list || [])) {
            const amount = parseFloat(t.change);
            if (!Number.isFinite(amount) || amount === 0) continue;
            await q(`INSERT INTO funding_ledger(user_id,tx_key,symbol,amount,at) VALUES($1,$2,$3,$4,to_timestamp($5/1000.0)) ON CONFLICT (user_id, tx_key) DO NOTHING`,
              [u.id, sha1([t.symbol, t.transactionTime, t.change, t.type].join('|')), t.symbol, amount, parseInt(t.transactionTime, 10)]);
          }
          cursor = r.result.nextPageCursor || undefined;
        } while (cursor);
        start = end;
      }
      await q('UPDATE users SET last_funding_sync_ms=$2 WHERE id=$1', [u.id, Math.max(prev, now - 600000)]);
    } catch (e) { console.error('[multiuser] funding sync skipped for', u.username + ':', e.message); }
  }
  async function syncUser(u) {
    const client = userClient(u);
    const WEEK = 7 * 24 * 3600 * 1000 - 1000; // Bybit's max query window
    const now = Date.now();
    const prev = u.last_pnl_sync_ms ? Number(u.last_pnl_sync_ms) : new Date(u.created_at).getTime();
    let start = prev;
    let added = 0;
    while (start < now) {
      const end = Math.min(start + WEEK, now);
      let cursor;
      do {
        const r = await client.getClosedPnL({ category: 'linear', startTime: start, endTime: end, limit: 100, cursor });
        if (r.retCode !== 0) throw bybitErr(r);
        for (const c of (r.result.list || [])) added += await insertLedger(u, c);
        cursor = r.result.nextPageCursor || undefined;
      } while (cursor);
      start = end;
    }
    await syncFunding(u, client, now);
    const eq = await getEquity(client);
    await q(`INSERT INTO equity_snap(user_id,day,equity) VALUES($1,(now() AT TIME ZONE 'UTC')::date,$2) ON CONFLICT DO NOTHING`, [u.id, eq.equity]);
    // keep a 10-minute overlap so trades that were still settling get picked up next time (duplicates are ignored)
    await q(`UPDATE users SET last_pnl_sync_ms=$2, last_synced_at=now(), last_equity=$3, key_status='ok', key_error=NULL WHERE id=$1`, [u.id, Math.max(prev, now - 600000), eq.equity]);
    return added;
  }
  let syncing = false;
  async function syncAll() {
    if (syncing) return { skipped: true };
    syncing = true;
    let users = 0, added = 0, failed = 0;
    try {
      await ready;
      await q('DELETE FROM sessions WHERE expires_at < now()');
      await q('DELETE FROM admin_sessions WHERE expires_at < now()');
      const r = await q(`SELECT * FROM users WHERE key_enc IS NOT NULL ORDER BY id`);
      for (const u of r.rows) {
        try { added += await syncUser(u); users++; }
        catch (e) {
          failed++;
          console.error('[multiuser] sync failed for', u.username + ':', e.message);
          if (e.retCode !== undefined && AUTH_RET_CODES.has(e.retCode)) await markKeyError(u, e.message);
        }
      }
    } finally { syncing = false; }
    return { users, added, failed };
  }

  // ---------- Profit Guard ----------
  // Watches the MASTER account's open trades every few seconds (see profitguard.js). Three jobs, each switchable per profile (fast / swing):
  //   1. lock profit: only ever RAISES a stop toward the profit side (never loosens it) and keeps the stop on Bybit
  //   2. scale-out (optional): closes a small slice at set R levels and leaves a runner
  //   3. re-entry RECORDER: after a winner closes, notes when a "pulled back, then resumed" entry would have appeared and how it would have ended. It never trades.
  // shadow = records what it would do and touches nothing. live = does it for real (master and copies).
  const pgRun = { at: 0, ok: null, note: '', err: null, positions: 0, busy: false, raises: 0, scales: 0 };
  let pgSavedAt = 0, pgForce = false;
  const pgClosing = [];           // trades that just closed, waiting for Bybit's closed-PnL record (in memory only)
  const pgEm = st => PG.effMode(pgCfg, st.profile);
  async function pgLog(row) {
    try {
      await q(`INSERT INTO profit_guard_log(symbol,side,mode,profile,event,entry,mark,old_sl,new_sl,peak_r,lock_pct,detail,result_r) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
        [row.symbol, row.side || null, row.mode || pgCfg.mode, row.profile || null, row.event, row.entry ?? null, row.mark ?? null, row.oldSl ?? null, row.newSl ?? null, row.peakR ?? null, row.lockPct ?? null, String(row.detail || '').slice(0, 300), row.resultR ?? null]);
    } catch (e) { console.error('[multiuser] profit guard log:', e.message); }
  }
  async function pgSaveState(force) {
    if (!force && Date.now() - pgSavedAt < 15000) return;
    pgSavedAt = Date.now();
    try {
      await q(`INSERT INTO meta(k,v) VALUES('profit_guard_state',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(Object.fromEntries(pgState))]);
      await q(`INSERT INTO meta(k,v) VALUES('profit_guard_watch',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(Object.fromEntries(pgWatch))]);
    } catch (e) { console.error('[multiuser] profit guard state:', e.message); }
  }
  // Which profile a trade follows, and the stop the bot originally planned for it (from what the bot reported when it opened the trade).
  async function pgLookup(symbol, side) {
    try {
      const r = await q(`SELECT bot, sl, eng FROM signals WHERE symbol=$1 AND side=$2 AND opened_at > now() - interval '30 days' ORDER BY opened_at DESC LIMIT 1`, [symbol, side === 'Buy' ? 'BUY' : 'SELL']);
      const x = r.rows[0]; if (!x) return { bot: '', sl: 0, eng: null };
      return { bot: x.bot || '', sl: Number(x.sl) || 0, eng: x.eng || null };
    } catch { return { bot: '', sl: 0, eng: null }; }
  }
  // Scale-out for the copies: each user closes the same SHARE of their OWN position (not the master's quantity).
  async function fanOutPartialClose(symbol, posSide, frac, inst) {
    if (getMode() !== 'live' || breakerIsTripped() || !inst) return { users: 0, closed: 0 };
    const opp = posSide === 'Buy' ? 'Sell' : 'Buy';
    const users = await tradableUsers({ forOpen: false });
    let closed = 0;
    await runLimited(users, 5, u => enqueue(u.id, async () => {
      if (isDry(u)) return;
      const base = { userId: u.id, kind: 'CLOSE', symbol, side: opp };
      try {
        const client = userClient(u);
        const pos = await getOpenPosition(client, symbol);
        if (!pos || pos.side !== posSide) return;
        const qty = PG.sliceQty(pos.size, frac, inst.qtyStep, inst.minQty);
        if (!qty) return logOrder({ ...base, code: 'MINQ', ok: true, detail: 'Scale-out skipped: the position is too small to split' });
        const res = await client.submitOrder({ category: 'linear', symbol, side: opp, orderType: 'Market', qty: String(qty), reduceOnly: true, positionIdx: Number(pos.positionIdx) || 0 });
        if (res.retCode === 0) { closed++; await logOrder({ ...base, qty, code: 'OK', ok: true, detail: 'Scale-out: took ' + Math.round(frac * 100) + '% profit, the rest keeps running' }); }
        else { const f = failFrom({ retCode: res.retCode, message: res.retMsg }); await logOrder({ ...base, qty, code: f.code, ok: false, detail: 'Scale-out failed: ' + res.retMsg }); if (f.auth) await markKeyError(u, res.retMsg); }
      } catch (e) { const f = failFrom(e); await logOrder({ ...base, code: f.code, ok: false, detail: 'Scale-out failed: ' + f.detail }); if (f.auth) await markKeyError(u, f.detail); }
    }));
    return { users: users.length, closed };
  }
  // A trade has closed: find Bybit's own exit, store the scorecard row, and (for a winner) start a re-entry watch.
  async function pgRecordClose(it) {
    const st = it.st, [symbol, side] = it.key.split('|'), long = side === 'Buy';
    let exit = 0, pnl = null;
    try {
      const r = await restClient.getClosedPnL({ category: 'linear', symbol, limit: 10 });
      const rows = ((r.result && r.result.list) || []).filter(x => x.symbol === symbol && Number(x.updatedTime || x.createdTime || 0) >= st.since - 60000);
      const last = rows.find(x => Number(x.updatedTime || x.createdTime || 0) >= it.at - 180000);
      if (last && parseFloat(last.avgExitPrice) > 0) { exit = parseFloat(last.avgExitPrice); pnl = rows.reduce((t, x) => t + (Number(x.closedPnl) || 0), 0); }
    } catch { /* retried below */ }
    if (!(exit > 0) && it.tries < 6) { it.tries++; return false; }
    const entry = st.entry, risk = st.initialSl > 0 ? Math.abs(entry - st.initialSl) : 0;
    const peakDist = long ? st.peak - entry : entry - st.peak, exitDist = exit > 0 ? (long ? exit - entry : entry - exit) : null;
    const peakPct = peakDist / entry * 100, exitPct = exitDist === null ? null : exitDist / entry * 100;
    const peakR = risk > 0 ? peakDist / risk : null, exitR = risk > 0 && exitDist !== null ? exitDist / risk : null;
    const gb = exitPct === null ? null : peakPct - exitPct;
    try {
      await q(`INSERT INTO pg_trades(symbol,side,profile,mode,entry,initial_sl,peak_price,exit_price,peak_pct,exit_pct,giveback_pct,peak_r,exit_r,guard_floor,scaled,pnl) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)`,
        [symbol, side, st.profile, it.em, entry, st.initialSl || null, st.peak, exit || null, peakPct, exitPct, gb, peakR, exitR, st.floor || st.shadowSl || null, (st.scaled || []).length, pnl]);
    } catch (e) { console.error('[multiuser] profit guard scorecard:', e.message); }
    await pgLog({ symbol, side, profile: st.profile, mode: it.em, event: 'closed', entry, mark: exit || null, newSl: st.floor || st.shadowSl || null, peakR, detail: 'trade closed' + (exitPct !== null ? ': best +' + peakPct.toFixed(2) + '%, exit ' + (exitPct >= 0 ? '+' : '') + exitPct.toFixed(2) + '%, gave back ' + gb.toFixed(2) + '%' : ' (exit price not found)') + (st.shadowSl > 0 && !st.shadowHit ? ' (price never touched the guard\'s shadow stop)' : '') });
    const rc = pgCfg.reentry, pf = pgCfg[st.profile];
    if (rc.on && it.em !== 'off' && risk > 0 && peakR >= pf.beR) {
      pgWatch.set(it.key, { symbol, side, profile: st.profile, entry, exit: exit || it.mark, peak: st.peak, risk, extreme: exit || it.mark, cand: null, expiresAt: Date.now() + (st.profile === 'swing' ? rc.hoursSwing : rc.hoursFast) * 3600000 });
      for (const k of [...pgWatch.keys()].slice(0, Math.max(0, pgWatch.size - 20))) pgWatch.delete(k);
    }
    return true;
  }
  async function pgTick() {
    if (pgRun.busy || pgCfg.mode === 'off') return;
    if (getMode() !== 'live' || breakerIsTripped()) { pgRun.note = 'paused: the relay is not live or trading is halted'; return; }
    pgRun.busy = true;
    try {
      await ready;
      const positions = await listOpenPositions(restClient);
      const seen = new Set();
      for (const p of positions) {
        if (p.side !== 'Buy' && p.side !== 'Sell') continue;
        const symbol = p.symbol, side = p.side, key = symbol + '|' + side, long = side === 'Buy'; seen.add(key);
        const entry = parseFloat(p.avgPrice), mark = parseFloat(p.markPrice), curSl = parseFloat(p.stopLoss) || 0;
        if (!(entry > 0) || !(mark > 0)) continue;
        let st = pgState.get(key);
        if (st && Math.abs(st.entry - entry) / st.entry > 0.005) st = null;   // a different trade on the same pair: start fresh
        if (!st) {
          const lk = await pgLookup(symbol, side);
          let init = lk.sl > 0 && (long ? lk.sl < entry : lk.sl > entry) ? lk.sl : 0;                     // the bot's own planned stop
          if (!init && curSl > 0 && (long ? curSl < entry : curSl > entry)) init = curSl;                    // else the first stop we saw on the position
          st = { entry, initialSl: init, peak: entry, peakAt: Date.now(), maxPull: 0, floor: 0, shadowSl: 0, shadowHit: false, scaled: [], profile: PG.profileOf(pgCfg, lk.eng, lk.bot), bot: lk.bot, since: Date.now(), lastAlert: 0 };
          pgState.set(key, st); pgWatch.delete(key);
        }
        st.scaled = st.scaled || [];
        const peak0 = st.peak;
        st.peak = PG.updatePeak(st.peak, side, mark, entry); st.mark = mark; st.curSl = curSl; st.size = Number(p.size) || 0;
        if (st.peak !== peak0 || !(st.peakAt > 0)) { st.peakAt = Date.now(); st.dirty = true; }          // smart: a new best resets the stall clock
        const pull0 = st.maxPull || 0; st.maxPull = PG.updatePull(pull0, side, st.peak, mark);          // smart: the trade's own largest pullback so far
        if (st.maxPull !== pull0) st.dirty = true;
        const em = pgEm(st);
        st.em = em;
        if (em === 'off') { st.lastWhy = 'switched off for this profile'; continue; }
        const inst = await getInstrument(symbol).catch(() => null);
        const pf = pgCfg[st.profile];

        // ---- scale-out ----
        if (pf.scale.on && st.initialSl > 0 && !PG_BAD_RISK(long, entry, st.initialSl)) {
          const risk = Math.abs(entry - st.initialSl), curR = (long ? mark - entry : entry - mark) / risk;
          const doneList = em === 'live' ? st.scaled : (st.scaledShadow = st.scaledShadow || []);
          const i = PG.scaleDue(pf.scale.steps, curR, doneList);
          if (i >= 0 && Date.now() >= (st.scaleRetryAt || 0)) {
            const frac = pf.scale.steps[i][1];
            if (em === 'shadow') {
              doneList.push(i); st.dirty = true;
              await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'would_scale', entry, mark, peakR: curR, detail: 'would take ' + Math.round(frac * 100) + '% off at ' + curR.toFixed(1) + 'R' });
            } else {
              const qty = PG.sliceQty(p.size, frac, inst && inst.qtyStep, inst && inst.minQty);
              if (!qty) { doneList.push(i); st.dirty = true; await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'scale_skipped', entry, mark, detail: 'position too small to split' }); }
              else {
                let res = null, err = null;
                try { res = await restClient.submitOrder({ category: 'linear', symbol, side: long ? 'Sell' : 'Buy', orderType: 'Market', qty: String(qty), reduceOnly: true, positionIdx: Number(p.positionIdx) || 0 }); }
                catch (e) { err = e.message || String(e); }
                if (res && res.retCode === 0) {
                  doneList.push(i); st.dirty = true; pgForce = true; pgRun.scales++;
                  await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'scaled', entry, mark, peakR: curR, detail: 'took ' + Math.round(frac * 100) + '% profit at ' + curR.toFixed(1) + 'R (' + qty + ')' });
                  fanOutPartialClose(symbol, side, frac, inst).catch(e => console.error('[multiuser] profit guard scale-out fan-out:', e.message));
                  if (pgCfg.alerts) deliverAlert('💰 Profit banked: ' + symbol.replace(/USDT$/, '') + ' ' + (long ? 'long' : 'short') + ' ' + Math.round(frac * 100) + '% closed at ' + curR.toFixed(1) + 'R. The rest keeps running with its stop.', { cat: 'updates' }).catch(() => {});
                } else {
                  st.scaleRetryAt = Date.now() + 60000;
                  await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'failed', entry, mark, detail: 'scale-out: ' + (err || (res && res.retMsg) || 'no answer') });
                }
              }
            }
          }
        }

        // ---- profit lock ----
        const eff = em === 'shadow' && st.shadowSl > 0 ? (long ? Math.max(curSl, st.shadowSl) : (curSl > 0 ? Math.min(curSl, st.shadowSl) : st.shadowSl)) : curSl;
        const d = PG.decide({ side, entry, mark, peak: st.peak, curSl: eff, initialSl: st.initialSl, tick: inst && inst.tickSize || 0, profile: pf, cfg: pgCfg,
          smart: { ...PG.noiseOf(pgCfg, st.maxPull), stallExtra: PG.stallExtra(pgCfg, st.profile, Date.now(), st.peakAt) } });
        st.lastWhy = d.action === 'raise' ? d.label : d.why; st.peakR = d.peakR !== undefined ? d.peakR : st.peakR;
        if (em === 'shadow' && st.shadowSl > 0 && !st.shadowHit && (long ? mark <= st.shadowSl : mark >= st.shadowSl)) {
          st.shadowHit = true;
          await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'would_exit', entry, mark, newSl: st.shadowSl, peakR: st.peakR, lockPct: (long ? st.shadowSl - entry : entry - st.shadowSl) / entry * 100, detail: 'price touched the guard\'s stop: it would have been closed here with the profit locked' });
        }
        if (d.action !== 'raise') continue;
        if (em === 'shadow') {
          st.shadowSl = d.newSl; st.dirty = true;
          await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'would_raise', entry, mark, oldSl: curSl || null, newSl: d.newSl, peakR: d.peakR, lockPct: d.lockPct, detail: d.label });
          continue;
        }
        // live: move the master's real stop, then the copies' stops
        const body = { category: 'linear', symbol, positionIdx: Number(p.positionIdx) || 0, stopLoss: String(d.newSl) };
        let res;
        try { res = await restClient.setTradingStop(body); }
        catch (e) { await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'failed', entry, mark, oldSl: curSl || null, newSl: d.newSl, peakR: d.peakR, detail: 'Bybit call failed: ' + (e.message || e) }); continue; }
        if (res.retCode !== 0 && res.retCode !== 34040) { await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'failed', entry, mark, oldSl: curSl || null, newSl: d.newSl, peakR: d.peakR, detail: 'Bybit refused: ' + (res.retMsg || res.retCode) }); continue; }
        st.floor = d.newSl; st.curSl = d.newSl; st.dirty = true; pgRun.raises++; pgForce = true;
        await pgLog({ symbol, side, profile: st.profile, mode: em, event: 'raised', entry, mark, oldSl: curSl || null, newSl: d.newSl, peakR: d.peakR, lockPct: d.lockPct, detail: d.label });
        fanOutTradingStop({ symbol, positionIdx: Number(p.positionIdx) || 0, stopLoss: String(d.newSl) }).catch(e => console.error('[multiuser] profit guard fan-out:', e.message));
        if (pgCfg.alerts && Date.now() - st.lastAlert > 60000) {
          st.lastAlert = Date.now();
          deliverAlert('🔒 Profit locked: ' + symbol.replace(/USDT$/, '') + ' ' + (long ? 'long' : 'short') + ' stop moved to ' + d.newSl + ' (' + (d.lockPct >= 0 ? '+' : '') + d.lockPct.toFixed(2) + '% from entry, ' + d.label + '). Best so far was ' + d.peakR.toFixed(1) + 'R.', { cat: 'updates' }).catch(() => {});
        }
      }
      // trades that have closed since the last look: queue them for the scorecard
      let gone = false;
      for (const [key, st] of [...pgState.entries()]) {
        if (seen.has(key)) continue;
        pgClosing.push({ key, st, em: st.em || pgEm(st), at: Date.now(), tries: 0, mark: st.mark });
        pgState.delete(key); gone = true;
      }
      for (let i = 0; i < pgClosing.length;) { if (await pgRecordClose(pgClosing[i]).catch(() => false)) { pgClosing.splice(i, 1); gone = true; } else i++; }
      // re-entry watches (recording only: this never places a trade)
      for (const [key, w] of [...pgWatch.entries()]) {
        if (seen.has(key) || Date.now() > w.expiresAt + 3600000) { pgWatch.delete(key); gone = true; continue; }
        if (!pgCfg.reentry.on || PG.effMode(pgCfg, w.profile) === 'off') continue;
        let mk = 0;
        try { const r = await restClient.getTickers({ category: 'linear', symbol: w.symbol }); mk = parseFloat(r.result.list[0].lastPrice); } catch { continue; }
        const out = PG.reentryStep(w, mk, Date.now(), pgCfg.reentry);
        if (out.events.length || out.finished) gone = true;
        for (const e of out.events) {
          const base = { symbol: w.symbol, side: w.side, profile: w.profile, mode: 'shadow', entry: w.entry };
          if (e.type === 'would_reenter') await pgLog({ ...base, event: 'would_reenter', mark: e.price, newSl: e.stop, peakR: e.pullR, detail: 'pulled back ' + e.pullR.toFixed(1) + 'R then resumed: a re-entry would have been taken here (recording only)' });
          else if (e.type === 'reentry_result') await pgLog({ ...base, event: 'reentry_result', mark: mk, resultR: e.r, peakR: e.bestR, detail: e.why });
          else if (e.type === 'no_reentry') await pgLog({ ...base, event: 'no_reentry', mark: mk, peakR: e.pullR, detail: 'no pullback-and-resume appeared within the window' });
        }
        if (out.finished) pgWatch.delete(key);
      }
      await pgAutoTune().catch(e => console.error('[multiuser] profit guard tuning:', e.message));
      pgRun.at = Date.now(); pgRun.ok = true; pgRun.err = null; pgRun.note = ''; pgRun.positions = positions.length;
      const changed = gone || [...pgState.values()].some(s => s.dirty);
      for (const s of pgState.values()) s.dirty = false;
      if (changed) { await pgSaveState(gone || pgForce); pgForce = false; }
    } catch (e) { pgRun.at = Date.now(); pgRun.ok = false; pgRun.err = e.message; console.error('[multiuser] profit guard:', e.message); }
    finally { pgRun.busy = false; }
  }
  const PG_BAD_RISK = (long, entry, init) => !(init > 0) || (long ? init >= entry : init <= entry);
  // Called by the stop route before a bot's stop is applied: while the guard is live for that trade, a looser stop is held at the guard's floor (and a stop removal is refused).
  function guardClamp(body) {
    try {
      if (!body || typeof body !== 'object' || body.stopLoss === undefined) return body;
      const cands = ['Buy', 'Sell'].map(s => [s, pgState.get(String(body.symbol) + '|' + s)]).filter(([, st]) => st && st.floor > 0 && pgEm(st) === 'live');
      if (cands.length !== 1) return body;
      const [side, st] = cands[0];
      const use = PG.clampStop(side, body.stopLoss, st.floor);
      if (use === null) return body;
      pgLog({ symbol: body.symbol, side, profile: st.profile, mode: 'live', event: 'held', entry: st.entry, newSl: st.floor, oldSl: Number(body.stopLoss) || null, detail: 'a stop of ' + body.stopLoss + ' was held at the guard\'s floor ' + st.floor });
      return { ...body, stopLoss: String(use) };
    } catch { return body; }
  }
  // After a scale-out the bot still thinks it holds the whole position. When it later sends its own close, fit the quantity to what is really left.
  async function guardFitClose(body) {
    try {
      if (!body || body.reduceOnly !== true || !(Number(body.qty) > 0)) return body;
      const st = ['Buy', 'Sell'].map(s => pgState.get(String(body.symbol) + '|' + s)).find(x => x && x.scaled && x.scaled.length);
      if (!st) return body;
      const left = parseFloat(((await getPositionState(restClient, body.symbol)).open || {}).size);
      if (left > 0 && left < Number(body.qty)) return { ...body, qty: String(left) };
    } catch { /* the original order goes ahead untouched */ }
    return body;
  }

  // ---- smart tuning: read the scorecard, suggest (or, with consent, apply) small changes to the keep shares ----
  async function pgTuneEval(profile) {
    const rows = (await q(`SELECT peak_pct, exit_pct, giveback_pct, peak_r FROM pg_trades WHERE profile=$1 AND mode='live' AND exit_pct IS NOT NULL ORDER BY id DESC LIMIT 300`, [profile])).rows
      .map(r => ({ peak_pct: Number(r.peak_pct), exit_pct: r.exit_pct === null ? null : Number(r.exit_pct), giveback_pct: Number(r.giveback_pct), peak_r: Number(r.peak_r) }));
    const re = (await q(`SELECT COUNT(*)::int AS done, COUNT(*) FILTER (WHERE result_r>0)::int AS wins, AVG(result_r) AS avg_r FROM profit_guard_log WHERE event='reentry_result' AND profile=$1`, [profile])).rows[0];
    return PG.suggestTuning(pgCfg, profile, rows, { done: re.done, wins: re.wins, avg_r: re.avg_r === null ? null : Number(re.avg_r) });
  }
  async function pgApplyTuning(profile, sug, who) {
    if (!sug || !sug.next) return false;
    const next = PG.normalize({ ...pgCfg, [profile]: { ...pgCfg[profile], ladder: sug.next }, smart: { ...pgCfg.smart, tune: { ...pgCfg.smart.tune, lastAtN: { ...pgCfg.smart.tune.lastAtN, [profile]: sug.n } } } });
    await q(`INSERT INTO meta(k,v) VALUES('profit_guard',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(next)]);
    pgCfg = next;
    const txt = sug.changes.map(c => 'step at ' + c.atR + 'R: keep ' + Math.round(c.from * 100) + '% -> ' + Math.round(c.to * 100) + '%').join('; ');
    await pgLog({ symbol: '-', profile, mode: 'live', event: 'tuned', detail: (who || 'auto') + ' (' + sug.n + ' trades): ' + txt + '. ' + sug.reasons.join(' ') });
    await audit('admin', 'profit_guard_tuned', null, null, profile + ': ' + txt).catch(() => {});
    if (pgCfg.alerts) deliverAlert('🧠 Profit Guard tuned the ' + profile + ' ladder: ' + txt + '. Why: ' + sug.reasons.join(' '), { kind: 'master' });
    return true;
  }
  let pgTunedAt = 0;
  async function pgAutoTune(force) {
    if (pgCfg.smart.tune.mode !== 'auto' || (!force && Date.now() - pgTunedAt < 60000)) return;
    pgTunedAt = Date.now();
    for (const profile of ['fast', 'swing']) {
      if (PG.effMode(pgCfg, profile) !== 'live') continue;
      const sug = await pgTuneEval(profile);
      if (!sug.ready || sug.since < pgCfg.smart.tune.every) continue;
      if (sug.action === 'hold') { pgCfg = PG.normalize({ ...pgCfg, smart: { ...pgCfg.smart, tune: { ...pgCfg.smart.tune, lastAtN: { ...pgCfg.smart.tune.lastAtN, [profile]: sug.n } } } }); await q(`INSERT INTO meta(k,v) VALUES('profit_guard',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(pgCfg)]); continue; }
      await pgApplyTuning(profile, sug, 'auto');
    }
  }
  const pgView = async () => {
    const log = (await q(`SELECT at, symbol, side, mode, profile, event, entry, mark, old_sl, new_sl, peak_r, lock_pct, detail, result_r FROM profit_guard_log ORDER BY id DESC LIMIT 60`)).rows;
    const trades = [...pgState.entries()].map(([key, st]) => ({ symbol: key.split('|')[0], side: key.split('|')[1], profile: st.profile, bot: st.bot, mode: st.em || pgEm(st), entry: st.entry, mark: st.mark || null, peak: st.peak, peakR: st.peakR || 0, initialSl: st.initialSl || null, stop: st.curSl || null, floor: st.floor || null, shadowStop: st.shadowSl || null, scaled: (st.scaled || []).length, why: st.lastWhy || '', pullR: st.initialSl > 0 ? (st.maxPull || 0) / Math.abs(st.entry - st.initialSl) : null, stallPts: Math.round(PG.stallExtra(pgCfg, st.profile, Date.now(), st.peakAt) * 100) }));
    const card = (await q(`SELECT at, symbol, side, profile, mode, peak_pct, exit_pct, giveback_pct, peak_r, exit_r, scaled, pnl FROM pg_trades ORDER BY id DESC LIMIT 20`)).rows;
    const agg = (await q(`SELECT profile, mode, COUNT(*)::int AS n, AVG(peak_pct) AS peak, AVG(exit_pct) AS exit, AVG(giveback_pct) AS giveback FROM pg_trades WHERE exit_pct IS NOT NULL GROUP BY profile, mode ORDER BY profile, mode`)).rows;
    const re = (await q(`SELECT COUNT(*) FILTER (WHERE event='would_reenter')::int AS spotted, COUNT(*) FILTER (WHERE event='reentry_result')::int AS done, COUNT(*) FILTER (WHERE event='reentry_result' AND result_r>0)::int AS wins, AVG(result_r) FILTER (WHERE event='reentry_result') AS avg_r, COUNT(*) FILTER (WHERE event='no_reentry')::int AS none FROM profit_guard_log`)).rows[0];
    const watching = [...pgWatch.values()].map(w => ({ symbol: w.symbol, side: w.side, profile: w.profile, cand: !!w.cand, expiresAt: w.expiresAt }));
    const tuning = {}; for (const pr of ['fast', 'swing']) { try { const t = await pgTuneEval(pr); delete t.next; tuning[pr] = t; } catch { tuning[pr] = null; } }
    return { cfg: pgCfg, tuning, run: { at: pgRun.at, ok: pgRun.ok, note: pgRun.note, err: pgRun.err, positions: pgRun.positions, raises: pgRun.raises, scales: pgRun.scales, relayMode: getMode(), halted: !!breakerIsTripped() }, trades, log, scorecard: { recent: card, summary: agg, reentry: re, watching } };
  };

  // ---------- CSV export + daily backup ----------
  async function buildCsv(userId) {
    const where = userId ? 'WHERE u.id=$1' : '';
    const params = userId ? [userId] : [];
    const r = await q(`
      SELECT * FROM (
        SELECT u.username, 'TRADE' AS kind, l.closed_at AS at, l.symbol, l.side, l.qty, l.entry_price, l.exit_price, l.closed_pnl AS amount, l.open_fee, l.close_fee, l.leverage
        FROM pnl_ledger l JOIN users u ON u.id=l.user_id ${where}
        UNION ALL
        SELECT u.username, 'FUNDING', f.at, f.symbol, NULL::text, NULL::numeric, NULL::numeric, NULL::numeric, f.amount, NULL::numeric, NULL::numeric, NULL::numeric
        FROM funding_ledger f JOIN users u ON u.id=f.user_id ${where}
      ) x ORDER BY at`, params);
    const cols = ['username', 'kind', 'at', 'symbol', 'side', 'qty', 'entry_price', 'exit_price', 'amount', 'open_fee', 'close_fee', 'leverage'];
    const lines = [cols.join(',')].concat(r.rows.map(row => cols.map(c => csvCell(row[c])).join(',')));
    return { csv: lines.join('\n') + '\n', rows: r.rows.length };
  }
  async function runBackupIfDue(force) {
    await ready;
    if (!tgOn || !TG_ADMIN_CHAT) return { sent: false, reason: 'Telegram is not configured' };
    const last = await q(`SELECT v FROM meta WHERE k='last_backup_ms'`);
    if (!force && last.rows[0] && Date.now() - Number(last.rows[0].v) < 23 * 3600 * 1000) return { sent: false, reason: 'not due yet' };
    const { csv, rows } = await buildCsv();
    if (!rows && !force) return { sent: false, reason: 'nothing to back up yet' };
    const ok = await tgSendDoc(TG_ADMIN_CHAT, 'ym-ledger-' + new Date().toISOString().slice(0, 10) + '.csv', csv);
    if (ok) await q(`INSERT INTO meta(k,v) VALUES('last_backup_ms',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [String(Date.now())]);
    return { sent: ok, rows };
  }

  if (process.env.NODE_ENV !== 'test' || process.env.YM_TEST_TIMERS === '1') {
    setTimeout(() => settlePending().catch(() => {}), 20000);
    setInterval(() => settlePending().catch(() => {}), 30000);
    setInterval(() => alertSweep().catch(e => console.error('[multiuser] alert sweep:', e.message)), Number(process.env.ALERT_SWEEP_MS) || 20000);   // retries failed deliveries and sends the short safety-net alerts
    setInterval(() => q(`DELETE FROM bot_msgs WHERE created_at < now() - interval '30 days'`).catch(() => {}), 6 * 3600 * 1000);
    const pgLoop = () => { pgTick().catch(e => console.error('[multiuser] profit guard:', e.message)).finally(() => { const t = setTimeout(pgLoop, Math.max(3000, (pgCfg.pollSec || 5) * 1000)); if (t.unref) t.unref(); }); };
    setTimeout(pgLoop, 15000);   // Profit Guard loop (does nothing while it is switched off)
    setInterval(() => checkSignalAlarms().catch(e => console.error('[multiuser] signal alarm:', e.message)), Number(process.env.ALERT_SWEEP_MS) || 20000);
    setTimeout(() => syncAll().catch(e => console.error('[multiuser] initial sync:', e.message)), 20000);
    setInterval(() => syncAll().catch(e => console.error('[multiuser] sync:', e.message)), SYNC_INTERVAL_MS);
    setTimeout(() => runBackupIfDue(false).catch(e => console.error('[multiuser] backup:', e.message)), 90000);
    setInterval(() => runBackupIfDue(false).catch(e => console.error('[multiuser] backup:', e.message)), 3600 * 1000);
    if (tgOn) {
      loadBotName();
      const t = setInterval(() => tgPollOnce().catch(e => console.error('[multiuser] telegram poll:', e.message)), 8000);
      if (t.unref) t.unref();
    }
  }

  // ---------- auth: users ----------
  const authLimiter = sec.makeLimiter({ windowMs: 15 * 60000, max: 20 });
  const limited = (req, res, next) => (authLimiter.hit(req.ip || 'x') ? next() : res.status(429).json({ success: false, message: 'Too many attempts. Try again in 15 minutes.' }));
  async function newSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    await q(`INSERT INTO sessions(token_hash,user_id,expires_at) VALUES($1,$2, now() + ($3 || ' days')::interval)`, [sha256(token), userId, String(SESSION_DAYS)]);
    return token;
  }
  const MUST_CHANGE_OK = new Set(['/api/me', '/api/me/password', '/api/auth/logout']);
  const userAuth = h(async (req, res, next) => {
    await ready;
    const m = /^Bearer (.+)$/.exec(req.get('Authorization') || '');
    if (!m) return res.status(401).json({ success: false, message: 'Not signed in' });
    const r = await q(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at > now()`, [sha256(m[1])]);
    if (!r.rows[0]) return res.status(401).json({ success: false, message: 'Session expired' });
    req.user = r.rows[0];
    req.tokenHash = sha256(m[1]);
    if (req.user.must_change_password && !MUST_CHANGE_OK.has(req.path)) return res.status(403).json({ success: false, mustChangePassword: true, message: 'Please change your password first.' });
    next();
  });
  const validUsername = s => /^[a-zA-Z0-9_]{3,24}$/.test(s || '');
  async function registerFailure(u, req) {
    const r = await q(`UPDATE users SET
        locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END,
        failed_logins = CASE WHEN failed_logins + 1 >= 5 THEN 0 ELSE failed_logins + 1 END
      WHERE id=$1 RETURNING locked_until, failed_logins`, [u.id]);
    const locked = r.rows[0] && r.rows[0].failed_logins === 0;
    await audit(u.username, locked ? 'login_locked' : 'login_failed', u.username, req, '');
  }

  app.get('/api/public-info', (req, res) => res.json({ success: true, outboundIps: process.env.PUBLIC_OUTBOUND_IPS || '', demo: demoLike, demoKeys: DEMO_KEYS_ALLOWED }));

  app.post('/api/auth/signup', limited, h(async (req, res) => {
    await ready;
    const { username, password, inviteCode, apiKey, apiSecret } = req.body || {};
    const env = normEnv(req.body && req.body.env);
    if (env === 'demo' && !DEMO_KEYS_ALLOWED) return res.status(400).json({ success: false, message: 'Demo keys are switched off on this server. Use a live key.' });
    if (!validUsername(username)) return res.status(400).json({ success: false, message: 'Username: 3-24 letters, numbers or underscore.' });
    if (typeof password !== 'string' || password.length < 10) return res.status(400).json({ success: false, message: 'Password must be at least 10 characters.' });
    if (!apiKey || !apiSecret) return res.status(400).json({ success: false, message: 'Bybit API key and secret are required.' });
    const code = String(inviteCode || '').trim().toUpperCase();
    const inv = await q('SELECT used_by FROM invites WHERE code=$1', [code]);
    if (!inv.rows[0] || inv.rows[0].used_by !== null) return res.status(400).json({ success: false, message: 'Invalid or already-used invite code.' });

    // the starting trade size picked on the sign-up page (optional; otherwise the plan's standard percent)
    const sb = req.body || {};
    let startMode = masterPlan.sizeMode, startPct = masterPlan.sizePct, startUsd = masterPlan.sizeUsd;
    if (sb.sizeMode !== undefined || sb.sizePct !== undefined || sb.sizeUsd !== undefined) {
      const mode = sb.sizeMode || (sb.sizeUsd !== undefined && sb.sizePct === undefined ? 'fixed' : 'percent');
      const pv = parseControls({ sizeMode: mode, sizePct: mode === 'percent' ? sb.sizePct : null, sizeUsd: mode === 'fixed' ? sb.sizeUsd : null },
        { current: {}, allowed: MANUAL_KEYS, pctMax: STD.userPctMax, ceilUsd: masterPlan.maxTradeUsd || 0 });
      if (pv.error) return res.status(400).json({ success: false, message: pv.error });
      if (pv.values.sizePct > STD.userPctConfirmAbove && sb.confirmHigh !== true) return res.status(400).json({ success: false, needConfirm: true, message: 'More than ' + STD.userPctConfirmAbove + '% per trade is risky. Confirm that you understand to continue.' });
      startMode = pv.values.sizeMode; startPct = pv.values.sizePct ?? null; startUsd = pv.values.sizeUsd ?? null;
    }

    const v = await validateKey(String(apiKey).trim(), String(apiSecret).trim(), env);
    if (!v.ok) return res.status(400).json({ success: false, message: v.message });
    if (env === 'live' && MIN_LIVE_BALANCE > 0 && !(v.equity >= MIN_LIVE_BALANCE)) return res.status(400).json({ success: false, message: 'A live account needs at least $' + MIN_LIVE_BALANCE + ' to copy trades safely (yours shows $' + Number(v.equity || 0).toFixed(2) + '). Add funds, or try a Bybit demo account first.' });

    const passHash = await hashPassword(password);
    const keyEnc = encrypt(JSON.stringify({ k: String(apiKey).trim(), s: String(apiSecret).trim() }), KEY);
    const client = await pool.connect();
    let userId;
    try {
      await client.query('BEGIN');
      const ins = await client.query(
        `INSERT INTO users(username,pass_hash,key_enc,key_hash,ips_unrestricted,last_equity,key_env,size_mode,size_pct,size_usd,risk_ack_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [username.toLowerCase(), passHash, keyEnc, sha256(String(apiKey).trim()), v.ipsUnrestricted, v.equity, env, startMode, startPct, startUsd, sb.riskAck === true ? new Date() : null]);
      userId = ins.rows[0].id;
      const claim = await client.query('UPDATE invites SET used_by=$2 WHERE code=$1 AND used_by IS NULL RETURNING code', [code, userId]);
      if (!claim.rows[0]) { await client.query('ROLLBACK'); return res.status(400).json({ success: false, message: 'Invalid or already-used invite code.' }); }
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      if (e.code === '23505') {
        const dupKey = /key_hash/.test(e.detail || e.constraint || '');
        return res.status(400).json({ success: false, message: dupKey ? 'This API key is already registered.' : 'That username is taken.' });
      }
      throw e;
    } finally { client.release(); }
    await audit(username.toLowerCase(), 'signup', username.toLowerCase(), req, (env === 'demo' ? 'DEMO key' : '') + (v.ipsUnrestricted && env === 'live' ? (env === 'demo' ? ', ' : '') + 'key not IP-restricted' : ''));
    res.status(200).json({ success: true, token: await newSession(userId), warnings: v.warnings });
  }));

  app.post('/api/auth/login', limited, h(async (req, res) => {
    await ready;
    const { username, password, totp } = req.body || {};
    const r = await q('SELECT * FROM users WHERE username=$1', [String(username || '').toLowerCase()]);
    const u = r.rows[0];
    if (u && u.locked_until && new Date(u.locked_until) > new Date()) return res.status(429).json({ success: false, message: 'Too many wrong attempts. This account is locked for a few minutes.' });
    const ok = u ? await verifyPassword(String(password || ''), u.pass_hash) : (await verifyPassword('x', 'scrypt$AAAA$AAAA'), false);
    if (!ok) { if (u) await registerFailure(u, req); return res.status(401).json({ success: false, message: 'Wrong username or password.' }); }
    if (u.totp_enabled) {
      if (!totp) return res.status(200).json({ success: false, needTotp: true, message: 'Enter the 6-digit code from your authenticator app.' });
      const counter = sec.verifyTotp(decrypt(u.totp_secret_enc, KEY), totp, { minCounter: u.totp_last_counter });
      if (counter === null) { await registerFailure(u, req); return res.status(401).json({ success: false, needTotp: true, message: 'Wrong or already-used code.' }); }
      await q('UPDATE users SET totp_last_counter=$2 WHERE id=$1', [u.id, counter]);
    }
    await q('UPDATE users SET failed_logins=0, locked_until=NULL WHERE id=$1', [u.id]);
    res.status(200).json({ success: true, token: await newSession(u.id), mustChangePassword: u.must_change_password });
  }));

  app.post('/api/auth/logout', userAuth, h(async (req, res) => {
    await q('DELETE FROM sessions WHERE token_hash=$1', [req.tokenHash]);
    res.json({ success: true });
  }));

  // ---------- trading controls ----------
  const numOrNull = v => (v === null || v === undefined ? null : Number(v));
  function limitsView(u) {
    const e = effective(u);
    return { ...ownView(e), dailyLossLimitUsd: numOrNull(u.daily_loss_limit_usd), sizeMultMax: 1, pctMax: STD.userPctMax, pctConfirmAbove: STD.userPctConfirmAbove,
      ceilings: { maxTradeUsd: numOrNull(e.max_trade_usd), maxLeverage: minPositive(MAX_USER_LEVERAGE, u.max_lev_ceiling) || null } };
  }
  // what "restore" puts a manual user's controls back to: the master plan's own values
  function defaultsFor() {
    return { sizeMode: masterPlan.sizeMode, sizeMult: 1, sizeUsd: masterPlan.sizeUsd, sizePct: masterPlan.sizePct, dailyLossLimitUsd: null };
  }
  const planColumns = () => [masterPlan.sizeMode, 1, masterPlan.sizeUsd, masterPlan.sizePct, null];

  app.get('/api/me', userAuth, h(async (req, res) => {
    const u = req.user;
    const s = await q(`SELECT COALESCE(SUM(closed_pnl),0) AS pnl, COUNT(*) AS trades, COUNT(*) FILTER (WHERE closed_pnl>0) AS wins FROM pnl_ledger WHERE user_id=$1`, [u.id]);
    const f = await q('SELECT COALESCE(SUM(amount),0) AS funding FROM funding_ledger WHERE user_id=$1', [u.id]);
    const first = await q('SELECT equity FROM equity_snap WHERE user_id=$1 ORDER BY day LIMIT 1', [u.id]);
    const ledger = await q(`SELECT symbol, side, qty, closed_pnl, closed_at FROM pnl_ledger WHERE user_id=$1 ORDER BY closed_at DESC LIMIT 40`, [u.id]);
    const t = s.rows[0];
    const todayPnl = await todaysPnl(u.id);
    const eff = effective(u);
    // the loss meter shows whichever daily limit bites first: the USD limit, or the % of the balance the day started with
    const pctLimit = Number(eff.daily_loss_pct) > 0 && Number(u.last_equity) > 0 ? (Number(u.last_equity) - todayPnl) * Number(eff.daily_loss_pct) / 100 : 0;
    const lossLimitNow = minPositive(eff.daily_loss_limit_usd, pctLimit) || null;
    res.json({
      success: true, username: u.username, paused: u.paused, active: u.active, hasKey: !!u.key_enc, env: normEnv(u.key_env), demoKeys: DEMO_KEYS_ALLOWED,
      keyStatus: u.key_status, keyError: u.key_error, equity: u.last_equity === null ? null : Number(u.last_equity),
      pnl: Number(t.pnl), funding: Number(f.rows[0].funding), trades: Number(t.trades), wins: Number(t.wins),
      shareToken: u.share_token || null, shareShowBalance: !!u.share_show_balance,
      mustChangePassword: !!u.must_change_password, totpEnabled: !!u.totp_enabled,
      telegram: { available: tgOn, linked: !!u.tg_chat_id, notify: u.tg_notify !== false, botUsername: tgBotUsername },
      limits: limitsView(u), defaults: defaultsFor(), plan: masterPlan, globalPause: pausedAll, dry: isDry(u),
      control: 'manual', allowManual: true, manualAckAt: u.manual_ack_at || null,
      planMatch: 100, standard: { ...STD }, notice: u.notice || null, noticeAt: u.notice_at || null,
      rails: { maxOpenTrades: masterPlan.maxOpenTrades, dailyLossPct: masterPlan.dailyLossPct, drawdownStopPct: masterPlan.drawdownStopPct, maxTradeUsd: masterPlan.maxTradeUsd },
      startEquity: first.rows[0] ? Number(first.rows[0].equity) : null,
      todayPnl, lossLimit: lossLimitNow === null || lossLimitNow === undefined ? null : Number(lossLimitNow),
      ledger: ledger.rows.map(r => ({ symbol: r.symbol, side: r.side, qty: Number(r.qty), pnl: Number(r.closed_pnl), at: r.closed_at })),
    });
  }));

  // ----- new: the user's own open trades (live from Bybit, cached 10s) and result curve -----
  const openCache = new Map();
  app.get('/api/me/open', userAuth, h(async (req, res) => {
    const u = req.user;
    if (!u.key_enc || u.key_status === 'error') return res.json({ success: true, open: [] });
    const hit = openCache.get(u.id);
    if (hit && Date.now() - hit.at < 10000) return res.json({ success: true, open: hit.open });
    try {
      const list = await listOpenPositions(userClient(u));
      const fin = v => (v !== undefined && v !== null && v !== '' && Number.isFinite(Number(v)) ? Number(v) : null);
      const open = list.map(p => ({
        symbol: p.symbol, side: p.side === 'Buy' ? 'LONG' : 'SHORT', size: fin(p.size), entry: fin(p.avgPrice), mark: fin(p.markPrice),
        pnl: fin(p.unrealisedPnl) === null ? 0 : fin(p.unrealisedPnl), leverage: fin(p.leverage) > 0 ? fin(p.leverage) : null,
        stop: fin(p.stopLoss) > 0 ? fin(p.stopLoss) : null, target: fin(p.takeProfit) > 0 ? fin(p.takeProfit) : null,
      }));
      openCache.set(u.id, { at: Date.now(), open });
      res.json({ success: true, open });
    } catch (e) {
      res.json({ success: false, message: 'Could not read your open trades from Bybit right now.' });
    }
  }));

  // cumulative result per day (closed PnL plus funding) for the last N days, one point per day with gaps filled
  async function resultSeries(userId, days) {
    const vals = [String(days)], who = userId ? ' AND user_id=$2' : '';
    if (userId) vals.push(userId);
    // the window starts at 00:00 UTC of the first day shown, so every row counted lands in a day we return
    const from = `(date_trunc('day', now() AT TIME ZONE 'UTC') - ($1 || ' days')::interval + interval '1 day') AT TIME ZONE 'UTC'`;
    const r = await q(`SELECT to_char(day, 'YYYY-MM-DD') AS d, SUM(v) AS v FROM (
        SELECT date_trunc('day', closed_at AT TIME ZONE 'UTC') AS day, closed_pnl AS v FROM pnl_ledger WHERE closed_at >= ${from}${who}
        UNION ALL
        SELECT date_trunc('day', at AT TIME ZONE 'UTC') AS day, amount AS v FROM funding_ledger WHERE at >= ${from}${who}
      ) x GROUP BY day ORDER BY day`, vals);
    const by = {};
    for (const x of r.rows) by[x.d] = Number(x.v);
    const out = [];
    let run = 0;
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
      run += by[d] || 0;
      out.push({ day: d, net: Math.round(run * 100) / 100 });
    }
    return out;
  }
  const seriesDays = req => Math.min(365, Math.max(2, parseInt((req.query || {}).days, 10) || 30));
  app.get('/api/me/series', userAuth, h(async (req, res) => { res.json({ success: true, points: await resultSeries(req.user.id, seriesDays(req)) }); }));

  app.post('/api/me/pause', userAuth, h(async (req, res) => {
    const paused = !!(req.body && req.body.paused);
    // resuming restarts the drawdown measurement from the current balance (otherwise the stop would re-trigger on the very next signal)
    await q(paused ? 'UPDATE users SET paused=TRUE WHERE id=$1' : 'UPDATE users SET paused=FALSE, equity_peak=NULL WHERE id=$1', [req.user.id]);
    let closed = null;
    if (paused && req.body && req.body.closeAll === true) {
      closed = await enqueue(req.user.id, () => closeAllForUser(req.user, 'user paused and closed everything'));
      await audit(req.user.username, 'pause_and_close_all', req.user.username, req, JSON.stringify(closed));
    }
    res.json({ success: true, closed });
  }));

  // emergency button: closes everything open on this user's account right now (does not pause or change settings)
  app.post('/api/me/close-all', userAuth, limited, h(async (req, res) => {
    if (!req.user.key_enc) return res.status(400).json({ success: false, message: 'No API key on your account.' });
    if (!(req.body && req.body.confirm === true)) return res.status(400).json({ success: false, message: 'Confirmation required.' });
    const r = await enqueue(req.user.id, () => closeAllForUser(req.user, 'user pressed close all'));
    await audit(req.user.username, 'close_all', req.user.username, req, JSON.stringify(r));
    if (r.error) return res.status(502).json({ success: false, message: "Couldn't reach Bybit: " + r.error });
    res.json({ success: true, closed: r.closed, failed: r.failed });
  }));

  // manual mode only: put the trade amount and loss limit back to the master plan's values (autopilot users have nothing to restore)
  app.post('/api/me/reset-defaults', userAuth, h(async (req, res) => {
    await q('UPDATE users SET size_mode=$2, size_mult=$3, size_usd=$4, size_pct=$5, daily_loss_limit_usd=$6 WHERE id=$1', [req.user.id, ...planColumns()]);
    await audit(req.user.username, 'limits_reset', req.user.username, req, 'restored to the standard trade size');
    res.json({ success: true });
  }));

  // Retired: there is no Autopilot/Manual switch any more (everyone has "Your settings"). Kept so an old open page does not error.
  app.post('/api/me/mode', userAuth, limited, h(async (req, res) => {
    res.json({ success: true, control: 'manual' });
  }));

  app.post('/api/me/password', userAuth, limited, h(async (req, res) => {
    const { current, next } = req.body || {};
    if (!(await verifyPassword(String(current || ''), req.user.pass_hash))) return res.status(400).json({ success: false, message: 'Your current password is wrong.' });
    if (typeof next !== 'string' || next.length < 10) return res.status(400).json({ success: false, message: 'New password must be at least 10 characters.' });
    if (next === current) return res.status(400).json({ success: false, message: 'Choose a different password.' });
    await q('UPDATE users SET pass_hash=$2, must_change_password=FALSE WHERE id=$1', [req.user.id, await hashPassword(next)]);
    await q('DELETE FROM sessions WHERE user_id=$1 AND token_hash<>$2', [req.user.id, req.tokenHash]); // every other device is signed out
    await audit(req.user.username, 'password_changed', req.user.username, req, '');
    res.json({ success: true });
  }));

  // two-factor (authenticator app)
  app.post('/api/me/2fa/setup', userAuth, h(async (req, res) => {
    if (req.user.totp_enabled) return res.status(400).json({ success: false, message: '2FA is already on.' });
    const secret = sec.newTotpSecret();
    await q('UPDATE users SET totp_secret_enc=$2 WHERE id=$1', [req.user.id, encrypt(secret, KEY)]);
    res.json({ success: true, secret, uri: sec.otpauthUri(req.user.username, secret, 'YM Oracle') });
  }));
  app.post('/api/me/2fa/enable', userAuth, limited, h(async (req, res) => {
    if (!req.user.totp_secret_enc) return res.status(400).json({ success: false, message: 'Start setup first.' });
    const counter = sec.verifyTotp(decrypt(req.user.totp_secret_enc, KEY), (req.body || {}).code);
    if (counter === null) return res.status(400).json({ success: false, message: 'That code is wrong. Check your phone clock and try the newest code.' });
    await q('UPDATE users SET totp_enabled=TRUE, totp_last_counter=$2 WHERE id=$1', [req.user.id, counter]);
    await audit(req.user.username, '2fa_enabled', req.user.username, req, '');
    res.json({ success: true });
  }));
  app.post('/api/me/2fa/disable', userAuth, limited, h(async (req, res) => {
    const { password, code } = req.body || {};
    if (!req.user.totp_enabled) return res.status(400).json({ success: false, message: '2FA is not on.' });
    if (!(await verifyPassword(String(password || ''), req.user.pass_hash))) return res.status(400).json({ success: false, message: 'Wrong password.' });
    if (sec.verifyTotp(decrypt(req.user.totp_secret_enc, KEY), code, { minCounter: req.user.totp_last_counter }) === null) return res.status(400).json({ success: false, message: 'Wrong code.' });
    await q('UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL, totp_last_counter=NULL WHERE id=$1', [req.user.id]);
    await audit(req.user.username, '2fa_disabled', req.user.username, req, '');
    res.json({ success: true });
  }));

  // The user's own trade size (percent of their balance, or a fixed amount) and optional USD loss limit.
  // Above 20% the page must send confirmHigh:true (the user has read the warning).
  app.post('/api/me/limits', userAuth, h(async (req, res) => {
    const u = req.user, body = { ...(req.body || {}) };
    delete body.sizeMult; // retired
    if (body.sizeMode === 'match') return res.status(400).json({ success: false, message: 'Choose a percent of your balance or a fixed amount.' });
    const parsed = parseControls(body, { current: ownView(effective(u)), allowed: MANUAL_KEYS, pctMax: STD.userPctMax,
      ceilUsd: Number(effective(u).max_trade_usd) > 0 ? Number(effective(u).max_trade_usd) : 0 });
    if (parsed.error) return res.status(400).json({ success: false, message: parsed.error });
    if (parsed.values.sizePct > STD.userPctConfirmAbove && body.confirmHigh !== true) return res.status(400).json({ success: false, needConfirm: true, message: 'More than ' + STD.userPctConfirmAbove + '% per trade risks a lot of your balance on a single signal. Confirm that you understand to continue.' });
    const colOf = { sizeMode: 'size_mode', sizeUsd: 'size_usd', sizePct: 'size_pct', dailyLossLimitUsd: 'daily_loss_limit_usd' };
    const sets = [], vals = [u.id];
    for (const [k, val] of Object.entries(parsed.values)) { vals.push(val); sets.push(colOf[k] + '=$' + vals.length); }
    // keep the unused field empty so one setting is always unambiguous
    if (parsed.values.sizeMode === 'percent') sets.push('size_usd=NULL'); else if (parsed.values.sizeMode === 'fixed') sets.push('size_pct=NULL');
    if (!sets.length) return res.status(400).json({ success: false, message: 'Nothing to change.' });
    sets.push('notice=NULL');
    await q('UPDATE users SET ' + sets.join(',') + ' WHERE id=$1', vals);
    await audit(u.username, 'limits_changed', u.username, req, JSON.stringify(body).slice(0, 200));
    res.json({ success: true });
  }));

  // The user's own recent signals in plain words: copied, skipped (and why), or failed. A skipped trade is never silent.
  const OUTCOME_TEXT = { OK: 'Copied', DRY: 'Practice only, nothing was sent' };
  app.get('/api/me/activity', userAuth, h(async (req, res) => {
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 30));
    const r = await q(`SELECT created_at, symbol, side, qty, code, ok, detail, risk_usd FROM order_log
        WHERE user_id=$1 AND kind='ORDER' AND code<>'PENDING' AND code NOT IN ('DUP','PAPER') ORDER BY id DESC LIMIT $2`, [req.user.id, limit]);
    const eq = Number(req.user.last_equity) || 0;
    const SKIP = new Set(['FILT', 'MAXT', 'HALT', 'MINQ', 'BAL', 'HELD', 'PAIR', 'NOPOS', 'SIDE']);
    res.json({ success: true, items: r.rows.map(x => {
      const outcome = x.code === 'OK' ? 'copied' : x.code === 'DRY' ? 'practice' : SKIP.has(x.code) ? 'skipped' : 'failed';
      const risk = x.risk_usd === null ? null : Number(x.risk_usd);
      return { at: x.created_at, symbol: x.symbol, side: x.side === 'Buy' ? 'LONG' : x.side === 'Sell' ? 'SHORT' : null, qty: x.qty === null ? null : Number(x.qty), outcome,
        text: outcome === 'copied' ? 'Copied' : outcome === 'practice' ? x.detail : (x.detail || CODE_TEXT[x.code] || 'Not copied'),
        riskUsd: risk, riskPct: risk !== null && eq > 0 ? Math.round(risk / eq * 1000) / 10 : null };
    }) });
  }));

  // the user has read the notice about the change to their trade size
  app.post('/api/me/notice/dismiss', userAuth, h(async (req, res) => { await q('UPDATE users SET notice=NULL WHERE id=$1', [req.user.id]); res.json({ success: true }); }));

  // telegram
  app.post('/api/me/telegram/link', userAuth, h(async (req, res) => {
    if (!tgOn) return res.status(400).json({ success: false, message: 'Telegram alerts are not set up on this server.' });
    const code = crypto.randomBytes(4).toString('hex').toUpperCase();
    await q(`UPDATE users SET tg_link_code=$2, tg_link_expires=now() + interval '15 minutes' WHERE id=$1`, [req.user.id, code]);
    res.json({ success: true, code, botUsername: tgBotUsername, minutes: 15 });
  }));
  app.post('/api/me/telegram/unlink', userAuth, h(async (req, res) => {
    await q('UPDATE users SET tg_chat_id=NULL, tg_link_code=NULL, tg_link_expires=NULL WHERE id=$1', [req.user.id]);
    res.json({ success: true });
  }));
  app.post('/api/me/telegram/notify', userAuth, h(async (req, res) => {
    await q('UPDATE users SET tg_notify=$2 WHERE id=$1', [req.user.id, !!(req.body && req.body.enabled)]);
    res.json({ success: true });
  }));
  app.post('/api/me/telegram/test', userAuth, h(async (req, res) => {
    if (!req.user.tg_chat_id) return res.status(400).json({ success: false, message: 'Connect Telegram first.' });
    const ok = await tgSend(req.user.tg_chat_id, '✅ Test alert from YM Oracle. Alerts are working.');
    res.json({ success: ok, message: ok ? undefined : 'Telegram did not accept the message.' });
  }));

  app.post('/api/me/key', userAuth, limited, h(async (req, res) => {
    const { apiKey, apiSecret } = req.body || {};
    if (!apiKey || !apiSecret) return res.status(400).json({ success: false, message: 'Key and secret are required.' });
    const prevEnv = normEnv(req.user.key_env);
    const env = req.body && req.body.env ? normEnv(req.body.env) : prevEnv;
    if (env === 'demo' && !DEMO_KEYS_ALLOWED) return res.status(400).json({ success: false, message: 'Demo keys are switched off on this server. Use a live key.' });
    const v = await validateKey(String(apiKey).trim(), String(apiSecret).trim(), env);
    if (!v.ok) return res.status(400).json({ success: false, message: v.message });
    const switched = req.user.key_enc && env !== prevEnv;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (switched) {
        // The results of the environment being left are filed away, so demo money never shows up in live numbers (or the reverse).
        await client.query(`INSERT INTO pnl_ledger_old SELECT l.*, $2, now() FROM pnl_ledger l WHERE user_id=$1`, [req.user.id, prevEnv]);
        await client.query(`DELETE FROM pnl_ledger WHERE user_id=$1`, [req.user.id]);
        await client.query(`INSERT INTO funding_ledger_old SELECT f.*, $2, now() FROM funding_ledger f WHERE user_id=$1`, [req.user.id, prevEnv]);
        await client.query(`DELETE FROM funding_ledger WHERE user_id=$1`, [req.user.id]);
        await client.query(`DELETE FROM equity_snap WHERE user_id=$1`, [req.user.id]);
      }
      await client.query(`UPDATE users SET key_enc=$2, key_hash=$3, key_status='ok', key_error=NULL, ips_unrestricted=$4, last_equity=$5, key_env=$6${switched ? ", paused=TRUE, equity_peak=NULL, last_pnl_sync_ms=$7, last_funding_sync_ms=$7" : ''} WHERE id=$1`,
        [req.user.id, encrypt(JSON.stringify({ k: String(apiKey).trim(), s: String(apiSecret).trim() }), KEY), sha256(String(apiKey).trim()), v.ipsUnrestricted, v.equity, env].concat(switched ? [Date.now()] : []));
      await client.query('COMMIT');
    } catch (e) {
      await client.query('ROLLBACK').catch(() => {});
      if (e.code === '23505') return res.status(400).json({ success: false, message: 'This API key is already registered.' });
      throw e;
    } finally { client.release(); }
    await audit(req.user.username, 'key_replaced', req.user.username, req, switched ? prevEnv + ' -> ' + env + ' (history filed away, trading paused)' : env);
    res.json({ success: true, warnings: v.warnings, env, switched: !!switched, pausedForSwitch: !!switched });
  }));

  // Wipes the stored key. The PnL history stays (that is the point of the ledger).
  app.post('/api/me/remove-key', userAuth, h(async (req, res) => {
    try { await syncUser(req.user); } catch { /* final sync is best-effort; the key may already be dead */ }
    await q(`UPDATE users SET key_enc=NULL, key_hash=NULL, key_status='removed', paused=TRUE WHERE id=$1`, [req.user.id]);
    await audit(req.user.username, 'key_removed', req.user.username, req, '');
    res.json({ success: true });
  }));

  // ---------- public monitoring link (read-only, opt-in, revocable) ----------
  app.post('/api/me/share', userAuth, h(async (req, res) => {
    const b = req.body || {};
    let token = req.user.share_token || null;
    if (b.enabled === false) token = null;
    else if (b.regenerate === true || (b.enabled === true && !token)) token = crypto.randomBytes(18).toString('base64url');
    const showBal = typeof b.showBalance === 'boolean' ? b.showBalance : !!req.user.share_show_balance;
    await q('UPDATE users SET share_token=$2, share_show_balance=$3 WHERE id=$1', [req.user.id, token, showBal]);
    await audit(req.user.username, 'share_link_changed', req.user.username, req, token ? (b.regenerate ? 'regenerated' : 'on') : 'off');
    res.json({ success: true, token, showBalance: showBal });
  }));

  const pubLimiter = sec.makeLimiter({ windowMs: 60000, max: 120 });
  const publicHeaders = { 'X-Robots-Tag': 'noindex, nofollow', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' };
  app.get('/api/share/:token', h(async (req, res) => {
    res.set(publicHeaders);
    if (!pubLimiter.hit(req.ip || 'x')) return res.status(429).json({ success: false, message: 'Slow down.' });
    await ready;
    const t = String(req.params.token || '');
    if (!/^[A-Za-z0-9_-]{20,40}$/.test(t)) return res.status(404).json({ success: false, message: 'Link not found' });
    const ur = await q('SELECT id, username, paused, active, key_status, last_equity, last_synced_at, created_at, share_show_balance, key_env FROM users WHERE share_token=$1', [t]);
    const u = ur.rows[0];
    if (!u) return res.status(404).json({ success: false, message: 'Link not found or switched off' });
    const rows = (await q('SELECT symbol, side, closed_pnl, closed_at FROM pnl_ledger WHERE user_id=$1 ORDER BY closed_at ASC LIMIT 1000', [u.id])).rows;
    const fund = (await q('SELECT amount, at FROM funding_ledger WHERE user_id=$1 ORDER BY at ASC LIMIT 1000', [u.id])).rows;
    const events = rows.map(r => ({ at: new Date(r.closed_at).getTime(), v: Number(r.closed_pnl) })).concat(fund.map(f => ({ at: new Date(f.at).getTime(), v: Number(f.amount) }))).sort((a, b) => a.at - b.at);
    let run = 0;
    const curve = events.map(e => { run += e.v; return Math.round(run * 100) / 100; });
    const fundingTotal = fund.reduce((a, f) => a + Number(f.amount), 0);
    const wins = rows.filter(r => Number(r.closed_pnl) > 0).length;
    res.json({
      success: true, username: u.username, env: normEnv(u.key_env),
      status: (u.active && !u.paused && u.key_status === 'ok') ? 'Active' : 'Not trading',
      since: u.created_at, lastSyncedAt: u.last_synced_at,
      pnl: Math.round(run * 100) / 100, funding: Math.round(fundingTotal * 100) / 100, trades: rows.length, wins, curve,
      balance: u.share_show_balance && u.last_equity !== null ? Number(u.last_equity) : null,
      recent: rows.slice(-40).reverse().map(r => ({ symbol: r.symbol, side: r.side, pnl: Number(r.closed_pnl), at: r.closed_at })),
    });
  }));

  // ---------- admin (session login + optional authenticator code; refuses to work without DASHBOARD_PASSWORD) ----------
  const adminLimiter = sec.makeLimiter({ windowMs: 15 * 60000, max: 8 });
  let adminLastCounter = 0;
  app.post('/api/admin/login', h(async (req, res) => {
    const pw = process.env.DASHBOARD_PASSWORD || '';
    if (!pw) return res.status(503).json({ success: false, message: 'Set DASHBOARD_PASSWORD on Render first. Admin is disabled without it.' });
    if (!adminLimiter.hit(req.ip || 'x')) { await audit('admin', 'admin_login_blocked', null, req, 'rate limited'); return res.status(429).json({ success: false, message: 'Too many attempts. Try again in 15 minutes.' }); }
    await ready;
    const { password, totp } = req.body || {};
    const adminTotp = process.env.ADMIN_TOTP_SECRET || '';
    if (!sec.safeEqual(String(password || ''), pw)) { await audit('admin', 'admin_login_failed', null, req, ''); return res.status(401).json({ success: false, message: 'Wrong password or code.' }); }
    if (adminTotp) {
      if (!totp) return res.status(200).json({ success: false, needTotp: true, message: 'Enter the 6-digit code from your authenticator app.' });
      const counter = sec.verifyTotp(adminTotp, totp, { minCounter: adminLastCounter });
      if (counter === null) { await audit('admin', 'admin_login_failed', null, req, 'bad code'); return res.status(401).json({ success: false, needTotp: true, message: 'Wrong password or code.' }); }
      adminLastCounter = counter;
    }
    const token = crypto.randomBytes(32).toString('hex');
    await q(`INSERT INTO admin_sessions(token_hash,expires_at) VALUES($1, now() + ($2 || ' hours')::interval)`, [sha256(token), String(ADMIN_SESSION_HOURS)]);
    adminLimiter.reset(req.ip || 'x');
    await audit('admin', 'admin_login', null, req, '');
    res.json({ success: true, token, hours: ADMIN_SESSION_HOURS });
  }));
  async function verifyAdminToken(token) {
    if (!process.env.DASHBOARD_PASSWORD || !token) return false;
    await ready;
    const r = await q('SELECT 1 FROM admin_sessions WHERE token_hash=$1 AND expires_at > now()', [sha256(String(token))]);
    return !!r.rows[0];
  }
  const adminAuth = h(async (req, res, next) => {
    if (!process.env.DASHBOARD_PASSWORD) return res.status(503).json({ success: false, message: 'Admin is disabled until DASHBOARD_PASSWORD is set.' });
    await ready;
    const m = /^Bearer (.+)$/.exec(req.get('Authorization') || '');
    if (!m) return res.status(401).json({ success: false, message: 'Not signed in' });
    const r = await q('SELECT 1 FROM admin_sessions WHERE token_hash=$1 AND expires_at > now()', [sha256(m[1])]);
    if (!r.rows[0]) return res.status(401).json({ success: false, message: 'Session expired' });
    req.adminTokenHash = sha256(m[1]);
    next();
  });
  app.post('/api/admin/logout', adminAuth, h(async (req, res) => { await q('DELETE FROM admin_sessions WHERE token_hash=$1', [req.adminTokenHash]); res.json({ success: true }); }));

  app.get('/api/admin/users', adminAuth, h(async (req, res) => {
    const r = await q(`
      SELECT u.id, u.username, u.active, u.paused, u.key_status, u.key_error, u.size_mult, u.size_mult_max, u.daily_loss_limit_usd, u.ips_unrestricted,
             u.size_mode, u.size_usd, u.size_pct, u.max_open_trades, u.symbols_allow, u.direction, u.user_max_lev, u.max_trade_usd, u.max_lev_ceiling, u.control_mode, u.manual_ack_at, u.dry_run,
             u.created_at, u.last_equity, u.last_synced_at, u.totp_enabled, u.key_env, (u.tg_chat_id IS NOT NULL) AS tg_linked,
             COALESCE((SELECT SUM(closed_pnl) FROM pnl_ledger WHERE user_id=u.id),0) AS pnl,
             (SELECT COUNT(*) FROM pnl_ledger WHERE user_id=u.id) AS trades,
             (SELECT COUNT(*) FROM pnl_ledger WHERE user_id=u.id AND closed_pnl>0) AS wins,
             COALESCE((SELECT SUM(amount) FROM funding_ledger WHERE user_id=u.id),0) AS funding,
             (SELECT equity FROM equity_snap s WHERE s.user_id=u.id ORDER BY day LIMIT 1) AS start_equity,
             (SELECT AVG(slippage_bps) FROM order_log WHERE user_id=u.id AND kind='ORDER' AND slippage_bps IS NOT NULL) AS slip
      FROM users u ORDER BY u.id`);
    const users = r.rows.map(x => {
      const eff = effective(x);
      const pnl = Number(x.pnl), funding = Number(x.funding);
      const start = x.start_equity === null ? null : Number(x.start_equity);
      const eq = x.last_equity === null ? null : Number(x.last_equity);
      return {
        id: x.id, username: x.username, active: x.active, paused: x.paused, keyStatus: x.key_status, keyError: x.key_error,
        sizeMult: Number(x.size_mult), sizeMultMax: Number(x.size_mult_max), dailyLossLimitUsd: x.daily_loss_limit_usd === null ? null : Number(x.daily_loss_limit_usd),
        dryRun: !!x.dry_run, controlMode: eff.control_mode, planMatch: null,
        sizeMode: eff.size_mode, sizeUsd: numOrNull(eff.size_usd), sizePct: numOrNull(eff.size_pct), maxOpenTrades: eff.max_open_trades,
        coins: eff.symbols_allow ? String(eff.symbols_allow).split(',').length : null, direction: eff.direction, userMaxLeverage: numOrNull(eff.user_max_lev),
        maxTradeUsd: numOrNull(x.max_trade_usd), maxLeverageCeiling: numOrNull(x.max_lev_ceiling),
        ipsUnrestricted: x.ips_unrestricted, createdAt: x.created_at, equity: eq, lastSyncedAt: x.last_synced_at,
        totpEnabled: x.totp_enabled, tgLinked: x.tg_linked, env: normEnv(x.key_env),
        pnl, funding, net: pnl + funding, trades: Number(x.trades), wins: Number(x.wins), startEquity: start,
        // what the balance change can't be explained by trading = money moved in or out (an estimate; snapshots are daily)
        estNetDeposits: (start !== null && eq !== null) ? Math.round((eq - start - pnl - funding) * 100) / 100 : null,
        avgSlippageBps: x.slip === null ? null : Math.round(Number(x.slip) * 10) / 10,
      };
    });
    res.json({ success: true, users, pausedAll, dryAll, planVersion, plan: masterPlan, totalPnl: users.reduce((a, b) => a + b.pnl, 0), totalNet: users.reduce((a, b) => a + b.net, 0) });
  }));

  app.post('/api/admin/users/:id', adminAuth, h(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const b = req.body || {};
    const sets = [], vals = [id];
    const add = (col, v) => { vals.push(v); sets.push(col + '=$' + vals.length); };
    if (typeof b.paused === 'boolean') { add('paused', b.paused); if (!b.paused) sets.push('equity_peak=NULL'); }
    if (typeof b.active === 'boolean') add('active', b.active);
    if (b.controlMode === 'auto') sets.push(`control_mode='auto'`);
    if (typeof b.dryRun === 'boolean') add('dry_run', b.dryRun);
    if (b.sizeMult !== undefined && Number(b.sizeMult) > 0 && Number(b.sizeMult) <= 20) { add('size_mult', Number(b.sizeMult)); add('size_mult_max', Number(b.sizeMult)); }
    if (b.dailyLossLimitUsd !== undefined) add('daily_loss_limit_usd', b.dailyLossLimitUsd === null || b.dailyLossLimitUsd === '' ? null : Math.max(0, Number(b.dailyLossLimitUsd)));
    if (b.maxTradeUsd !== undefined) {
      const v = posOrNull(b.maxTradeUsd, 1e7); if (Number.isNaN(v)) return res.status(400).json({ success: false, message: 'Max trade amount must be a positive number, or empty for no limit.' });
      add('max_trade_usd', v);
      // pull the user's own amount down under the new ceiling (a CASE, not LEAST(): LEAST ignores NULL and would invent a value)
      if (v !== null) sets.push(`size_usd=CASE WHEN size_usd > $${vals.length} THEN $${vals.length} ELSE size_usd END`);
    }
    if (b.maxLeverage !== undefined) {
      const v = posOrNull(b.maxLeverage, 125); if (Number.isNaN(v)) return res.status(400).json({ success: false, message: 'Max leverage must be between 1 and 125, or empty for no limit.' });
      add('max_lev_ceiling', v);
      if (v !== null) sets.push(`user_max_lev=CASE WHEN user_max_lev > $${vals.length} THEN $${vals.length} ELSE user_max_lev END`);
    }
    if (b.clearKeyError === true) { sets.push(`key_status=CASE WHEN key_enc IS NULL THEN key_status ELSE 'ok' END`); sets.push('key_error=NULL'); }
    if (!sets.length) return res.status(400).json({ success: false, message: 'Nothing to change' });
    await q(`UPDATE users SET ${sets.join(',')} WHERE id=$1`, vals);
    await audit('admin', 'user_updated', String(id), req, JSON.stringify(b).slice(0, 150));
    res.json({ success: true });
  }));

  // ----- the Master Plan: one set of settings for every autopilot account -----
  app.get('/api/admin/plan', adminAuth, h(async (req, res) => {
    const c = await q(`SELECT COUNT(*) AS total FROM users WHERE key_enc IS NOT NULL AND active`);
    const total = Number(c.rows[0].total);
    res.json({ success: true, plan: masterPlan, defaults: PLAN_DEFAULT, standard: { ...STD }, manualUsers: total, autoUsers: 0, accounts: total, masterFollowsPlan: masterFollows() });
  }));

  // Switches the live plan, records a new history row, restarts the drawdown measurement if that rule changed.
  async function applyPlan(newPlan, req, restoredFrom) {
    const before = masterPlan;
    masterPlan = newPlan;
    await q(`INSERT INTO meta(k,v) VALUES('master_plan',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(masterPlan)]);
    if (masterPlan.drawdownStopPct !== before.drawdownStopPct) await q('UPDATE users SET equity_peak=NULL'); // a changed drawdown rule restarts everyone's "highest balance" measurement
    const diff = planDiff(before, masterPlan);
    const summary = (restoredFrom ? 'Restored version ' + restoredFrom + (diff.length ? ': ' : '') : '') + diff.map(d => d.text).join('; ');
    planVersion = await saveVersion('admin', summary || 'Saved (no changes)', restoredFrom);
    await audit('admin', restoredFrom ? 'plan_restored' : 'plan_changed', 'all', req, ('v' + planVersion + ' ' + summary).slice(0, 300));
    return { diff, version: planVersion };
  }
  const mergePlan = body => { const b = { ...(body || {}) }; delete b.sizeMult; delete b.maxLeverage; return parseControls(b, { current: masterPlan, allowed: CONTROL_KEYS.concat(['allowManual']), openMax: STD.adminMaxOpen }); };

  app.post('/api/admin/plan', adminAuth, h(async (req, res) => {
    const parsed = mergePlan(req.body);
    if (parsed.error) return res.status(400).json({ success: false, message: parsed.error });
    if (!Object.keys(parsed.values).length) return res.status(400).json({ success: false, message: 'Nothing to change.' });
    const r = await applyPlan({ ...masterPlan, ...parsed.values }, req, null);
    res.json({ success: true, plan: masterPlan, version: r.version, changes: r.diff.map(d => d.text) });
  }));

  // "What would this change?" without saving: the differences, how many accounts follow the plan, and (for amount changes) a sample trade for each
  app.post('/api/admin/plan/preview', adminAuth, h(async (req, res) => {
    const parsed = mergePlan(req.body);
    if (parsed.error) return res.status(400).json({ success: false, message: parsed.error });
    const next = { ...masterPlan, ...parsed.values };
    const diff = planDiff(masterPlan, next);
    const c = await q(`SELECT COUNT(*) AS total FROM users WHERE key_enc IS NOT NULL AND active`);
    const total = Number(c.rows[0].total);
    res.json({ success: true, changes: diff, unchanged: !diff.length, autopilotAccounts: 0, manualAccounts: total, accounts: total, forcedToAutopilot: 0 });
  }));

  app.get('/api/admin/plan/history', adminAuth, h(async (req, res) => {
    const r = await q('SELECT id, plan, changed_by, summary, restored_from, created_at FROM plan_versions ORDER BY id DESC LIMIT $1', [Math.min(100, parseInt(req.query.limit, 10) || 30)]);
    const rows = r.rows.map(x => { let plan = null; try { plan = JSON.parse(x.plan); } catch { /* corrupt row: shown without values */ } return { id: x.id, plan, changedBy: x.changed_by, summary: x.summary, restoredFrom: x.restored_from, at: x.created_at, live: x.id === planVersion }; });
    res.json({ success: true, live: planVersion, versions: rows });
  }));

  app.post('/api/admin/plan/restore', adminAuth, h(async (req, res) => {
    const id = parseInt((req.body || {}).id, 10);
    const r = Number.isInteger(id) ? await q('SELECT plan FROM plan_versions WHERE id=$1', [id]) : { rows: [] };
    if (!r.rows[0]) return res.status(404).json({ success: false, message: 'No such plan version.' });
    let stored;
    try { stored = JSON.parse(r.rows[0].plan); } catch { return res.status(400).json({ success: false, message: 'That version is damaged and cannot be restored.' }); }
    const ok = parseControls(normalizeStoredPlan(stored), { current: PLAN_DEFAULT, allowed: CONTROL_KEYS.concat(['allowManual']) });
    if (ok.error) return res.status(400).json({ success: false, message: 'That version is not valid any more: ' + ok.error });
    const next = { ...PLAN_DEFAULT, ...ok.values };
    if (!planDiff(masterPlan, next).length) return res.status(400).json({ success: false, message: 'That is already the live plan.' });
    const out = await applyPlan(next, req, id);
    res.json({ success: true, plan: masterPlan, version: out.version, changes: out.diff.map(d => d.text) });
  }));

  // ----- dry run: every signal is worked out for every user (filters, limits, sizing) but nothing is sent to Bybit -----
  app.post('/api/admin/dry-run', adminAuth, h(async (req, res) => {
    if (typeof (req.body || {}).enabled !== 'boolean') return res.status(400).json({ success: false, message: 'Send enabled:true or enabled:false.' });
    dryAll = req.body.enabled;
    await q(`INSERT INTO meta(k,v) VALUES('dry_run_all',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [dryAll ? '1' : '0']);
    await audit('admin', dryAll ? 'dry_run_on' : 'dry_run_off', 'all', req, '');
    res.json({ success: true, dryAll });
  }));

  // ----- everyone at once -----
  app.post('/api/admin/pause-all', adminAuth, h(async (req, res) => {
    pausedAll = !!(req.body && req.body.paused);
    await q(`INSERT INTO meta(k,v) VALUES('users_paused_all',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [pausedAll ? '1' : '0']);
    await audit('admin', pausedAll ? 'pause_all_users' : 'resume_all_users', 'all', req, '');
    res.json({ success: true, pausedAll });
  }));

  app.post('/api/admin/close-all', adminAuth, h(async (req, res) => {
    if (!(req.body && req.body.confirm === 'CLOSE')) return res.status(400).json({ success: false, message: 'Send confirm:"CLOSE" to close every user\'s open trades.' });
    const users = (await q(`SELECT * FROM users WHERE key_enc IS NOT NULL AND active ORDER BY id`)).rows;
    let closed = 0, failed = 0;
    await runLimited(users, 5, u => enqueue(u.id, async () => {
      const r = await closeAllForUser(u, 'admin closed all trades');
      closed += r.closed; failed += r.failed;
      if (r.closed) notify(u, '🛑 The admin closed all open trades on your account (' + r.closed + ').');
    }));
    await audit('admin', 'close_all_users', 'all', req, 'closed ' + closed + ', failed ' + failed + ', users ' + users.length);
    res.json({ success: true, users: users.length, closed, failed });
  }));

  app.post('/api/admin/users/:id/reset-password', adminAuth, h(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const temp = crypto.randomBytes(9).toString('base64url'); // shown once; the user must change it at next login
    const r = await q('UPDATE users SET pass_hash=$2, must_change_password=TRUE, failed_logins=0, locked_until=NULL WHERE id=$1 RETURNING username', [id, await hashPassword(temp)]);
    if (!r.rows[0]) return res.status(404).json({ success: false, message: 'No such user' });
    await q('DELETE FROM sessions WHERE user_id=$1', [id]);
    await audit('admin', 'password_reset', r.rows[0].username, req, '');
    res.json({ success: true, username: r.rows[0].username, tempPassword: temp });
  }));
  app.post('/api/admin/users/:id/disable-2fa', adminAuth, h(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    const r = await q('UPDATE users SET totp_enabled=FALSE, totp_secret_enc=NULL, totp_last_counter=NULL WHERE id=$1 RETURNING username', [id]);
    if (!r.rows[0]) return res.status(404).json({ success: false, message: 'No such user' });
    await q('DELETE FROM sessions WHERE user_id=$1', [id]);
    await audit('admin', '2fa_disabled_by_admin', r.rows[0].username, req, '');
    res.json({ success: true });
  }));

  app.get('/api/admin/users/:id/ledger', adminAuth, h(async (req, res) => {
    const r = await q(`SELECT symbol, side, qty, entry_price, exit_price, closed_pnl, open_fee, close_fee, closed_at FROM pnl_ledger WHERE user_id=$1 ORDER BY closed_at DESC LIMIT $2`, [parseInt(req.params.id, 10), Math.min(500, parseInt(req.query.limit, 10) || 100)]);
    res.json({ success: true, rows: r.rows });
  }));
  app.get('/api/admin/orders', adminAuth, h(async (req, res) => {
    const where = [], vals = [];
    const qs = req.query || {};
    if (qs.user) { vals.push(String(qs.user)); where.push('u.username=$' + vals.length); }
    if (qs.code) { vals.push(String(qs.code).toUpperCase().slice(0, 8)); where.push('o.code=$' + vals.length); }
    if (qs.failed === '1') where.push(`o.ok=false AND o.code<>'PENDING'`);
    if (qs.dry === '1') where.push(`o.code='DRY'`);
    vals.push(Math.min(200, parseInt(qs.limit, 10) || 60));
    const r = await q(`SELECT o.id, u.username, o.kind, o.symbol, o.side, o.qty, o.code, o.ok, o.detail, o.slippage_bps, o.plan_version, o.created_at
      FROM order_log o JOIN users u ON u.id=o.user_id ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY o.id DESC LIMIT $${vals.length}`, vals);
    res.json({ success: true, rows: r.rows });
  }));

  // What a dry run (or the last day of live trading) did, per user: how many would trade, how many were skipped and why
  app.get('/api/admin/orders/summary', adminAuth, h(async (req, res) => {
    const hours = Math.min(168, Math.max(1, parseInt(req.query.hours, 10) || 24));
    const r = await q(`SELECT u.username, o.code, COUNT(*) AS n FROM order_log o JOIN users u ON u.id=o.user_id
      WHERE o.kind='ORDER' AND o.created_at > now() - ($1 || ' hours')::interval AND o.code<>'PENDING' GROUP BY u.username, o.code ORDER BY u.username, o.code`, [String(hours)]);
    const by = {};
    for (const x of r.rows) (by[x.username] = by[x.username] || {})[x.code] = Number(x.n);
    res.json({ success: true, hours, users: Object.entries(by).map(([username, codes]) => ({ username, codes })) });
  }));

  // ----- new: console cards (bots, signal feed, result curve) and per-user close-all -----
  app.get('/api/admin/series', adminAuth, h(async (req, res) => { res.json({ success: true, points: await resultSeries(null, seriesDays(req)) }); }));

  app.get('/api/admin/bots', adminAuth, h(async (req, res) => {
    const f = getFleet(), now = Date.now();
    const bots = Object.keys(f.last || {}).sort().map(name => {
      const info = (f.info || {})[name] || {};
      return { name, lastSeenAt: f.last[name], online: f.offlineMs ? (now - f.last[name]) < f.offlineMs : true,
        uptimeMin: info.uptimeMin === undefined ? null : info.uptimeMin, resetReason: info.resetReason || null,
        freeHeap: info.freeHeap === undefined ? null : info.freeHeap, build: info.build || null,
        relayOn: info.relayOn === undefined ? null : info.relayOn, relayMarginUsd: info.relayMarginUsd === undefined ? null : info.relayMarginUsd };
    });
    res.json({ success: true, bots });
  }));

  // What happened on the MASTER account (the one the bots trade directly) and whether the relay's records match Bybit.
  const MASTER_TEXT = {
    OK: 'Placed', DUP: 'Already placed', NOCHG: 'Already at that value', PAPER: 'Paper mode', NOPOS: 'Nothing open to change',
    BAL: 'Not enough free balance', MINQ: "Below Bybit's minimum size", PAIR: 'Pair not on Bybit', LEV: 'Bybit rejected the leverage',
    NET: "Couldn't reach Bybit", BYBIT: 'Bybit refused it', BAD: 'Command malformed', PRICE: 'Price did not match',
    HELD: 'Already holding this pair', HALT: 'Trading is halted', SIDE: 'Position is on the other side',
    NOTRL: 'Opened, trailing stop not set', SCALED: 'Opened smaller than asked', LEVCLMP: 'Opened at lower leverage',
  };
  const M_QUIET = new Set(['OK', 'DUP', 'NOCHG', 'PAPER', 'NOPOS']);
  const M_WARN = new Set(['NOTRL', 'SCALED', 'LEVCLMP', 'HELD', 'HALT', 'SIDE']);
  const mSev = r => (M_QUIET.has(r.code) ? 'quiet' : M_WARN.has(r.code) ? 'warn' : (r.ok ? 'quiet' : 'fail'));
  async function masterReports(hours, limit) {
    let rows = [];
    try {
      rows = (await q(`SELECT exec_id, bot, kind, symbol, side, ok, code, detail, created_at FROM master_log
        WHERE created_at > now() - ($1 || ' hours')::interval ORDER BY created_at DESC LIMIT $2`, [String(hours), limit])).rows
        .map(x => ({ id: x.exec_id, bot: x.bot, kind: x.kind, symbol: x.symbol, side: x.side, ok: x.ok, code: x.code, detail: x.detail, at: new Date(x.created_at).getTime() }));
    } catch (e) { console.error('[multiuser] master_log read:', e.message); }
    if (!rows.length) { const cut = Date.now() - hours * 3600000; rows = (getExecReports() || []).filter(r => r.at >= cut).slice(0, limit); } // nothing in the database yet: fall back to what the relay remembers
    return rows.map(r => ({ ...r, sev: mSev(r), text: MASTER_TEXT[r.code] || r.code || 'Unknown' }));
  }
  app.get('/api/admin/master', adminAuth, h(async (req, res) => {
    const hours = Math.min(168, Math.max(1, parseInt(req.query.hours, 10) || 24));
    const reports = await masterReports(hours, 40);
    const sy = getMasterSync() || {};
    const counts = { ok: 0, warn: 0, fail: 0 };
    reports.filter(r => r.kind === 'TRADE').forEach(r => { counts[r.sev === 'fail' ? 'fail' : r.sev === 'warn' ? 'warn' : 'ok']++; });
    res.json({ success: true, counts, reports: reports.slice(0, 12),
      sync: { mode: sy.mode || null, lastOkAt: sy.lastOkAt || null, lastRunAt: sy.lastRunAt || null, masterOpen: sy.masterOpen === undefined ? null : sy.masterOpen, loggedOpen: sy.loggedOpen === undefined ? null : sy.loggedOpen,
        recoveredTotal: sy.recoveredTotal || 0, lastRecovered: sy.lastRecovered || null, staleOpen: sy.staleOpen || 0, lastError: sy.lastError || null } });
  }));

  // one row per bot signal: when it arrived and what happened across all accounts (signals fan out within seconds, so a 2 minute bucket groups them)
  app.get('/api/admin/signals', adminAuth, h(async (req, res) => {
    const hours = Math.min(168, Math.max(1, parseInt(req.query.hours, 10) || 24));
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 8));
    const SK = `('FILT','MAXT','HALT','MINQ','BAL','HELD')`;
    const r = await q(`SELECT o.symbol, o.side, MIN(o.created_at) AS at,
        COUNT(*) FILTER (WHERE o.code='OK') AS placed,
        COUNT(*) FILTER (WHERE o.code='DRY') AS dry,
        COUNT(*) FILTER (WHERE o.code IN ${SK}) AS skipped,
        COUNT(*) FILTER (WHERE o.ok=false AND o.code NOT IN ${SK} AND o.code<>'PENDING') AS failed,
        COUNT(*) FILTER (WHERE o.code<>'PENDING') AS total
      FROM order_log o WHERE o.kind='ORDER' AND o.created_at > now() - ($1 || ' hours')::interval
      GROUP BY o.symbol, o.side, floor(extract(epoch from o.created_at) / 120)
      ORDER BY MIN(o.created_at) DESC LIMIT $2`, [String(hours), limit]);
    res.json({ success: true, signals: r.rows.map(x => ({ symbol: x.symbol, side: x.side === 'Buy' ? 'LONG' : 'SHORT', at: x.at,
      placed: Number(x.placed), dry: Number(x.dry), skipped: Number(x.skipped), failed: Number(x.failed), total: Number(x.total) })) });
  }));

  app.get('/api/admin/alerts', adminAuth, h(async (req, res) => {
    const r = await q(`SELECT k, bot, kind, sym, priv, text, created_at, sent_at, tries, last_result FROM bot_msgs ORDER BY created_at DESC LIMIT 15`);
    const un = await q(`SELECT COUNT(*)::int AS n FROM bot_msgs WHERE sent_at IS NULL AND created_at > now() - interval '2 hours'`);
    res.json({ success: true, undelivered: un.rows[0].n, alerts: r.rows.map(x => ({ key: x.k, bot: x.bot, kind: x.kind, sym: x.sym, text: stripTags(x.text).split('\n').filter(Boolean).slice(0, 2).join(' · ').slice(0, 160), at: x.created_at, sent: !!x.sent_at, tries: x.tries, result: x.last_result })) });
  }));
  app.post('/api/admin/test-alert', adminAuth, h(async (req, res) => {
    const to = (req.body && (req.body.target === 'group' || req.body.target === 'dm')) ? req.body.target : null;
    const label = to === 'group' ? 'the GROUP' : to === 'dm' ? 'your DM' : 'the chat(s) your alert settings choose';
    const r = await deliverAlert('✅ Test alert from the YM Oracle admin page, sent to ' + label + '. If you can read this, alerts from Render reach it.', to ? { force: to } : { cat: 'tests' });
    res.json({ success: !!r.ok, configured: r.configured !== false, telegram: r.telegram || null, email: r.email || null, muted: !!r.muted, reason: r.reason || null, tradeAlerts: tradeAlertsOn() });
  }));

  // Telegram routing: who gets what (group / DM / both / off), the Dev and Off modes, and an optional timer. Saved in the database, effective at once.
  const routeView = () => {
    const R = alertRouter.route, env = alertRouter.envChats(), cfg = alertRouter.state.cfg, now = Date.now();
    return { ...R.describe(cfg, now), tokenSet: alertRouter.tokenSet(), groupSet: !!(cfg.groupChat || env.groupChat), dmSet: !!(cfg.dmChat || env.dmChat),
      groupFromEnv: !cfg.groupChat && !!env.groupChat, dmFromEnv: !cfg.dmChat && !!env.dmChat, tradeAlerts: tradeAlertsOn(), now,
      cats: R.CAT_IDS.map(id => ({ id, label: R.CATS[id].label, hint: R.CATS[id].hint, def: R.CATS[id].def })) };
  };
  app.get('/api/admin/alert-routes', adminAuth, h(async (req, res) => {
    if (!alertRouter) return res.status(503).json({ success: false, message: 'not available' });
    res.json({ success: true, ...routeView() });
  }));
  app.post('/api/admin/alert-routes', adminAuth, h(async (req, res) => {
    if (!alertRouter) return res.status(503).json({ success: false, message: 'not available' });
    const R = alertRouter.route, b = req.body || {};
    if (b.mode !== undefined && !R.MODES.includes(b.mode)) return res.status(400).json({ success: false, message: 'mode must be live, dev or off' });
    if (b.routes && typeof b.routes === 'object') for (const [k, v] of Object.entries(b.routes)) if (!R.CAT_IDS.includes(k) || !R.DESTS.includes(v)) return res.status(400).json({ success: false, message: 'bad route for ' + k });
    for (const k of ['groupChat', 'dmChat']) if (b[k] !== undefined && String(b[k]).trim() !== '' && R.normalize({ [k]: b[k] })[k] === '') return res.status(400).json({ success: false, message: 'that chat id does not look right (use the number, e.g. -1001234567890, or @channelname)' });
    const next = R.fromRequest(b, Date.now(), alertRouter.state.cfg);
    // never let a setting silently swallow everything: dev mode and "DM" routes need a DM chat to land in
    const env = alertRouter.envChats();
    const dmKnown = !!(next.dmChat || env.dmChat);
    if (next.mode === 'dev' && !dmKnown) return res.status(400).json({ success: false, message: 'Dev mode sends everything to your DM, but no DM chat is set yet. Add your DM chat id first (ALERT_TELEGRAM_PRIVATE_CHAT_ID on Render, or the field on this panel).' });
    await q(`INSERT INTO meta(k,v) VALUES('alert_routes',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(next)]);
    alertRouter.state.cfg = next;
    await audit('admin', 'alert_routes_changed', null, req, (next.mode === 'live' ? 'live' : next.mode + (next.until ? ' until ' + new Date(next.until).toISOString() : ' until changed')) + ' ' + JSON.stringify(next.routes));
    res.json({ success: true, ...routeView() });
  }));

  // Profit Guard: settings, what it is watching, and its log. Going live needs an explicit confirm.
  app.get('/api/admin/profit-guard', adminAuth, h(async (req, res) => { res.json({ success: true, ...(await pgView()) }); }));
  app.post('/api/admin/profit-guard', adminAuth, h(async (req, res) => {
    const b = req.body || {};
    if (b.mode !== undefined && !PG.MODES.includes(b.mode)) return res.status(400).json({ success: false, message: 'mode must be off, shadow or live' });
    if (b.mode === 'live' && b.confirm !== 'LIVE') return res.status(400).json({ success: false, message: 'Going live moves real stops on Bybit. Confirm it on the panel.' });
    if (b.applyTuning !== undefined) {                 // apply the current suggestion for one profile (the server recomputes it: nothing is taken from the page)
      const pr = b.applyTuning; if (pr !== 'fast' && pr !== 'swing') return res.status(400).json({ success: false, message: 'applyTuning must be fast or swing' });
      if (PG.effMode(pgCfg, pr) === 'live' && b.confirm !== 'LIVE') return res.status(400).json({ success: false, message: 'This changes the live stop rules. Confirm it on the panel.' });
      const sug = await pgTuneEval(pr);
      if (!sug.ready || sug.action === 'hold' || !sug.next) return res.status(400).json({ success: false, message: 'There is nothing to apply: ' + sug.reasons.join(' ') });
      await pgApplyTuning(pr, sug, 'admin');
      return res.json({ success: true, ...(await pgView()) });
    }
    const sm = b.smart && typeof b.smart === 'object' ? { noise: { ...pgCfg.smart.noise, ...(b.smart.noise || {}) }, stall: { ...pgCfg.smart.stall, ...(b.smart.stall || {}) }, tune: { ...pgCfg.smart.tune, ...(b.smart.tune || {}), lastAtN: pgCfg.smart.tune.lastAtN } } : pgCfg.smart;
    const next = PG.normalize({ ...pgCfg, ...b, smart: sm, reentry: b.reentry ? { ...pgCfg.reentry, ...b.reentry } : pgCfg.reentry, fast: b.fast ? { ...pgCfg.fast, ...b.fast } : pgCfg.fast, swing: b.swing ? { ...pgCfg.swing, ...b.swing } : pgCfg.swing });
    if (next.smart.tune.mode === 'auto' && pgCfg.smart.tune.mode !== 'auto' && b.confirm !== 'LIVE') return res.status(400).json({ success: false, message: 'Auto-tuning changes the live stop rules by itself. Confirm it on the panel.' });
    for (const pr of ['fast', 'swing']) {      // anything that starts acting on real money needs the explicit confirm
      const goesLive = PG.effMode(next, pr) === 'live' && PG.effMode(pgCfg, pr) !== 'live';
      const scaleLive = PG.effMode(next, pr) === 'live' && next[pr].scale.on && !(PG.effMode(pgCfg, pr) === 'live' && pgCfg[pr].scale.on);
      if ((goesLive || scaleLive) && b.confirm !== 'LIVE') return res.status(400).json({ success: false, message: 'This moves real stops or closes real positions on Bybit. Confirm it on the panel.' });
    }
    await q(`INSERT INTO meta(k,v) VALUES('profit_guard',$1) ON CONFLICT (k) DO UPDATE SET v=EXCLUDED.v`, [JSON.stringify(next)]);
    const was = pgCfg.mode; pgCfg = next;
    await audit('admin', 'profit_guard_changed', null, req, was + ' -> ' + next.mode + ' ' + JSON.stringify({ fast: next.fast, swing: next.swing, minGapPct: next.minGapPct, smart: next.smart }));
    res.json({ success: true, ...(await pgView()) });
  }));

  // signal-first view: one row per bot signal with what the bot said, whether the order reached the relay, the master result and the copies
  app.get('/api/admin/signal-ledger', adminAuth, h(async (req, res) => {
    const hours = Math.min(168, Math.max(1, parseInt(req.query.hours, 10) || 24));
    const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 30));
    const SK = `('FILT','MAXT','HALT','MINQ','BAL','HELD','PAIR','NOPOS','SIDE')`;
    const r = await q(`SELECT s.*,
        (SELECT code FROM master_log m WHERE m.exec_id=s.rid AND m.kind='TRADE' ORDER BY created_at DESC LIMIT 1) AS master_code,
        (SELECT ok FROM master_log m WHERE m.exec_id=s.rid AND m.kind='TRADE' ORDER BY created_at DESC LIMIT 1) AS master_ok,
        (SELECT detail FROM master_log m WHERE m.exec_id=s.rid AND m.kind='TRADE' ORDER BY created_at DESC LIMIT 1) AS master_detail,
        COUNT(o.id) FILTER (WHERE o.code='OK') AS copied,
        COUNT(o.id) FILTER (WHERE o.code='DRY') AS dry,
        COUNT(o.id) FILTER (WHERE o.code IN ${SK}) AS skipped,
        COUNT(o.id) FILTER (WHERE o.ok=false AND o.code NOT IN ${SK} AND o.code<>'PENDING') AS failed
      FROM signals s LEFT JOIN order_log o ON o.signal_key = 'ym-' || s.rid AND o.kind='ORDER' AND s.rid IS NOT NULL AND s.rid <> ''
      WHERE s.opened_at > now() - ($1 || ' hours')::interval
      GROUP BY s.k ORDER BY s.opened_at DESC LIMIT $2`, [String(hours), limit]);
    const bots = (await q('SELECT bot, payload, at FROM bot_status ORDER BY bot')).rows.map(b => { let p = {}; try { p = JSON.parse(b.payload); } catch { /* ignore */ } return { bot: b.bot, at: b.at, build: p.build || null, open: p.open ?? null, cfg: p.cfg || null, relayq: p.relayq || null, webq: p.webq || null }; });
    res.json({ success: true, bots, signals: r.rows.map(x => {
      const reached = !!x.order_seen_at;
      let state = 'ok', text = '';
      if (x.relay_flag === 'NOT_SENT') { state = 'info'; text = 'The bot chose not to relay this one'; }
      else if (x.alarm_at && !reached) { state = 'bad'; text = 'Never reached the relay'; }
      else if (!reached && x.relay_flag === 'SENT') { state = 'warn'; text = 'Waiting for the order to arrive'; }
      else if (x.master_ok === false) { state = 'bad'; text = 'Refused on the master account' + (x.master_detail ? ': ' + x.master_detail : ''); }
      else if (reached) { text = 'Reached the relay' + (x.relay_secs !== null ? ' in ' + Number(x.relay_secs) + 's' : ''); }
      return { key: x.k, bot: x.bot, symbol: x.symbol, side: x.side === 'BUY' ? 'LONG' : x.side === 'SELL' ? 'SHORT' : null, engine: x.eng, at: x.opened_at, entry: numOrNull(x.entry), stop: numOrNull(x.sl), target: numOrNull(x.tp), leverage: numOrNull(x.lev),
        botSaid: x.relay_flag, reached, state, text, relayOk: x.relay_ok, relaySecs: numOrNull(x.relay_secs), masterCode: x.master_code || null, masterOk: x.master_ok,
        closed: !!x.closed_at, won: x.won, pct: numOrNull(x.pct),
        copied: Number(x.copied), dry: Number(x.dry), skipped: Number(x.skipped), failed: Number(x.failed) };
    }) });
  }));

  app.post('/api/admin/users/:id/close-all', adminAuth, h(async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!(req.body && req.body.confirm === 'CLOSE')) return res.status(400).json({ success: false, message: 'Send confirm:"CLOSE" to close this user\'s open trades.' });
    const r = await q('SELECT * FROM users WHERE id=$1 AND key_enc IS NOT NULL', [id]);
    if (!r.rows[0]) return res.status(404).json({ success: false, message: 'That user has no key, so there is nothing to close.' });
    const out = await closeAllForUser(r.rows[0], 'admin closed this account\'s trades');
    if (out.closed) notify(r.rows[0], '\ud83d\uded1 The admin closed all open trades on your account (' + out.closed + ').');
    await audit('admin', 'close_all_user', String(id), req, 'closed ' + out.closed + ', failed ' + out.failed);
    res.json({ success: true, closed: out.closed, failed: out.failed });
  }));

  // Overview tiles + the "needs attention" list
  app.get('/api/admin/overview', adminAuth, h(async (req, res) => {
    const c = (await q(`SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE active AND key_enc IS NOT NULL) AS trading,
        COUNT(*) FILTER (WHERE active AND key_enc IS NOT NULL AND control_mode='manual') AS manual,
        COUNT(*) FILTER (WHERE active AND key_enc IS NOT NULL AND paused) AS paused,
        COUNT(*) FILTER (WHERE key_status='error') AS keyerr,
        COUNT(*) FILTER (WHERE dry_run) AS dry,
        COALESCE(SUM(last_equity) FILTER (WHERE active AND key_enc IS NOT NULL AND key_env='live'),0) AS equity,
        COUNT(*) FILTER (WHERE active AND key_enc IS NOT NULL AND key_env='demo') AS demo
      FROM users`)).rows[0];
    const o = (await q(`SELECT
        COUNT(*) FILTER (WHERE code='OK') AS placed,
        COUNT(*) FILTER (WHERE code='DRY') AS dry,
        COUNT(*) FILTER (WHERE ok=false AND code NOT IN ('PENDING')) AS failed,
        COUNT(*) FILTER (WHERE code IN ('FILT','MAXT','HALT') AND ok=true) AS skipped
      FROM order_log WHERE kind='ORDER' AND created_at > now() - interval '24 hours'`)).rows[0];
    const pn = (await q(`SELECT
        COALESCE(SUM(closed_pnl) FILTER (WHERE closed_at >= (date_trunc('day', now() AT TIME ZONE 'UTC') AT TIME ZONE 'UTC')),0) AS today,
        COALESCE(SUM(closed_pnl) FILTER (WHERE closed_at > now() - interval '7 days'),0) AS week,
        COALESCE(SUM(closed_pnl),0) AS total FROM pnl_ledger WHERE user_id IN (SELECT id FROM users WHERE key_env='live')`)).rows[0];
    const attention = [];
    const push = (kind, severity, u, text, action) => attention.push({ kind, severity, userId: u.id, username: u.username, text, action: action || null });
    const key = (await q(`SELECT id, username, key_error FROM users WHERE key_status='error' AND active ORDER BY id`)).rows;
    key.forEach(u => push('key', 'high', u, 'Bybit key stopped working' + (u.key_error ? ': ' + u.key_error : ''), 'clearKeyError'));
    const pz = (await q(`SELECT id, username FROM users WHERE paused AND active AND key_enc IS NOT NULL AND key_status<>'error' ORDER BY id`)).rows;
    pz.forEach(u => push('paused', 'medium', u, 'Trading is paused', 'resume'));
    const fl = (await q(`SELECT u.id, u.username, COUNT(*) AS n, MAX(o.detail) AS last FROM order_log o JOIN users u ON u.id=o.user_id
      WHERE o.kind='ORDER' AND o.ok=false AND o.code NOT IN ('PENDING','HALT','MINQ','BAL') AND o.created_at > now() - interval '24 hours' AND u.active AND u.key_status<>'error'
      GROUP BY u.id, u.username HAVING COUNT(*) >= 3 ORDER BY n DESC`)).rows;
    fl.forEach(u => push('failing', 'high', u, u.n + ' failed orders in the last 24h' + (u.last ? ' (' + String(u.last).slice(0, 80) + ')' : ''), null));
    const lowRows = (await q(`SELECT u.id, u.username, u.last_equity, o.n FROM users u JOIN (SELECT user_id, COUNT(*) AS n FROM order_log WHERE code IN ('MINQ','BAL') AND created_at > now() - interval '24 hours' GROUP BY user_id) o ON o.user_id=u.id WHERE u.active ORDER BY u.id`)).rows;
    lowRows.forEach(u => push('balance', 'medium', u, 'Trades skipped for size or margin ' + u.n + ' time(s) in 24h' + (u.last_equity !== null ? ' (balance $' + Number(u.last_equity).toFixed(2) + ')' : ''), null));
    const nk = (await q(`SELECT id, username FROM users WHERE key_enc IS NULL AND active AND created_at < now() - interval '1 day' ORDER BY id`)).rows;
    nk.forEach(u => push('nokey', 'low', u, 'Signed up over a day ago but has not added a Bybit key', null));
    // system-level items (not tied to one user): master account refusals, bots whose relay switch is off, bots that crashed, a relay/Bybit mismatch
    const sys = (kind, severity, who, text) => attention.push({ kind, severity, userId: null, username: who, text, action: null });
    try {
      const mr = await masterReports(24, 40);
      const bad = mr.filter(r => r.kind === 'TRADE' && r.sev === 'fail');
      if (bad.length) sys('master', 'high', 'Master account', bad.length + ' trade(s) refused in the last 24h, so they were not copied. Latest: ' + (bad[0].symbol || '').replace('USDT', '') + ' (' + (bad[0].text || bad[0].code) + ')');
      const nt = mr.filter(r => r.kind === 'TRADE' && r.code === 'NOTRL');
      if (nt.length) sys('master', 'high', 'Master account', nt.length + ' trade(s) opened without their trailing stop in the last 24h');
    } catch (e) { /* the journal is optional here */ }
    const fl2 = getFleet();
    Object.keys(fl2.last || {}).sort().forEach(name => {
      const inf = (fl2.info || {})[name] || {};
      const online = fl2.offlineMs ? (Date.now() - fl2.last[name]) < fl2.offlineMs : true;
      if (online && inf.relayOn === false) sys('relay', 'medium', name.replace('YM ORACLE ', 'Oracle '), 'Bybit Relay switch is OFF: trades this bot opens will not reach Bybit or any user');
      if (online && ['CRASH', 'WATCHDOG', 'BROWNOUT'].includes(inf.resetReason) && inf.uptimeMin !== null && inf.uptimeMin !== undefined && inf.uptimeMin < 180) sys('crash', 'low', name.replace('YM ORACLE ', 'Oracle '), 'Restarted ' + inf.uptimeMin + ' min ago (' + inf.resetReason + ')');
    });
    const sy2 = getMasterSync() || {};
    if (sy2.lastError) sys('sync', 'medium', 'Master account', 'Could not compare with Bybit: ' + sy2.lastError);
    if (sy2.lastRecovered && Date.now() - sy2.lastRecovered.at < 24 * 3600000) sys('sync', 'low', 'Master account', 'A ' + String(sy2.lastRecovered.side).toLowerCase() + ' on ' + String(sy2.lastRecovered.symbol).replace('USDT', '') + ' was open on Bybit but missing from the log; it was added automatically');
    const order = { high: 0, medium: 1, low: 2 };
    attention.sort((a, b) => order[a.severity] - order[b.severity]);
    res.json({ success: true,
      tiles: { users: Number(c.total), trading: Number(c.trading), autopilot: Number(c.trading) - Number(c.manual), manual: Number(c.manual), paused: Number(c.paused), keyErrors: Number(c.keyerr), dryUsers: Number(c.dry), demoUsers: Number(c.demo), equity: Number(c.equity),
        ordersPlaced24h: Number(o.placed), ordersDry24h: Number(o.dry), ordersFailed24h: Number(o.failed), ordersSkipped24h: Number(o.skipped),
        pnlToday: Number(pn.today), pnl7d: Number(pn.week), pnlTotal: Number(pn.total) },
      pausedAll, dryAll, planVersion, allowManual: masterPlan.allowManual, attention });
  }));
  app.get('/api/admin/audit', adminAuth, h(async (req, res) => {
    const r = await q('SELECT at, actor, action, target, ip, detail FROM audit_log ORDER BY id DESC LIMIT $1', [Math.min(300, parseInt(req.query.limit, 10) || 60)]);
    res.json({ success: true, rows: r.rows });
  }));

  app.get('/api/admin/invites', adminAuth, h(async (req, res) => {
    const r = await q('SELECT i.code, i.created_at, u.username AS used_by FROM invites i LEFT JOIN users u ON u.id=i.used_by ORDER BY i.created_at DESC LIMIT 100');
    res.json({ success: true, invites: r.rows });
  }));
  app.post('/api/admin/invites', adminAuth, h(async (req, res) => {
    const n = Math.min(10, Math.max(1, parseInt((req.body || {}).count, 10) || 1));
    const codes = [];
    for (let i = 0; i < n; i++) {
      const code = crypto.randomBytes(5).toString('hex').toUpperCase();
      await q('INSERT INTO invites(code) VALUES($1)', [code]);
      codes.push(code);
    }
    await audit('admin', 'invites_created', null, req, String(n));
    res.json({ success: true, codes });
  }));

  app.post('/api/admin/sync-now', adminAuth, h(async (req, res) => {
    await audit('admin', 'sync_now', null, req, '');
    res.json({ success: true, ...(await syncAll()) });
  }));

  app.get('/api/admin/export.csv', adminAuth, h(async (req, res) => {
    const uid = parseInt(req.query.userId, 10) || null;
    const { csv } = await buildCsv(uid);
    await audit('admin', 'csv_export', uid ? String(uid) : 'all', req, '');
    res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="ym-ledger.csv"', 'Cache-Control': 'no-store' });
    res.send(csv);
  }));
  app.post('/api/admin/backup-now', adminAuth, h(async (req, res) => {
    await audit('admin', 'backup_now', null, req, '');
    const r = await runBackupIfDue(true);
    res.json({ success: !!r.sent, ...r });
  }));

  app.get('/api/admin/security', adminAuth, h(async (req, res) => {
    const info = getSecurityInfo();
    const us = (await q(`SELECT COUNT(*) AS n, COUNT(*) FILTER (WHERE totp_enabled) AS with2fa, COUNT(*) FILTER (WHERE ips_unrestricted AND key_enc IS NOT NULL) AS noip FROM users`)).rows[0];
    const n = Number(us.n);
    const checks = [
      { id: 'dash_pw', ok: !!process.env.DASHBOARD_PASSWORD, label: 'Admin password set', fix: 'Add DASHBOARD_PASSWORD on Render.' },
      { id: 'admin_2fa', ok: !!process.env.ADMIN_TOTP_SECRET, label: 'Admin 2FA (authenticator code) on', fix: 'Add ADMIN_TOTP_SECRET on Render (a base32 secret you also add to your authenticator app).' },
      { id: 'device_key', ok: !!info.deviceKeySet && info.deviceKeyMode === 'enforce', label: 'Trading endpoints require the device key', fix: info.deviceKeySet ? 'Key is set but in warn mode. After your ESP32s send it, set DEVICE_KEY_MODE=enforce.' : 'Anyone who finds your URL can place trades. Set DEVICE_API_KEY on Render and update the ESP32 firmware to send it.' },
      { id: 'device_misses', ok: !(info.deviceKeySet && info.deviceKeyMisses > 0), label: 'No unauthenticated trading requests seen since last restart', fix: info.deviceKeyMisses ? info.deviceKeyMisses + ' request(s) arrived without a valid device key.' : '' },
      { id: 'leverage_cap', ok: MAX_USER_LEVERAGE > 0, label: 'Leverage cap on users\' accounts', fix: 'Set MAX_USER_LEVERAGE (for example 10) so a bad signal can never over-leverage users.' },
      { id: 'telegram', ok: tgOn && !!TG_ADMIN_CHAT, label: 'Telegram alerts and daily backup on', fix: 'Set ALERT_TELEGRAM_BOT_TOKEN and ALERT_TELEGRAM_CHAT_ID.' },
      { id: 'user_2fa', ok: n === 0 || Number(us.with2fa) === n, label: 'All users have 2FA (' + us.with2fa + '/' + n + ')', fix: 'Encourage users to turn it on.' },
      { id: 'key_ip', ok: Number(us.noip) === 0, label: 'All user keys are IP-restricted', fix: Number(us.noip) + ' key(s) are not IP-locked.' },
    ];
    res.json({ success: true, checks });
  }));

  // ---------- pages ----------
  app.get('/join', sec.pageHeaders, (req, res) => res.sendFile(path.join(__dirname, 'public', 'join.html')));
  app.get('/admin', sec.pageHeaders, (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));
  app.get('/s/:token', sec.pageHeaders, (req, res) => res.sendFile(path.join(__dirname, 'public', 'share.html')));

  return { enabled: true, canPersist: true, loadMasterCreds, saveMasterCreds, clearMasterCreds, fanOutOrder, fanOutTradingStop, guardClamp, guardFitClose, fanOutLeverage, recordExec, recordBotEvent, sizeMasterOrder, syncAll, verifyAdminToken, _test: { ...off._test, pgTune: pgTuneEval, pgAutoTune, pgTick, pgState, pgWatch, pgClosing, pgRun, fanOutPartialClose, getPgCfg: () => pgCfg, envOpts, normEnv, tgPollOnce, runBackupIfDue, buildCsv, settlePending, withRetry, checkSignalAlarms, pushSignalAlerts, pushBotMsgs, alertSweep, getPlan: () => masterPlan, rerunStdMigration: async (legacy) => { await q(`DELETE FROM meta WHERE k='std_v1_migrated'`); await migrateToStandardV1(legacy ? { ...LEGACY_PLAN, ...legacy } : LEGACY_PLAN, !!legacy); }, migrateOnce: (legacy) => migrateToStandardV1({ ...LEGACY_PLAN, ...(legacy || {}) }, !!legacy), ageAdminEquity: (ms, clear) => { adminEq = { at: Date.now() - ms, v: clear ? null : adminEq.v }; } } };
}

module.exports = { init };
