#include <WiFi.h>
#include <esp_now.h>
#include <LittleFS.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <ArduinoJson.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include <esp_system.h>

// --- Network Configuration ---
const char* ssid     = "Pikam Broadband";
const char* password = "elxv00440";
const char* renderServerUrl = "https://ym-oracle.onrender.com";
const char* MANAGER_UI_PASSWORD = "YOUR_MANAGER_UI_PASSWORD"; // protects the manager's own status page (see MANAGERUI block) -- anyone on this WiFi can reach it otherwise. Set this before flashing.

// REAL FEATURE ADDED at the user's explicit request: this device now
// also receives trade signals from the YM ORACLE fleet over ESP-NOW,
// not just Serial. Same processCommandString() handles both -- an
// ESP-NOW message and a typed Serial line are treated identically once
// they're a String, so nothing about the already-tested command logic
// changes; this just adds a second way a command string can arrive.
// ESP-NOW requires this device and every sending oracle bot to be on
// WiFi networks using the SAME CHANNEL -- it's a link-layer protocol
// tied to the current WiFi channel, not something a shared SSID name
// alone guarantees if they're on different routers.
typedef struct struct_message {
  char command[200]; // roomy enough for the full TRADE,... command below with real price/percentage values
} struct_message;

// RELIABLE RELAY -- REAL FEATURE ADDED at the user's explicit request: "I want it prioritized to
// never fail." Measured on the old version with a simulated radio (8% packet loss) and a flaky
// backend (5% of order calls timing out): 12.5% of trades never executed, and the sending bot was
// never told about any of them. This section is the manager's half of the fix:
//   * every TRADEQ / SLTPQ / CLOSEQ command carries a unique id from the bot;
//   * the moment one arrives, the RADIO CALLBACK itself queues an "ACK,<id>" reply (through a tiny
//     dedicated send task, so it goes out even while loop() is blocked on a slow HTTPS call) -- this
//     is what stops the bot retransmitting;
//   * a retransmit of an id we already have is dropped here (never a second order); if that id has
//     already finished, its result is simply sent again;
//   * when a command finishes, "RES,<id>,<O|F>,<code>" goes back, and the same outcome is reported to
//     the backend so it shows up on the dashboard.
// Older bots that still send plain TRADE,... keep working exactly as before (no ids, no replies).
// One slot used to be all there was here, and it lost messages -- see the queue below.
#define ESPNOW_QUEUE_SIZE 8
struct_message espNowQueue[ESPNOW_QUEUE_SIZE];
unsigned long espNowQueueRxMs[ESPNOW_QUEUE_SIZE];
uint8_t espNowQueueSrc[ESPNOW_QUEUE_SIZE][6]; // who sent each queued message, so the reply can go back to them
volatile uint8_t espNowQueueHead = 0; // next slot the callback writes
volatile uint8_t espNowQueueTail = 0; // next slot loop() reads
volatile uint32_t espNowDroppedCount = 0; // messages lost because the queue was full
uint32_t espNowDroppedReported = 0;
unsigned long currentMessageRxMs = 0; // arrival time of the message loop() is processing right now
uint8_t currentMessageSrc[6] = {0, 0, 0, 0, 0, 0}; // sender of the message loop() is processing right now
bool currentMessageHasSrc = false;
portMUX_TYPE espNowQueueMux = portMUX_INITIALIZER_UNLOCKED;

// Replies to the oracle bots (ACK / RES) go through this queue and are sent by a small dedicated task,
// not from the radio callback and not from loop() -- the callback must stay tiny, and loop() can be
// stuck on an HTTPS call for many seconds.
struct TxItem { uint8_t mac[6]; char text[48]; };
QueueHandle_t espNowTxQueue = NULL;
volatile uint32_t espNowTxDropped = 0;

// The last SEEN_RING_SIZE command ids: state 0 = accepted and queued/running, 1 = finished OK,
// 2 = finished with a failure (code kept so a retransmit can be answered without re-running it).
#define SEEN_RING_SIZE 96 // was 24: a burst of trades plus lost replies could push an unanswered id out, and its resend would then look like a NEW command
struct SeenEntry { char id[14]; uint8_t state; char code[8]; uint8_t src[6]; };
SeenEntry seenRing[SEEN_RING_SIZE];
uint8_t seenNext = 0;

bool isIdCommandText(const char* cmd) {
  return strncmp(cmd, "TRADEQ,", 7) == 0 || strncmp(cmd, "SLTPQ,", 6) == 0 || strncmp(cmd, "CLOSEQ,", 7) == 0;
}

// Anything that moves money or a live position: handled before housekeeping (heartbeats, pings).
bool isTradeRelatedText(const char* cmd) {
  return isIdCommandText(cmd) || strncmp(cmd, "TRADE,", 6) == 0 || strncmp(cmd, "CLOSE,", 6) == 0 ||
         strncmp(cmd, "TPSL,", 5) == 0 || strncmp(cmd, "TRAIL,", 6) == 0;
}

// The id is the 2nd comma-separated field.
bool extractIdFromCommand(const char* cmd, char* out, size_t outSize) {
  const char* a = strchr(cmd, ',');
  if (!a) return false;
  a++;
  const char* b = strchr(a, ',');
  size_t n = b ? (size_t)(b - a) : strlen(a);
  if (n == 0 || n >= outSize) return false;
  memcpy(out, a, n);
  out[n] = '\0';
  return true;
}

int seenFindIndex(const char* id, const uint8_t* src) {
  for (int i = 0; i < SEEN_RING_SIZE; i++) {
    if (seenRing[i].id[0] != '\0' && strcmp(seenRing[i].id, id) == 0 && memcmp(seenRing[i].src, src, 6) == 0) return i;
  }
  return -1;
}

int seenAddIndex(const char* id, const uint8_t* src) {
  int i = seenNext;
  seenNext = (seenNext + 1) % SEEN_RING_SIZE;
  memset(&seenRing[i], 0, sizeof(SeenEntry));
  strncpy(seenRing[i].id, id, sizeof(seenRing[i].id) - 1);
  memcpy(seenRing[i].src, src, 6);
  seenRing[i].state = 0;
  return i;
}

void txQueueSend(const uint8_t* mac, const char* text) {
  if (espNowTxQueue == NULL) return;
  TxItem item;
  memset(&item, 0, sizeof(item));
  memcpy(item.mac, mac, 6);
  strncpy(item.text, text, sizeof(item.text) - 1);
  if (xQueueSend(espNowTxQueue, &item, 0) != pdTRUE) espNowTxDropped++;
}

// One turn of the reply-sending task. Also called directly by the host test harness.
void espNowTxPumpOnce(unsigned long waitTicks) {
  if (espNowTxQueue == NULL) return;
  TxItem item;
  if (xQueueReceive(espNowTxQueue, &item, (TickType_t)waitTicks) != pdTRUE) return;
  if (!esp_now_is_peer_exist(item.mac)) {
    esp_now_peer_info_t peerInfo = {};
    memcpy(peerInfo.peer_addr, item.mac, 6);
    peerInfo.channel = 0;
    peerInfo.encrypt = false;
    esp_now_add_peer(&peerInfo);
  }
  esp_now_send(item.mac, (const uint8_t*)item.text, strlen(item.text) + 1);
}

void espNowTxTask(void* arg) {
  for (;;) espNowTxPumpOnce(portMAX_DELAY);
}

void noteOracleHeard(const uint8_t* src); // defined below, once the bot table exists
// SYNC-17: sender check. ESP-NOW here is unencrypted, so anyone in radio range who knew the frame format and this device's MAC could send a trade
// command. Every frame's sender is now compared with the four bot MACs in oracleMacs[] below.
//   0 = off (old behaviour)   1 = LOG ONLY: unknown senders are counted and printed, nothing is dropped   2 = ENFORCE: frames from unknown senders are dropped, no ACK
// Ships at 1 on purpose: a wrong or stale MAC in oracleMacs[] would make mode 2 silently drop that bot's trades. Flash with 1, watch the status page
// and Serial for "[SENDER CHECK]" lines while all four bots run, and when none appear change this to 2 and reflash.
#define MGR_SENDER_CHECK 1
bool isKnownOracleMac(const uint8_t* src); // defined below, next to noteOracleHeard
volatile uint32_t mgrUnknownSenders = 0;
uint8_t mgrLastUnknownMac[6] = {0, 0, 0, 0, 0, 0};
void hbNote(const char* name, unsigned long nowMs); // mgr-2: defined in the MGRHEALTH block
void onEspNowDataRecv(const esp_now_recv_info *recv_info, const uint8_t *data, int len) {
  if (len <= 0 || len > (int)sizeof(struct_message)) return; // guard against a malformed/oversized packet before touching memory
  uint8_t src[6] = {0, 0, 0, 0, 0, 0};
  if (recv_info != NULL && recv_info->src_addr != NULL) memcpy(src, recv_info->src_addr, 6);

#if MGR_SENDER_CHECK
  if (!isKnownOracleMac(src)) {
    mgrUnknownSenders++;
    memcpy(mgrLastUnknownMac, src, 6);
#if MGR_SENDER_CHECK >= 2
    return; // not one of the four bots: dropped, never ACKed, never queued
#endif
  }
#endif
  noteOracleHeard(src); // status page only: remember when each bot was last heard
  char text[sizeof(struct_message)];
  memset(text, 0, sizeof(text));
  memcpy(text, data, len);
  text[sizeof(text) - 1] = '\0'; // guarantee null-termination regardless of what arrived
  if (strncmp(text, "HEARTBEAT,", 10) == 0) { hbNote(text + 10, millis()); return; }   // mgr-2: never queued, never waits behind a trade

  char id[14] = {0};
  bool hasId = isIdCommandText(text) && extractIdFromCommand(text, id, sizeof(id));

  char reply[48];
  reply[0] = '\0';
  portENTER_CRITICAL(&espNowQueueMux);
  bool enqueue = true;
  int seenIdx = -1;
  bool newlySeen = false;
  if (hasId) {
    seenIdx = seenFindIndex(id, src);
    if (seenIdx >= 0) {
      enqueue = false; // a retransmit -- never queue it a second time
      if (seenRing[seenIdx].state == 0) snprintf(reply, sizeof(reply), "ACK,%s", id);
      else snprintf(reply, sizeof(reply), "RES,%s,%c,%s", id, seenRing[seenIdx].state == 1 ? 'O' : 'F', seenRing[seenIdx].code);
    } else {
      seenIdx = seenAddIndex(id, src);
      newlySeen = true;
      snprintf(reply, sizeof(reply), "ACK,%s", id);
    }
  }
  if (enqueue) {
    uint8_t next = (espNowQueueHead + 1) % ESPNOW_QUEUE_SIZE;
    if (next == espNowQueueTail) {
      espNowDroppedCount++; // full: drop the newest rather than corrupt an entry loop() may be reading
      // ...and forget its id and send NO ack, so the bot's next retransmit gets a fresh chance
      if (newlySeen && seenIdx >= 0) seenRing[seenIdx].id[0] = '\0';
      reply[0] = '\0';
    } else {
      memset(&espNowQueue[espNowQueueHead], 0, sizeof(struct_message));
      memcpy(&espNowQueue[espNowQueueHead], text, sizeof(struct_message));
      espNowQueueRxMs[espNowQueueHead] = millis();
      memcpy(espNowQueueSrc[espNowQueueHead], src, 6);
      espNowQueueHead = next;
    }
  }
  portEXIT_CRITICAL(&espNowQueueMux);
  if (reply[0] != '\0') txQueueSend(src, reply);
}

// Called by loop() when a command has finished: remember the outcome (so a retransmit can be
// answered) and tell the bot.
void finishIdCommandReply(const char* id, bool ok, const char* code) {
  if (!currentMessageHasSrc) return;
  portENTER_CRITICAL(&espNowQueueMux);
  int i = seenFindIndex(id, currentMessageSrc);
  if (i >= 0) {
    seenRing[i].state = ok ? 1 : 2;
    strncpy(seenRing[i].code, code, sizeof(seenRing[i].code) - 1);
    seenRing[i].code[sizeof(seenRing[i].code) - 1] = '\0';
  }
  portEXIT_CRITICAL(&espNowQueueMux);
  char reply[48];
  snprintf(reply, sizeof(reply), "RES,%s,%c,%s", id, ok ? 'O' : 'F', code);
  txQueueSend(currentMessageSrc, reply);
}

// This talks to the backend exactly as it's deployed right now -- no
// auth header, no signalId, nothing the live server.js doesn't already
// expect. Every request below matches the current, running API exactly.

// --- HTTP Helpers ---
// REAL BUG FOUND, fixed from an actual test run: no explicit timeout was
// set, so HTTPClient used its short built-in default. Render's free
// tier spins the service down after inactivity -- the first request
// after a period of idle can take 30-60+ seconds just to wake it back
// up, well past that default, which is exactly what produced the
// httpCode=-11 (READ_TIMEOUT) seen on the very first POS command after
// boot. 60 seconds gives a cold start real room without hanging forever
// on a genuinely dead connection.
const unsigned long HTTP_TIMEOUT_MS = 60000;

// ===== MGRHEALTH-BEGIN =====
// mgr-2. The manager runs ONE thing at a time. Before this block, every alive-signal from a bot became a queued message that loop() forwarded with a
// 60-second HTTPS call, and /api/ping-check was polled every 10 s with the same 60-second limit. With Render slow or asleep that is a full minute lost per
// call, so alive-signals piled up behind each other (queue of 8), the dashboard saw ALL bots go quiet together, and a trade could wait behind them.
//  * An alive-signal no longer uses the queue: the radio callback only marks "bot X is alive" in a tiny table (one entry per bot, newer replaces older).
//  * Bookkeeping calls (alive-signal, ping check/result, execution report) get a 10 s limit, and after a failure they back off 15 s -> 30 s -> 60 s instead of
//    hammering a dead backend. Trade calls are NOT held back by that.
//  * Trade calls keep the full 60 s only while the backend has not answered recently (a cold Render start can take that long); a warm backend gets 25 s.
//  * Numbers that would show WHY it failed (heap, longest stall, reset reason, failures) are kept for the status page.
//  * If the heap can no longer support a TLS connection, and nothing is in flight, the board restarts itself (and writes down why).
const unsigned long HOUSEKEEPING_TIMEOUT_MS = 10000UL;
const unsigned long WARM_BACKEND_TIMEOUT_MS = 25000UL;
const unsigned long WARM_BACKEND_WINDOW_MS = 300000UL;
const unsigned long BACKEND_BACKOFF_FIRST_MS = 15000UL;
const unsigned long BACKEND_BACKOFF_MAX_MS = 60000UL;
const unsigned long HB_STALE_MS = 240000UL;               // an alive-signal not forwarded within this long is dropped: reporting it later would claim a bot is alive when it may not be
const int HB_SLOTS = 8;
struct HbSlot { char name[24]; bool pending; unsigned long rxMs; };
HbSlot hbSlots[HB_SLOTS];
portMUX_TYPE hbMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t hbReceived = 0, hbCoalesced = 0;
uint32_t hbForwarded = 0, hbFailed = 0, hbStale = 0;
unsigned long g_httpTimeoutOverrideMs = 0;                // set by the short helpers for the duration of ONE bookkeeping call
unsigned long backendLastOkMs = 0;
bool backendEverOk = false;
uint32_t backendFailStreak = 0, backendCalls = 0, backendFailTotal = 0;
unsigned long backendNextHousekeepingMs = 0;
unsigned long loopLastPassMs = 0, loopLongestGapMs = 0;
uint32_t loopStallsOver30s = 0;
unsigned long lastCommandMs = 0;                          // when the loop last handled a queued message
bool hbNameOk(const char* n) {
  if (n == nullptr || n[0] == '\0') return false;
  size_t len = strlen(n);
  if (len >= sizeof(hbSlots[0].name)) return false;
  for (size_t i = 0; i < len; i++) if ((unsigned char)n[i] < 32 || n[i] == '"' || n[i] == '\\') return false;
  return true;
}
// Called from the radio callback: must stay tiny and never block.
void hbNote(const char* name, unsigned long nowMs) {
  if (!hbNameOk(name)) return;
  portENTER_CRITICAL(&hbMux);
  hbReceived++;
  int freeIdx = -1, oldest = 0, same = -1;
  for (int i = 0; i < HB_SLOTS; i++) {
    if (hbSlots[i].name[0] != '\0' && strcmp(hbSlots[i].name, name) == 0) same = i;
    if (hbSlots[i].name[0] == '\0' && freeIdx < 0) freeIdx = i;
    if ((long)(hbSlots[i].rxMs - hbSlots[oldest].rxMs) < 0) oldest = i;
  }
  int use = same >= 0 ? same : (freeIdx >= 0 ? freeIdx : oldest);
  if (same >= 0 && hbSlots[use].pending) hbCoalesced++;      // the previous one was never forwarded: this newer one replaces it
  strncpy(hbSlots[use].name, name, sizeof(hbSlots[use].name) - 1); hbSlots[use].name[sizeof(hbSlots[use].name) - 1] = '\0';
  hbSlots[use].pending = true; hbSlots[use].rxMs = nowMs;
  portEXIT_CRITICAL(&hbMux);
}
// Oldest pending alive-signal first; stale ones are dropped (and counted).
bool hbTake(char* out, size_t outSize, unsigned long nowMs) {
  bool got = false;
  portENTER_CRITICAL(&hbMux);
  for (;;) {
    int pick = -1;
    for (int i = 0; i < HB_SLOTS; i++) if (hbSlots[i].pending && (pick < 0 || (long)(hbSlots[i].rxMs - hbSlots[pick].rxMs) < 0)) pick = i;
    if (pick < 0) break;
    hbSlots[pick].pending = false;
    if ((unsigned long)(nowMs - hbSlots[pick].rxMs) > HB_STALE_MS) { hbStale++; continue; }
    strncpy(out, hbSlots[pick].name, outSize - 1); out[outSize - 1] = '\0'; got = true; break;
  }
  portEXIT_CRITICAL(&hbMux);
  return got;
}
int hbPendingCount() { int n = 0; for (int i = 0; i < HB_SLOTS; i++) if (hbSlots[i].pending) n++; return n; }
// Timeout for a backend call that is not bookkeeping.
unsigned long backendTimeoutMs(unsigned long nowMs) {
  if (g_httpTimeoutOverrideMs != 0) return g_httpTimeoutOverrideMs;
  if (backendEverOk && (unsigned long)(nowMs - backendLastOkMs) < WARM_BACKEND_WINDOW_MS) return WARM_BACKEND_TIMEOUT_MS;
  return HTTP_TIMEOUT_MS;
}
// Every backend call reports here. Only a transport failure (no HTTP answer at all) counts as a failure: the backend answers 503 on purpose when trading is
// halted, and that must never make the manager stop asking whether the halt has been lifted.
void backendNoteResult(int httpCode, unsigned long nowMs) {
  backendCalls++;
  if (httpCode > 0) { backendEverOk = true; backendLastOkMs = nowMs; backendFailStreak = 0; backendNextHousekeepingMs = 0; return; }
  backendFailTotal++; backendFailStreak++;
  unsigned long wait = BACKEND_BACKOFF_FIRST_MS;
  for (uint32_t i = 1; i < backendFailStreak && wait < BACKEND_BACKOFF_MAX_MS; i++) wait *= 2;
  if (wait > BACKEND_BACKOFF_MAX_MS) wait = BACKEND_BACKOFF_MAX_MS;
  backendNextHousekeepingMs = nowMs + wait;
}
bool backendHousekeepingDue(unsigned long nowMs) { return backendNextHousekeepingMs == 0 || (long)(nowMs - backendNextHousekeepingMs) >= 0; }
void loopNotePass(unsigned long nowMs) {
  if (loopLastPassMs != 0) {
    unsigned long gap = nowMs - loopLastPassMs;
    if (gap > loopLongestGapMs) loopLongestGapMs = gap;
    if (gap > 30000UL) loopStallsOver30s++;
  }
  loopLastPassMs = nowMs;
}
// 0 = no, 1 = heap too small for a TLS connection, 2 = backend calls keep failing while the heap is fragmented. Only ever when idle and after 10 minutes up.
int healthRestartReason(unsigned long upMs, bool idle, bool wifiUp, uint32_t maxBlock, uint32_t failStreak) {
  if (upMs < 600000UL || !idle) return 0;
  if (maxBlock < 20000UL) return 1;
  if (wifiUp && failStreak >= 8 && maxBlock < 45000UL) return 2;
  return 0;
}
const char* resetReasonName(int r) {
  switch (r) {
    case 1: return "power on"; case 2: return "reset pin"; case 3: return "software restart"; case 4: return "CRASH (panic)";
    case 5: return "interrupt watchdog"; case 6: return "task watchdog"; case 7: return "watchdog"; case 8: return "deep sleep";
    case 9: return "BROWNOUT (power dip)"; case 10: return "SDIO"; default: return "unknown";
  }
}
// ===== MGRHEALTH-END =====

// REAL FEATURE ADDED at the user's explicit request: the manager bot
// has never needed to know the oracle fleet's own MAC addresses before
// this -- every prior message flowed one way, oracle bots to here,
// which only requires THIS device's MAC to be known by them. Sending a
// ping requires the opposite: esp_now_add_peer() needs the target's
// MAC before esp_now_send() will work at all. REPLACE EACH WITH THE
// REAL MAC of that oracle bot, printed on its own Serial output on
// boot the same way this device prints its own.
// UPDATE at the user's request (2026-10): Oracle IV (bot 4) is wired back in. It is the SWING bot now and its board was replaced, so its MAC is
// registered here: 14:C1:9F:3B:D8:D4 (confirmed by the owner; an older version of this comment named a different MAC, which was stale). Being in this table means (1) everything it sends is attributed to "YM ORACLE IV" instead of "unknown bot"
// (heartbeats, execution reports, logs), (2) its ESP-NOW peer is registered at boot so a reply never waits for it, (3) it is included in every ping
// round. The backend's dashboard and offline alerts now track all four bots (SERVER_TRACKED_BOT_NAMES / ACTIVE_BOT_NAMES).
// If a board is ever replaced again, change ONLY its row below (the order stays bot 1, 2, 3, 4) and reflash this device.
const int ORACLE_COUNT = 4;
uint8_t oracleMacs[ORACLE_COUNT][6] = {
  {0x24, 0x58, 0x7C, 0x91, 0xA0, 0x3C}, // YM ORACLE I   (bot 1)
  {0x28, 0x84, 0x85, 0x59, 0xD0, 0x54}, // YM ORACLE II  (bot 2)
  {0x38, 0x3E, 0x51, 0x58, 0xF8, 0xF0}, // YM ORACLE III (bot 3)
  {0x14, 0xC1, 0x9F, 0x3B, 0xD8, 0xD4}, // YM ORACLE IV  (bot 4)
};
const char* PING_BOT_NAMES[ORACLE_COUNT] = {"YM ORACLE I", "YM ORACLE II", "YM ORACLE III", "YM ORACLE IV"};
// Each bot's own page, by the mDNS name the bot announces (same order as above). Shown on the manager page.
const char* ORACLE_LOCAL_HOSTS[ORACLE_COUNT] = {"tradescanner", "tradescanner2", "tradescanner3", "tradescanner4"};
// Last time ANY packet (heartbeat, trade, pong) arrived from each bot. Written by the ESP-NOW receive callback (one
// store, no locking, no network) and only ever READ by the status page -- so it adds nothing to the signal path.
volatile unsigned long oracleLastHeardMs[ORACLE_COUNT] = {0, 0, 0, 0};
volatile bool oracleEverHeard[ORACLE_COUNT] = {false, false, false, false};
void noteOracleHeard(const uint8_t* src) {
  for (int i = 0; i < ORACLE_COUNT; i++) {
    if (memcmp(src, oracleMacs[i], 6) == 0) { oracleLastHeardMs[i] = millis(); oracleEverHeard[i] = true; return; }
  }
}
bool isKnownOracleMac(const uint8_t* src) {
  for (int i = 0; i < ORACLE_COUNT; i++) if (memcmp(src, oracleMacs[i], 6) == 0) return true;
  return false;
}
bool oraclePeerAdded[ORACLE_COUNT] = {false, false, false, false};

// Ping-round state. Deliberately simple -- one round at a time, no
// queue. A second "ping fleet" click while one is still resolving just
// starts a fresh round (see the backend side for exactly how that's
// handled), rather than this device needing to track several at once.
bool pingRoundActive = false;
unsigned long pingRoundStartMs = 0;
String currentPingId = "";
bool pingReplied[ORACLE_COUNT] = {false, false, false, false};
// REAL CHANGE at the user's explicit request. Two problems with the old
// 5s wait / 2s poll: (1) polling Render every 2 seconds, forever, cost
// roughly 10x what the heartbeat does in data for a feature used
// occasionally, and (2) 5s was too short -- a bot busy with a scan used
// to answer only after the scan ended (that is fixed on the bot side now,
// but a generous window is still the right safety margin).
// Timing chain, worst case: up to 10s before this device notices a ping
// request + up to 15s waiting for replies = 25s, which fits inside the
// dashboard's 30s wait with a few seconds of slack. If either number here
// changes, the dashboard's wait (PING_UI_WAIT_MS in server.js) must be
// kept >= poll + timeout + a few seconds.
const unsigned long PING_TIMEOUT_MS = 15000;
const unsigned long PING_POLL_INTERVAL_MS = 10000;
unsigned long lastPingPollMs = 0;

// REAL CHANGE at the user's explicit request: these two now also report the HTTP status code (a timeout
// and a real "no" answer used to look identical -- both were just an empty or unread string), and send
// the dashboard password when one is configured. Before this, if DASHBOARD_PASSWORD were ever set on
// the backend, /api/balance and /api/positions would answer 401 and EVERY trade would fail at the
// balance step with nothing explaining why. Leave dashboardPassword empty unless the backend has one.
const char* dashboardPassword = "Ophamuero1?@"; // must equal DASHBOARD_PASSWORD on Render exactly (change both together)
// FIX: the secret that must equal DEVICE_API_KEY on Render. The manager sends it on every call to the relay so the balance
// and positions reads (and, later, enforce mode) are accepted. Leave "" only if DEVICE_API_KEY is not set on Render.
const char* deviceKey = "15be51e10ba92dd88ce0c5f11cbbe732423b002a13f964ad70807cc0aaec4a4f";

String sendPostRequestEx(String path, String jsonPayload, int &httpCode) {
  httpCode = 0;
  if (WiFi.status() != WL_CONNECTED) { Serial.println("[ERROR] WiFi not connected."); return ""; }
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;

  http.begin(client, String(renderServerUrl) + path);
  http.addHeader("Content-Type", "application/json");
  if (dashboardPassword[0] != '\0') http.addHeader("X-Dashboard-Password", dashboardPassword);
  if (deviceKey[0] != '\0') http.addHeader("X-Device-Key", deviceKey);
  http.setTimeout((uint16_t)backendTimeoutMs(millis()));

  httpCode = http.POST(jsonPayload);
  backendNoteResult(httpCode, millis());
  String response = (httpCode > 0) ? http.getString() : "";
  if (httpCode <= 0) {
    Serial.printf("[ERROR] POST %s failed, httpCode=%d\n", path.c_str(), httpCode);
  }
  http.end();
  return response;
}

String sendGetRequestEx(String path, int &httpCode) {
  httpCode = 0;
  if (WiFi.status() != WL_CONNECTED) { Serial.println("[ERROR] WiFi not connected."); return ""; }
  WiFiClientSecure client;
  client.setInsecure();
  HTTPClient http;

  http.begin(client, String(renderServerUrl) + path);
  if (dashboardPassword[0] != '\0') http.addHeader("X-Dashboard-Password", dashboardPassword);
  if (deviceKey[0] != '\0') http.addHeader("X-Device-Key", deviceKey);
  http.setTimeout((uint16_t)backendTimeoutMs(millis()));
  httpCode = http.GET();
  backendNoteResult(httpCode, millis());
  String response = (httpCode > 0) ? http.getString() : "";
  if (httpCode <= 0) {
    Serial.printf("[ERROR] GET %s failed, httpCode=%d\n", path.c_str(), httpCode);
  }
  http.end();
  return response;
}

String sendPostRequest(String path, String jsonPayload) {
  int httpCode = 0;
  return sendPostRequestEx(path, jsonPayload, httpCode);
}

String sendGetRequest(String path) {
  int httpCode = 0;
  return sendGetRequestEx(path, httpCode);
}
// Bookkeeping calls (alive-signal, ping check / result, execution report): 10 s, never the full minute.
String sendPostShort(String path, String jsonPayload, int &httpCode) {
  g_httpTimeoutOverrideMs = HOUSEKEEPING_TIMEOUT_MS;
  String r = sendPostRequestEx(path, jsonPayload, httpCode);
  g_httpTimeoutOverrideMs = 0;
  return r;
}
String sendGetShort(String path, int &httpCode) {
  g_httpTimeoutOverrideMs = HOUSEKEEPING_TIMEOUT_MS;
  String r = sendGetRequestEx(path, httpCode);
  g_httpTimeoutOverrideMs = 0;
  return r;
}


// --- Data Fetching Helpers ---
// REAL GAP found at the user's request ("what happens when there is low balance"): /api/balance's 'balance' is
// account EQUITY, which still counts the margin locked inside open positions -- so a check against it could pass
// while Bybit rejected the order for lack of AVAILABLE margin. The backend now also sends 'available'; that is what
// decides whether a new trade fits. An older backend that sends only 'balance' still works (falls back to it).
float g_lastEquity = -1.0f;
float getAccountBalance() {
  String res = sendGetRequest("/api/balance");
  if (res.length() == 0) return -1.0;
  JsonDocument doc;
  if (deserializeJson(doc, res) != DeserializationError::Ok) return -1.0;
  if (doc["success"] != true) return -1.0;
  g_lastEquity = doc["balance"] | -1.0f;
  if (!doc["available"].isNull()) return doc["available"].as<float>();
  return doc["balance"].as<float>();
}

float getLivePrice(String symbol) {
  String res = sendGetRequest("/api/price/" + symbol);
  if (res.length() == 0) return -1.0;
  JsonDocument doc;
  deserializeJson(doc, res);
  return (doc["success"] == true) ? doc["price"].as<float>() : -1.0;
}

bool getInstrumentInfo(String symbol, float &qtyStep, float &minQty) {
  qtyStep = 0.001; minQty = 0.001; // sane fallback if the lookup fails
  String res = sendGetRequest("/api/instrument/" + symbol);
  if (res.length() == 0) return false;
  JsonDocument doc;
  if (deserializeJson(doc, res) != DeserializationError::Ok) return false;
  if (doc["success"] != true) return false;
  qtyStep = doc["qtyStep"].as<float>();
  minQty = doc["minOrderQty"].as<float>();
  return true;
}

int getPrecisionDecimals(float step) {
  int decimals = 0;
  while (step < 1.0 && decimals < 6) { step *= 10.0f; decimals++; }
  return decimals;
}


String getArgument(String data, char separator, int index) {
  int found = 0;
  int strIndex[] = {0, -1};
  int maxIndex = data.length() - 1;
  for (int i = 0; i <= maxIndex && found <= index; i++) {
    if (data.charAt(i) == separator || i == maxIndex) {
      found++;
      strIndex[0] = strIndex[1] + 1;
      // FIX: a command ending in a comma (e.g. "BUY,BTCUSDT,10,10,,") used to leave that comma inside the last field, so
      // TP became "," and Bybit said "takeProfit invalid". A trailing separator now ends the field instead of joining it.
      strIndex[1] = (i == maxIndex && data.charAt(i) != separator) ? i + 1 : i;
    }
  }
  return found > index ? data.substring(strIndex[0], strIndex[1]) : "";
}

// --- Feature: set leverage ---
// REAL FEATURE ADDED at the user's explicit request: forwards an oracle
// bot's heartbeat to the backend so the dashboard can show which of the
// four are actually alive right now, from anywhere. No error handling
// beyond what sendPostRequest already does -- a dropped heartbeat isn't
// worth retrying, the next one is only 60s away.
void forwardHeartbeat(String botName) {
  String payload = "{\"name\":\"" + botName + "\"}";
  int code = 0;
  sendPostShort("/api/heartbeat", payload, code);
  if (code > 0) hbForwarded++; else hbFailed++;
}

bool ensureOraclePeerAdded(int idx) {
  if (oraclePeerAdded[idx]) return true;
  esp_now_peer_info_t peerInfo = {};
  memcpy(peerInfo.peer_addr, oracleMacs[idx], 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;
  if (esp_now_add_peer(&peerInfo) == ESP_OK) {
    oraclePeerAdded[idx] = true;
    return true;
  }
  return false;
}

void reportPingResult(String pingId, String name, long ms, bool timedOut) {
  String payload = "{\"pingId\":\"" + pingId + "\",\"name\":\"" + name + "\"" +
                    (timedOut ? ",\"timeout\":true}" : ",\"ms\":" + String(ms) + "}");
  int postCode = 0;
  sendPostShort("/api/ping-result", payload, postCode);
}

// REAL FEATURE ADDED at the user's explicit request: broadcasts PING to
// all four oracle bots and starts the round's clock. A bot whose peer
// fails to add (misconfigured MAC, same failure mode as the relay
// path) is reported as an immediate timeout rather than left to
// silently never respond -- the dashboard should see a clear failure,
// not an entry that just never shows up.
// REAL FEATURE ADDED at the user's explicit request: this whole function
// used to be silent -- a peer-add failure or a failed esp_now_send()
// only ever showed up, eventually, as a generic timeout on the
// dashboard, with nothing on this device's own Serial to explain why.
// REAL FEATURE ADDED at the user's explicit request: esp_now_send()'s
// own return value only confirms the packet was handed to the WiFi
// driver -- it says nothing about whether it was actually received at
// the radio level. This is the separate, asynchronous callback
// ESP-NOW provides specifically for that, previously never registered
// here -- meaning every ping this device sent had zero real delivery
// confirmation, "queued successfully" was being treated as good enough
// when it isn't. Resolves the MAC back to a bot name so the log is
// actually readable, not just raw hex.
void onEspNowDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  String who = "unknown peer";
  for (int i = 0; i < ORACLE_COUNT; i++) {
    if (memcmp(mac_addr, oracleMacs[i], 6) == 0) { who = PING_BOT_NAMES[i]; break; }
  }
  Serial.println("[ESP-NOW SEND] " + who + ": " + (status == ESP_NOW_SEND_SUCCESS ? "delivered" : "FAILED at the radio level (queued OK, but never actually received)"));
}

String macToString(uint8_t* mac) {
  char buf[18];
  snprintf(buf, sizeof(buf), "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  return String(buf);
}

void startPingRound(String pingId) {
  Serial.println("\n[PING] Starting round " + pingId);
  currentPingId = pingId;
  pingRoundStartMs = millis();
  pingRoundActive = true;
  for (int i = 0; i < ORACLE_COUNT; i++) {
    pingReplied[i] = false;
    Serial.println("[PING] " + String(PING_BOT_NAMES[i]) + " -> " + macToString(oracleMacs[i]));
    if (!ensureOraclePeerAdded(i)) {
      Serial.println("[PING]   esp_now_add_peer FAILED -- reporting immediate timeout.");
      pingReplied[i] = true; // mark resolved so the timeout sweep below doesn't also report it
      reportPingResult(pingId, PING_BOT_NAMES[i], 0, true);
      continue;
    }
    struct_message msg;
    memset(&msg, 0, sizeof(msg));
    snprintf(msg.command, sizeof(msg.command), "PING");
    esp_err_t result = esp_now_send(oracleMacs[i], (uint8_t*)&msg, sizeof(msg));
    Serial.println(result == ESP_OK ? "[PING]   esp_now_send OK, waiting for PONG..." : "[PING]   esp_now_send FAILED (queued but not accepted by the radio -- check the peer's channel).");
  }
}

// REAL FEATURE ADDED at the user's explicit request: checked every
// loop() iteration while a round is active. Once the window closes,
// anything that hasn't replied yet is reported as a timeout exactly
// once, then the round ends -- a late PONG arriving after this point
// is simply ignored by the PONG handler, since pingRoundActive is
// already false by then.
void checkPingRoundTimeout() {
  if (!pingRoundActive) return;
  if (millis() - pingRoundStartMs < PING_TIMEOUT_MS) return;
  for (int i = 0; i < ORACLE_COUNT; i++) {
    if (!pingReplied[i]) {
      reportPingResult(currentPingId, PING_BOT_NAMES[i], 0, true);
    }
  }
  pingRoundActive = false;
}

// REAL FEATURE ADDED at the user's explicit request: polls the backend
// for a pending "ping fleet" request from the dashboard. Polling, not
// a push, because the manager bot only ever initiates HTTP requests --
// there's no way for Render to reach it directly.
void finishIdCommand(const char* kind, String id, String side, String symbol, bool ok, const char* code, const char* detail); // defined further down; forward-declared here since haltGateBlocks() (below) is used before that point in the file
// ===== HALTCACHE-BEGIN (compiled and tested verbatim by the host simulator) =====
// REAL FEATURE ADDED at the user's explicit request, closing a real safety gap: halting trading is currently just
// a file on Render's disk (see breakerIsTripped() on the backend) -- and Render's free tier filesystem is NOT
// persistent: it can be wiped by ANY restart, not just a redeploy, and Render says it may restart a free service
// at any time. If that happens while a human has halted trading, the backend forgets and trading can silently
// resume with nothing telling anyone it happened.
//
// The fix lives here too, not only on the backend: the manager now keeps its OWN persistent copy of the halt
// state, in its own flash, synced from the backend's /api/ping-check response every ~10s -- a call the manager
// already makes, so this adds no new network traffic. Two fail-safe defaults close most of the gap:
//   - On boot, before the FIRST successful sync, cachedHalted defaults to TRUE (unknown state = treat as halted).
//   - A poll reply with no "halted" key at all (an older/mismatched backend) never changes the cache either way --
//     missing information should never move things toward the LESS safe state.
// One gap this cannot close on its own: a Render restart wipes the backend's OWN halt flag too, so the very next
// reply the manager gets afterward genuinely says "not halted" -- indistinguishable here from a real, hand-pressed
// Resume. What this DOES fully close: a manager reboot (its own flash survives, unlike Render's), and any window
// where the manager would otherwise be acting on stale in-RAM state. A paid Render disk would close the
// remaining gap completely; that tradeoff is the user's call, not made here.
const char* HALT_CACHE_FILE = "/halt_cache.json";
bool cachedHalted = true;          // fail-safe default: unknown = treat as halted, until the first real sync says otherwise
bool haltStateEverSynced = false;  // stays false until the first /api/ping-check reply that actually carries "halted"

void saveHaltCacheToFlash() {
  JsonDocument doc;
  doc["halted"] = cachedHalted;
  File f = LittleFS.open(HALT_CACHE_FILE, "w");
  if (!f) return;
  serializeJson(doc, f);
  f.close();
}

void loadHaltCacheFromFlash() {
  if (!LittleFS.exists(HALT_CACHE_FILE)) return; // no prior save -- stays at the fail-safe default (halted, not yet synced)
  File f = LittleFS.open(HALT_CACHE_FILE, "r");
  if (!f) return;
  JsonDocument doc;
  if (deserializeJson(doc, f) == DeserializationError::Ok) {
    cachedHalted = doc["halted"] | true;
    haltStateEverSynced = true; // a saved file only ever exists after a real sync -- see saveHaltCacheToFlash's only caller
  }
  f.close();
}

// Called from pollForPingRequest() whenever a reply actually carries a "halted" key. Only writes to flash when the
// value actually changes, so this doesn't wear the flash on every 10-second poll.
void updateHaltCacheFromServer(bool serverSaysHalted) {
  haltStateEverSynced = true;
  if (serverSaysHalted == cachedHalted) return;
  cachedHalted = serverSaysHalted;
  saveHaltCacheToFlash();
  Serial.printf("[HALT CACHE] Updated from the backend: now %s\n", cachedHalted ? "HALTED" : "not halted");
}

// Call at the top of handleTradeQ/handleSltpQ/handleCloseQ, before attempting anything. Matches the backend's own
// breaker gate exactly -- it blocks opens, closes, AND stop updates (see /api/order and /api/trading-stop) -- so
// this pre-check has the same reach, not a narrower one.
bool haltGateBlocks(const char* kind, const String& id, const String& side, const String& symbol) {
  if (!cachedHalted) return false;
  const char* why = haltStateEverSynced ? "trading is halted (cached)" : "trading halted -- has not synced with the backend yet";
  finishIdCommand(kind, id, side, symbol, false, "HALT", why);
  return true;
}
// ===== HALTCACHE-END =====

void pollForPingRequest() {
  if (millis() - lastPingPollMs < PING_POLL_INTERVAL_MS) return;
  if (espNowQueueTail != espNowQueueHead) return;              // mgr-2: a queued trade / stop update goes first
  if (!backendHousekeepingDue(millis())) return;               // mgr-2: the backend just failed to answer; do not hammer it
  lastPingPollMs = millis();
  if (pingRoundActive) return; // one round at a time -- let the current one finish or time out first

  int pollCode = 0;
  String res = sendGetShort("/api/ping-check", pollCode);
  if (res.length() == 0) return;
  JsonDocument doc;
  if (deserializeJson(doc, res) != DeserializationError::Ok) return;
  if (!doc["halted"].isNull()) updateHaltCacheFromServer(doc["halted"].as<bool>()); // see the HALTCACHE block
  if (doc["pingId"].isNull()) return;
  startPingRound(doc["pingId"].as<String>());
}

bool setSymbolLeverage(String symbol, int leverage) {
  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\",\"buyLeverage\":\"" + String(leverage) + "\",\"sellLeverage\":\"" + String(leverage) + "\"}";
  String res = sendPostRequest("/api/set-leverage", payload);
  Serial.println("[RESPONSE] " + res);
  JsonDocument doc;
  deserializeJson(doc, res);
  return (doc["success"] == true);
}




// REAL GAP FOUND, fixed at the user's explicit request: the TRADE
// handler used to just wait a fixed 500ms after opening before trying
// to set the trailing stop, hoping that was long enough for Bybit's own
// systems to register the new position. That's a guess, not a check --
// under worse network conditions or exchange load, the trailing-stop
// call could fire before the position actually exists yet on Bybit's
// side, fail, and there was no retry. This replaces the guess with an
// actual check: poll /api/positions for the specific symbol+side that
// was just opened, a few times, spaced apart, until it genuinely shows
// up (or genuinely doesn't, within a bounded number of tries -- this
// still can't wait forever).
const int POSITION_POLL_MAX_ATTEMPTS = 6;
const unsigned long POSITION_POLL_DELAY_MS = 700; // ~4.2s worst case total wait

bool waitForPositionToRegister(String symbol, String expectedBybitSide) {
  for (int attempt = 1; attempt <= POSITION_POLL_MAX_ATTEMPTS; attempt++) {
    delay(POSITION_POLL_DELAY_MS);
    String res = sendGetRequest("/api/positions");
    if (res.length() == 0) {
      Serial.printf("[POLL] Attempt %d/%d: no response from server, retrying...\n", attempt, POSITION_POLL_MAX_ATTEMPTS);
      continue;
    }
    JsonDocument doc;
    if (deserializeJson(doc, res) != DeserializationError::Ok || doc["success"] != true) {
      Serial.printf("[POLL] Attempt %d/%d: could not parse positions response, retrying...\n", attempt, POSITION_POLL_MAX_ATTEMPTS);
      continue;
    }
    JsonArray positions = doc["positions"].as<JsonArray>();
    for (JsonObject pos : positions) {
      String posSymbol = pos["symbol"].as<String>();
      String posSide = pos["side"].as<String>();
      float size = pos["size"].as<float>();
      if (posSymbol == symbol && posSide == expectedBybitSide && size > 0.0f) {
        Serial.printf("[POLL] Position confirmed on attempt %d/%d (size %.6f).\n", attempt, POSITION_POLL_MAX_ATTEMPTS, size);
        return true;
      }
    }
    Serial.printf("[POLL] Attempt %d/%d: %s not showing yet, retrying...\n", attempt, POSITION_POLL_MAX_ATTEMPTS, symbol.c_str());
  }
  return false;
}


void fetchAndPrintPositions() {
  Serial.println("\n--- POSITIONS ---");
  String response = sendGetRequest("/api/positions");
  if (response.length() == 0) { Serial.println("[ERROR] Server communication failed."); return; }

  JsonDocument doc;
  if (deserializeJson(doc, response) != DeserializationError::Ok) { Serial.println("[ERROR] Could not parse response."); return; }

  if (doc["success"] != true) { Serial.println("[ERROR] Failed to fetch positions."); return; }

  int count = doc["count"];
  if (count == 0) {
    Serial.println("No active positions.");
    return;
  }

  Serial.printf("%-10s | %-5s | %-6s | %-10s | %-10s | %-10s | %-8s\n",
                "SYMBOL", "SIDE", "LEV", "ENTRY", "MARK", "VAL(USD)", "PnL(USDT)");
  JsonArray positions = doc["positions"].as<JsonArray>();
  float totalPnl = 0.0;
  for (JsonObject pos : positions) {
    const char* symbol = pos["symbol"];
    const char* side   = pos["side"];
    const char* lev    = pos["leverage"];
    const char* entry  = pos["entryPrice"];
    const char* mark   = pos["markPrice"];
    const char* val    = pos["positionValue"];
    float pnl          = pos["unrealisedPnl"].as<float>();
    totalPnl += pnl;
    Serial.printf("%-10s | %-5s | %-5sx | %-10s | %-10s | $%-9s | %+.2f\n", symbol, side, lev, entry, mark, val, pnl);
  }
  Serial.printf("TOTAL UNREALIZED PnL: %+.2f USDT\n", totalPnl);
}

// ====================================================================================================
// EXECUTION WITH REAL OUTCOMES -- REAL FEATURE ADDED at the user's explicit request.
// Every failure the old code met (low balance, a pair Bybit doesn't list, a quantity below Bybit's
// minimum, a rejected leverage, Bybit refusing the order, a dead backend) used to print one line to
// THIS device's Serial and stop: nothing went back to the bot, nothing reached the dashboard, and the
// order reply from /api/order was never even read. Now each ends in a short code:
//   OK      done                         PAPER   accepted in paper mode (nothing sent to Bybit)
//   BAL     not enough balance           PAIR    pair not available on Bybit
//   MINQ    below Bybit's minimum size   LEV     leverage rejected
//   HELD    already in a position here   HALT    trading halted on the dashboard
//   NET     backend/Bybit unreachable    BYBIT   Bybit refused it (full reason goes to the dashboard)
//   NOTRL   position open, but the trailing stop could not be set
//   NOPOS   no open position to update/close      SIDE   open position is on the other side
// Only primitive types appear in these signatures (results travel in the two globals below), so the
// Arduino IDE's automatic prototypes cannot trip over a struct that is declared later in the file.
// ====================================================================================================
const float BAL_USABLE_FRACTION = 0.97f;   // leave ~3% of the free balance for fees and price movement
const float BAL_MIN_SCALE_FRACTION = 0.5f; // never open smaller than half of what the bot asked for
char g_execCode[8] = "OK";
char g_execDetail[96] = "";
bool g_lastOrderWasPaper = false;

// ===== MANAGERUI-BEGIN (compiled and tested verbatim by the host simulator) =====
// REAL FEATURE ADDED at the user's explicit request: the manager had no page of its own -- everything about it was
// only visible on the Render dashboard (which needs the internet to be up) or this device's own Serial monitor
// (which needs a USB cable plugged in). This is a small page served BY the manager itself, in the same dark theme
// the bots already use, showing the Bybit executions it has handled -- nothing else, as asked for -- auto-refreshing
// so it can just be left open.
//
// EXEC_LOG_CAPACITY is generous (the manager runs nothing like the bots' 100-pair scan engine, so it has real RAM
// headroom) but still bounded, same reasoning as every other ring buffer in this project.
const int EXEC_LOG_CAPACITY = 30;
struct ExecLogEntry {
  bool used = false;
  char bot[20] = "";
  char kind[8] = "";
  char side[6] = "";
  char symbol[16] = "";
  char code[8] = "";
  char detail[100] = "";
  bool ok = false;
  unsigned long atEpoch = 0;
};
ExecLogEntry execLog[EXEC_LOG_CAPACITY];
int execLogHead = 0;
int execLogCount = 0;
WebServer managerWeb(80);

// Same three-way split the dashboard already uses for these exact codes (backend/server.js's EXEC_QUIET/WARN/FAIL_CODES) --
// kept here too so this page can colour a result without depending on the backend being reachable.
bool execCodeIsWarn(const char* code) {
  const char* warn[] = { "NOTRL", "SCALED", "LEVCLMP", "HELD", "HALT", "SIDE" };
  for (int i = 0; i < 6; i++) if (strcmp(code, warn[i]) == 0) return true;
  return false;
}
bool execCodeIsQuiet(const char* code) {
  const char* quiet[] = { "OK", "DUP", "NOCHG", "PAPER", "NOPOS" };
  for (int i = 0; i < 5; i++) if (strcmp(code, quiet[i]) == 0) return true;
  return false;
}

// The single place every completed Bybit attempt already passes through (see reportExec() below) -- logging it here
// costs nothing extra to compute, it is simply kept locally as well as sent to the dashboard.
void logExecLocally(const char* bot, const char* kind, const char* side, const char* symbol, bool ok, const char* code, const char* detail) {
  ExecLogEntry& e = execLog[execLogHead];
  e = ExecLogEntry();
  e.used = true;
  strncpy(e.bot, bot, sizeof(e.bot) - 1);
  strncpy(e.kind, kind, sizeof(e.kind) - 1);
  strncpy(e.side, side, sizeof(e.side) - 1);
  strncpy(e.symbol, symbol, sizeof(e.symbol) - 1);
  strncpy(e.code, code, sizeof(e.code) - 1);
  strncpy(e.detail, detail, sizeof(e.detail) - 1);
  e.ok = ok;
  e.atEpoch = (unsigned long)time(nullptr);
  execLogHead = (execLogHead + 1) % EXEC_LOG_CAPACITY;
  if (execLogCount < EXEC_LOG_CAPACITY) execLogCount++;
}

String execAgo(unsigned long atEpoch) {
  unsigned long now = (unsigned long)time(nullptr);
  if (atEpoch == 0 || now < atEpoch) return "just now";
  unsigned long s = now - atEpoch;
  if (s < 60) return String(s) + "s ago";
  if (s < 3600) return String(s / 60) + "m ago";
  return String(s / 3600) + "h ago";
}
String execKindLabel(const char* k) {
  if (strcmp(k, "SLTP") == 0) return "stop update";
  if (strcmp(k, "CLOSE") == 0) return "close";
  return "order";
}
String execDirLabel(const char* side) {
  if (strcmp(side, "BUY") == 0) return "long";
  if (strcmp(side, "SELL") == 0) return "short";
  return "";
}
String execHtmlEscape(const String& in) {
  String out; out.reserve(in.length());
  for (unsigned int i = 0; i < in.length(); i++) {
    char c = in[i];
    if (c == '<') out += "&lt;"; else if (c == '>') out += "&gt;"; else if (c == '&') out += "&amp;"; else out += c;
  }
  return out;
}

// One page: a status pill and the last EXEC_LOG_CAPACITY Bybit executions, newest first, auto-refreshing every 5s.
String managerHealthHtml();   // defined after this block (needs the heap / backend numbers)
void handleManagerHome() {
  // REAL FEATURE ADDED at the user's explicit request: this page is otherwise reachable by anything on the same
  // WiFi network. Standard HTTP Basic Auth -- the browser prompts once and remembers it for the session, no login
  // page or token to build. Username is fixed since there's only ever one person using this page.
  if (!managerWeb.authenticate("admin", MANAGER_UI_PASSWORD)) return managerWeb.requestAuthentication();
  int sentToday = 0, failedToday = 0;
  unsigned long nowEpoch = (unsigned long)time(nullptr);
  for (int i = 0; i < execLogCount; i++) {
    ExecLogEntry& e = execLog[i];
    if (e.used && nowEpoch >= e.atEpoch && (nowEpoch - e.atEpoch) < 86400UL) { if (e.ok) sentToday++; else failedToday++; }
  }
  String html;
  html.reserve(6000);
  html += "<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<meta http-equiv='refresh' content='5'>";
  html += "<title>YM Oracle Manager</title>";
  html += "<style>:root{--bg:#0a0c10;--panel:#12151c;--panel2:#181c25;--line:#242938;--mist:#8891a3;--paper:#eef1f6;--long:#22c55e;--short:#ef4444;--signal:#8b5cf6;--pending:#f2b134;}";
  html += "*{box-sizing:border-box;}body{background:var(--bg);color:var(--paper);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin:0;padding:14px;max-width:520px;margin:0 auto;}";
  html += ".card{background:var(--panel);border:0.5px solid var(--line);border-radius:10px;padding:14px;margin-bottom:12px;}";
  html += ".pill{font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:500;padding:3px 10px;border-radius:20px;border:0.5px solid var(--long);color:var(--long);}";
  html += ".stat{background:var(--panel);border:0.5px solid var(--line);border-radius:10px;padding:10px 12px;}";
  html += ".statLabel{font-size:10.5px;color:var(--mist);margin:0 0 3px;}.statVal{font-size:19px;font-weight:500;margin:0;}";
  html += ".row{display:flex;justify-content:space-between;align-items:baseline;padding:8px 0;border-top:0.5px solid var(--line);font-size:12px;}";
  html += ".row:first-child{border-top:none;}.meta{font-size:10.5px;color:var(--mist);margin-top:2px;}";
  html += ".bots{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}.bot{background:var(--panel);border:0.5px solid var(--line);border-radius:10px;padding:10px 12px;text-decoration:none;color:var(--paper);display:block;}";
  html += ".dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;}.bn{font-size:12px;font-weight:500;}.bu{font-size:10.5px;color:var(--mist);margin-top:3px;word-break:break-all;}</style></head><body>";
  html += "<div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;'>";
  html += "<span style='font-family:monospace;font-size:15px;font-weight:500;'>YM Oracle Manager</span>";
  html += "<span class='pill'>online</span></div>";
  html += "<div style='display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;'>";
  html += "<div class='stat'><p class='statLabel'>Sent (24h)</p><p class='statVal'>" + String(sentToday) + "</p></div>";
  html += "<div class='stat'><p class='statLabel' style='color:" + String(failedToday > 0 ? "var(--short)" : "var(--mist)") + ";'>Failed (24h)</p><p class='statVal' style='color:" + String(failedToday > 0 ? "var(--short)" : "var(--paper)") + ";'>" + String(failedToday) + "</p></div></div>";
  // Bot status: pure arithmetic on timestamps already in memory -- no network call, no waiting on a bot.
  html += "<div class='bots'>";
  unsigned long nowMs = millis();
  for (int i = 0; i < ORACLE_COUNT; i++) {
    const char* col = "var(--short)"; String label = "never heard";
    if (oracleEverHeard[i]) {
      unsigned long ago = (nowMs - oracleLastHeardMs[i]) / 1000UL;
      if (ago < 150) col = "var(--long)"; else if (ago < 300) col = "var(--pending)"; else col = "var(--short)";
      label = (ago < 60) ? String(ago) + "s ago" : (ago < 3600) ? String(ago / 60) + "m ago" : String(ago / 3600) + "h ago";
    }
    String host = String(ORACLE_LOCAL_HOSTS[i]) + ".local";
    html += "<a class='bot' target='_blank' href='http://" + host + "/'><div class='bn'><span class='dot' style='background:" + String(col) + ";'></span>" + execHtmlEscape(String(PING_BOT_NAMES[i])) + "</div>";
    html += "<div class='meta'>" + label + "</div><div class='bu'>" + host + "</div></a>";
  }
  html += "</div>";
  if (mgrUnknownSenders > 0) html += "<div class='card' style='border-color:var(--short);'><p style='font-size:11px;margin:0;color:var(--short);'>Sender check: " + String((unsigned long)mgrUnknownSenders) + " frame(s) from an unknown MAC (" + macToString(mgrLastUnknownMac) + ")" + String(MGR_SENDER_CHECK >= 2 ? " - dropped." : " - log-only, not dropped.") + "</p></div>";
  html += managerHealthHtml();
  html += "<div class='card'><p style='font-size:11px;color:var(--mist);margin:0 0 4px;'>Bybit executions</p>";
  if (execLogCount == 0) {
    html += "<p style='font-size:12px;color:var(--mist);margin:6px 0;'>Nothing sent to Bybit yet.</p>";
  } else {
    for (int i = 0; i < execLogCount; i++) {
      int idx = (execLogHead - 1 - i + EXEC_LOG_CAPACITY * 2) % EXEC_LOG_CAPACITY;
      ExecLogEntry& e = execLog[idx];
      if (!e.used) continue;
      String color = e.ok ? (execCodeIsWarn(e.code) ? "var(--pending)" : "var(--long)") : "var(--short)";
      String what = execHtmlEscape(String(e.symbol)) + (execDirLabel(e.side).length() ? " " + execDirLabel(e.side) : "") + " " + execKindLabel(e.kind) + " &middot; " + execHtmlEscape(String(e.bot));
      html += "<div class='row'><div><span style='color:" + color + ";'>&#9679;</span> " + what;
      html += "<div class='meta'>" + execHtmlEscape(String(e.detail)) + "</div></div><div class='meta' style='white-space:nowrap;'>" + execAgo(e.atEpoch) + "</div></div>";
    }
  }
  html += "</div></body></html>";
  managerWeb.send(200, "text/html", html);
}
// ===== MANAGERUI-END =====


void execSet(const char* code, String detail) {
  strncpy(g_execCode, code, sizeof(g_execCode) - 1);
  g_execCode[sizeof(g_execCode) - 1] = '\0';
  strncpy(g_execDetail, detail.c_str(), sizeof(g_execDetail) - 1);
  g_execDetail[sizeof(g_execDetail) - 1] = '\0';
}

// Reads the backend's answer to /api/order or /api/trading-stop.
// Returns 1 = the exchange accepted it, 0 = a definitive "no", 2 = no usable answer (safe to retry).
int classifyExchangeReply(String body, int httpCode) {
  if (body.length() == 0 || httpCode <= 0) {
    execSet("NET", "no reply from the backend (HTTP " + String(httpCode) + ")");
    return 2;
  }
  JsonDocument doc;
  if (deserializeJson(doc, body) != DeserializationError::Ok) {
    execSet("NET", "unreadable reply from the backend (HTTP " + String(httpCode) + ")");
    return 2;
  }
  if (doc["paper"] == true) {
    g_lastOrderWasPaper = true;
    execSet("PAPER", "paper mode: nothing was sent to Bybit");
    return 1;
  }
  if (doc["retCode"].is<int>()) { // Bybit's own answer, passed straight through by the backend
    int rc = doc["retCode"].as<int>();
    String msg = String(doc["retMsg"] | "no message");
    if (rc == 0) { execSet("OK", "accepted"); return 1; }
    if (rc == 110072) { execSet("DUP", "already placed (same orderLinkId)"); return 1; }
    if (rc == 34040) { execSet("NOCHG", "already at that value"); return 1; }
    String low = msg;
    low.toLowerCase();
    const char* code = "BYBIT";
    if (rc == 110007 || rc == 110004 || rc == 110012 || rc == 110045 || low.indexOf("insufficient") >= 0 || low.indexOf("not enough") >= 0) {
      code = "BAL";
    } else if (rc == 110094 || (low.indexOf("min") >= 0 && (low.indexOf("qty") >= 0 || low.indexOf("value") >= 0 || low.indexOf("notional") >= 0 || low.indexOf("size") >= 0))) {
      code = "MINQ";
    } else if (low.indexOf("symbol") >= 0 && (low.indexOf("invalid") >= 0 || low.indexOf("not exist") >= 0 || low.indexOf("not found") >= 0)) {
      code = "PAIR";
    }
    execSet(code, "Bybit " + String(rc) + ": " + msg);
    return 0;
  }
  String message = String(doc["message"] | "");
  message.toLowerCase();
  if (message.indexOf("halted") >= 0) { execSet("HALT", "trading is halted on the dashboard"); return 0; }
  if (doc["error"].is<const char*>()) { // the backend itself threw (e.g. it could not reach Bybit) -- transient
    execSet("NET", "backend error: " + String(doc["error"] | "unknown"));
    return 2;
  }
  if (doc["success"] == false) { execSet("BYBIT", "backend: " + String(doc["message"] | "refused") + " (HTTP " + String(httpCode) + ")"); return 0; }
  execSet("OK", "accepted");
  return 1;
}

float getAccountBalanceRetry() {
  for (int attempt = 0; attempt < 3; attempt++) {
    float bal = getAccountBalance();
    if (bal >= 0) return bal;
    delay(500);
  }
  return -1.0f;
}

// 1 = a position is open on this symbol (side and size filled in), 0 = none, -1 = could not check
int checkHeldPosition(String symbol, String &outSide, String &outSize) {
  outSide = "";
  outSize = "";
  for (int attempt = 0; attempt < 3; attempt++) {
    int httpCode = 0;
    String res = sendGetRequestEx("/api/positions", httpCode);
    if (res.length() == 0) { delay(500); continue; }
    JsonDocument doc;
    if (deserializeJson(doc, res) != DeserializationError::Ok || doc["success"] != true) { delay(500); continue; }
    JsonArray positions = doc["positions"].as<JsonArray>();
    for (JsonObject pos : positions) {
      if (pos["symbol"].as<String>() == symbol && pos["size"].as<float>() > 0.0f) {
        outSide = pos["side"].as<String>();
        outSize = pos["size"].as<String>();
        return 1;
      }
    }
    return 0;
  }
  return -1;
}

float getLivePriceEx(String symbol) {
  for (int attempt = 0; attempt < 3; attempt++) {
    int httpCode = 0;
    String res = sendGetRequestEx("/api/price/" + symbol, httpCode);
    if (httpCode == 400) { execSet("PAIR", symbol + " has no price on Bybit (pair not available)"); return -1.0f; }
    if (res.length() == 0) { delay(500); continue; }
    JsonDocument doc;
    if (deserializeJson(doc, res) == DeserializationError::Ok && doc["success"] == true) return doc["price"].as<float>();
    delay(500);
  }
  execSet("NET", "could not read the price for " + symbol);
  return -1.0f;
}

// The old version silently fell back to made-up defaults (step 0.001 / min 0.001) when this lookup
// failed, which sized the order wrong. Now a failed lookup is a reported failure.
// The last instrument lookup, kept for 60s. executeOrderEx() needs the pair's leverage cap BEFORE it sets leverage,
// and calculateContractQtyEx() needs the sizing rules right after -- this makes that one HTTPS call, not two.
struct InstrCache { bool valid; char symbol[24]; float qtyStep; float minQty; float minNotional; float maxLev; unsigned long ms; };
InstrCache g_instr = {false, "", 0.0f, 0.0f, 0.0f, 0.0f, 0};

bool getInstrumentInfoEx(String symbol, float &qtyStep, float &minQty, float &minNotional) {
  qtyStep = 0.0f;
  minQty = 0.0f;
  minNotional = 0.0f;
  if (g_instr.valid && strcmp(symbol.c_str(), g_instr.symbol) == 0 && (millis() - g_instr.ms) < 60000UL) {
    qtyStep = g_instr.qtyStep; minQty = g_instr.minQty; minNotional = g_instr.minNotional;
    return true;
  }
  for (int attempt = 0; attempt < 3; attempt++) {
    int httpCode = 0;
    String res = sendGetRequestEx("/api/instrument/" + symbol, httpCode);
    if (httpCode == 400) { execSet("PAIR", symbol + " is not listed on Bybit (pair not available)"); return false; }
    if (res.length() == 0) { delay(500); continue; }
    JsonDocument doc;
    if (deserializeJson(doc, res) == DeserializationError::Ok && doc["success"] == true) {
      qtyStep = doc["qtyStep"].as<float>();
      minQty = doc["minOrderQty"].as<float>();
      minNotional = doc["minNotional"] | 0.0f; // older backends don't send it: 0 = unknown, skip that check
      if (qtyStep <= 0.0f) qtyStep = minQty > 0.0f ? minQty : 0.001f;
      g_instr.valid = true;
      strncpy(g_instr.symbol, symbol.c_str(), sizeof(g_instr.symbol) - 1);
      g_instr.symbol[sizeof(g_instr.symbol) - 1] = '\0';
      g_instr.qtyStep = qtyStep; g_instr.minQty = minQty; g_instr.minNotional = minNotional;
      g_instr.maxLev = doc["maxLeverage"] | 0.0f; // 0 = unknown: no clamp
      g_instr.ms = millis();
      return true;
    }
    delay(500);
  }
  execSet("NET", "could not read the instrument rules for " + symbol);
  return false;
}

String calculateContractQtyEx(String symbol, float positionUsdValue, int leverage, float &outPrice) {
  outPrice = getLivePriceEx(symbol);
  if (outPrice <= 0.0f) return "";
  float qtyStep, minQty, minNotional;
  if (!getInstrumentInfoEx(symbol, qtyStep, minQty, minNotional)) return "";

  float minMargin = (minQty * outPrice) / (leverage > 0 ? leverage : 1);
  if (minNotional > 0.0f && positionUsdValue < minNotional) {
    float need = minNotional / (leverage > 0 ? leverage : 1);
    execSet("MINQ", "position $" + String(positionUsdValue, 2) + " is under Bybit's $" + String(minNotional, 2) + " minimum; need >= $" + String(need, 2) + " margin at " + String(leverage) + "x");
    return "";
  }
  float rawQty = positionUsdValue / outPrice;
  if (rawQty < minQty) {
    execSet("MINQ", "min order " + String(minQty, 4) + " (~$" + String(minQty * outPrice, 2) + "); need >= $" + String(minMargin, 2) + " margin at " + String(leverage) + "x");
    return "";
  }
  // Round DOWN TO A MULTIPLE OF THE STEP. The old code only rounded to the step's decimal places, which
  // is wrong for any token whose step is above 1 (10, 100, 1000...): e.g. step 10 and a raw quantity of
  // 456 was sent as "456", which Bybit rejects as an invalid quantity.
  double stepsD = floor((double)rawQty / (double)qtyStep + 1e-9);
  double roundedQty = stepsD * (double)qtyStep;
  if (roundedQty < (double)minQty) {
    execSet("MINQ", "after rounding to the step the size is under Bybit's minimum " + String(minQty, 4));
    return "";
  }
  int decimals = getPrecisionDecimals(qtyStep);
  return String((float)roundedQty, decimals);
}

bool setSymbolLeverageEx(String symbol, int leverage) {
  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\",\"buyLeverage\":\"" + String(leverage) + "\",\"sellLeverage\":\"" + String(leverage) + "\"}";
  for (int attempt = 0; attempt < 2; attempt++) {
    int httpCode = 0;
    String res = sendPostRequestEx("/api/set-leverage", payload, httpCode);
    if (res.length() == 0) { delay(500); continue; }
    JsonDocument doc;
    if (deserializeJson(doc, res) != DeserializationError::Ok) { delay(500); continue; }
    if (doc["success"] == true) return true;
    execSet("LEV", "Bybit rejected " + String(leverage) + "x: " + String(doc["message"] | "no message"));
    return false;
  }
  execSet("NET", "could not reach Bybit to set the leverage");
  return false;
}

// Sends an order-type request and only gives up on a NON-answer after three tries. Every try carries the
// same orderLinkId, so if the first request actually reached Bybit but its reply was lost, the retry is
// refused as a duplicate (retCode 110072, treated as success) instead of placing a second order.
bool submitOrderReliably(String payload, String symbol, String expectedBybitSide, bool isCloseOrder) {
  for (int attempt = 1; attempt <= 3; attempt++) {
    int httpCode = 0;
    String res = sendPostRequestEx("/api/order", payload, httpCode);
    Serial.println("[RESPONSE] " + res);
    int verdict = classifyExchangeReply(res, httpCode);
    if (verdict == 1) return true;
    if (verdict == 0) return false;
    if (attempt < 3) {
      Serial.printf("[RETRY] order attempt %d/3 got no usable answer -- retrying with the same orderLinkId (safe: a duplicate is refused).\n", attempt);
      delay(1500UL * attempt);
    }
  }
  // Three non-answers: the order may still have gone through. Look before declaring failure.
  String heldSide, heldSize;
  int held = checkHeldPosition(symbol, heldSide, heldSize);
  if (isCloseOrder ? (held == 0) : (held == 1 && heldSide == expectedBybitSide)) {
    execSet("OK", "confirmed on Bybit after lost replies");
    return true;
  }
  execSet("NET", "no usable reply from the backend after 3 tries");
  return false;
}

bool executeOrderEx(String side, String symbol, float usdMargin, int leverage, String tp, String sl, String orderLinkId) {
  Serial.println("\n--- OPEN TRADE ---");
  g_lastOrderWasPaper = false;
  String bybitSide = (side == "BUY") ? "Buy" : "Sell";

  float availableBal = getAccountBalanceRetry();
  if (availableBal < 0) { execSet("NET", "could not read the Bybit balance"); Serial.println("[ERROR] " + String(g_execDetail)); return false; }
  // REAL CHANGE at the user's request ("what happens when the balance is low"): a trade that does not quite fit is
  // OPENED SMALLER (never larger, never more than the free balance) rather than refused -- but only down to half
  // of what was asked; below that it is refused and reported, because a fraction of the intended trade is not the
  // trade the bot analysed. 3% is left for fees and price movement between the check and the fill.
  const float usable = availableBal * BAL_USABLE_FRACTION;
  const float requestedMargin = usdMargin;
  bool marginScaled = false;
  if (usdMargin > usable) {
    if (usable > 0.0f && usable >= requestedMargin * BAL_MIN_SCALE_FRACTION) {
      Serial.printf("[BALANCE] Wanted $%.2f margin but only $%.2f is free -- opening with $%.2f instead.\n", requestedMargin, availableBal, usable);
      usdMargin = usable;
      marginScaled = true;
    } else {
      execSet("BAL", "wanted $" + String(requestedMargin, 2) + " margin, only $" + String(availableBal, 2) + " free");
      Serial.println("[ERROR] " + String(g_execDetail));
      return false;
    }
  }

  // One position per symbol: a second signal on a pair already held would net against (or flip) the
  // first in Bybit's one-way mode and overwrite its TP/SL.
  String heldSide, heldSize;
  if (checkHeldPosition(symbol, heldSide, heldSize) == 1) {
    execSet("HELD", "already in a " + heldSide + " position on " + symbol);
    Serial.println("[ERROR] " + String(g_execDetail));
    return false;
  }

  // Is the pair listed AND tradable on Bybit? Asked first, before anything is touched -- and it also tells us the
  // pair's leverage cap. A bot asking for more than the pair allows used to be refused outright (Bybit keeps the
  // old leverage and the sizing would then be wrong); it is now clamped to the cap and the trade goes ahead.
  const int requestedLeverage = leverage;
  {
    float pairStep = 0.0f, pairMinQty = 0.0f, pairMinNotional = 0.0f;
    if (!getInstrumentInfoEx(symbol, pairStep, pairMinQty, pairMinNotional)) {
      Serial.println("[ERROR] " + String(g_execDetail) + " -- no order placed.");
      return false;
    }
    if (g_instr.maxLev >= 1.0f && leverage > (int)g_instr.maxLev) {
      leverage = (int)g_instr.maxLev;
      Serial.printf("[LEVERAGE] %s allows at most %dx, not %dx -- using %dx.\n", symbol.c_str(), leverage, requestedLeverage, leverage);
    }
  }
  Serial.printf("[STEP] Setting leverage to %dx for %s...\n", leverage, symbol.c_str());
  // If Bybit refuses the requested leverage it keeps the old one, and sizing the order for the requested
  // leverage would then use more real margin than intended -- so a refusal aborts the trade.
  if (!setSymbolLeverageEx(symbol, leverage)) {
    Serial.println("[ERROR] " + String(g_execDetail) + " -- no order placed.");
    return false;
  }

  float priceUsed = 0.0f;
  String qtyStr = calculateContractQtyEx(symbol, usdMargin * leverage, leverage, priceUsed);
  if (qtyStr == "") { Serial.println("[ERROR] " + String(g_execDetail) + " -- no order placed."); return false; }

  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\",\"side\":\"" + bybitSide + "\",\"orderType\":\"Market\",\"qty\":\"" + qtyStr + "\",\"orderLinkId\":\"" + orderLinkId + "\"";
  if (tp.length() > 0) payload += ",\"takeProfit\":\"" + tp + "\"";
  if (sl.length() > 0) payload += ",\"stopLoss\":\"" + sl + "\"";
  payload += "}";

  Serial.printf("[TRADE] %s %s | Margin: $%.2f | Lev: %dx | Entry ~$%.4f | Qty: %s | TP: %s | SL: %s | link: %s\n",
                bybitSide.c_str(), symbol.c_str(), usdMargin, leverage, priceUsed, qtyStr.c_str(),
                tp.length() ? tp.c_str() : "(none)", sl.length() ? sl.c_str() : "(none)", orderLinkId.c_str());
  bool ok = submitOrderReliably(payload, symbol, bybitSide, false);
  if (!ok) Serial.println("[ERROR] " + String(g_execCode) + ": " + String(g_execDetail));
  // The order went through, but not exactly as asked: say so, so the bot (and the dashboard) can tell.
  if (ok && (marginScaled || leverage != requestedLeverage) && strcmp(g_execCode, "OK") == 0) {
    String note = "";
    if (marginScaled) note += "margin $" + String(requestedMargin, 2) + "->$" + String(usdMargin, 2) + " (only $" + String(availableBal, 2) + " free)";
    if (leverage != requestedLeverage) note += String(note.length() ? "; " : "") + "leverage " + String(requestedLeverage) + "x->" + String(leverage) + "x (pair cap)";
    execSet(marginScaled ? "SCALED" : "LEVCLMP", note);
  }
  return ok;
}

bool updateTpSlEx(String symbol, String tp, String sl) {
  Serial.println("\n--- UPDATE TP/SL ---");
  if (tp.length() == 0 && sl.length() == 0) { execSet("BAD", "nothing to update"); return false; }
  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\"";
  if (tp.length() > 0) payload += ",\"takeProfit\":\"" + tp + "\"";
  if (sl.length() > 0) payload += ",\"stopLoss\":\"" + sl + "\"";
  payload += "}";
  Serial.printf("[TPSL] %s | TP: %s | SL: %s\n", symbol.c_str(), tp.length() ? tp.c_str() : "(unchanged)", sl.length() ? sl.c_str() : "(unchanged)");
  for (int attempt = 1; attempt <= 3; attempt++) {
    int httpCode = 0;
    String res = sendPostRequestEx("/api/trading-stop", payload, httpCode);
    Serial.println("[RESPONSE] " + res);
    int verdict = classifyExchangeReply(res, httpCode);
    if (verdict == 1) return true;
    if (verdict == 0) return false;
    if (attempt < 3) delay(1500UL * attempt);
  }
  return false;
}

bool setTrailingStopEx(String symbol, String activePrice, float trailPct) {
  Serial.println("\n--- SET TRAILING STOP ---");
  if (trailPct <= 0) { execSet("BAD", "trail percentage must be positive"); return false; }
  float livePrice = getLivePriceEx(symbol);
  if (livePrice <= 0) return false;
  float trailDistance = livePrice * (trailPct / 100.0f);
  String trailDistanceStr = String(trailDistance, 4);
  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\",\"trailingStop\":\"" + trailDistanceStr + "\"";
  if (activePrice.length() > 0) payload += ",\"activePrice\":\"" + activePrice + "\"";
  payload += "}";
  Serial.printf("[TRAIL] %s | Live price: $%.4f | Trail: %.2f%% -> distance $%s | Active/trigger price: %s\n",
                symbol.c_str(), livePrice, trailPct, trailDistanceStr.c_str(),
                activePrice.length() ? activePrice.c_str() : "(activates immediately)");
  for (int attempt = 1; attempt <= 3; attempt++) {
    int httpCode = 0;
    String res = sendPostRequestEx("/api/trading-stop", payload, httpCode);
    Serial.println("[RESPONSE] " + res);
    int verdict = classifyExchangeReply(res, httpCode);
    if (verdict == 1) return true;
    if (verdict == 0) return false;
    if (attempt < 3) delay(1500UL * attempt);
  }
  return false;
}

// expectedBybitSide: "Buy"/"Sell" to close only if the open position is on that side, or "" to close whatever is open.
// Returns true when there is nothing left open (either just closed, or it was already flat -- code NOPOS).
bool closePositionEx(String symbol, String expectedBybitSide, String orderLinkId) {
  Serial.println("\n--- CLOSE POSITION ---");
  String heldSide, heldSize;
  int held = checkHeldPosition(symbol, heldSide, heldSize);
  if (held == -1) { execSet("NET", "could not read the open positions"); return false; }
  if (held == 0) { execSet("NOPOS", "no open position on " + symbol + " (already closed)"); return true; }
  if (expectedBybitSide.length() > 0 && heldSide != expectedBybitSide) {
    execSet("SIDE", "open position on " + symbol + " is " + heldSide + ", not " + expectedBybitSide + " -- left alone");
    return false;
  }
  String closeSide = (heldSide == "Buy") ? "Sell" : "Buy";
  String payload = "{\"category\":\"linear\",\"symbol\":\"" + symbol + "\",\"side\":\"" + closeSide +
                   "\",\"orderType\":\"Market\",\"qty\":\"" + heldSize + "\",\"reduceOnly\":true,\"orderLinkId\":\"" + orderLinkId + "\"}";
  Serial.printf("[CLOSE] %s | Current side: %s | Size: %s | Submitting %s reduceOnly to close...\n", symbol.c_str(), heldSide.c_str(), heldSize.c_str(), closeSide.c_str());
  return submitOrderReliably(payload, symbol, closeSide, true);
}

String botNameForMac(const uint8_t* mac) {
  for (int i = 0; i < ORACLE_COUNT; i++) {
    if (memcmp(mac, oracleMacs[i], 6) == 0) return String(PING_BOT_NAMES[i]);
  }
  return String("unknown bot");
}

// Tells the dashboard what happened, so a failure is visible somewhere other than this device's Serial.
void reportExec(const char* kind, const char* id, String side, String symbol, bool ok, const char* code, const char* detail) {
  JsonDocument doc;
  String botName = currentMessageHasSrc ? botNameForMac(currentMessageSrc) : String("serial");
  // c_str() of strings that stay alive until serializeJson() below has finished
  doc["bot"] = botName.c_str();
  doc["id"] = id;
  doc["kind"] = kind;
  doc["side"] = side.c_str();
  doc["symbol"] = symbol.c_str();
  doc["ok"] = ok;
  doc["code"] = code;
  doc["detail"] = detail;
  String payload;
  serializeJson(doc, payload);
  int postCode = 0;
  sendPostShort("/api/exec-report", payload, postCode);
  logExecLocally(botName.c_str(), kind, side.c_str(), symbol.c_str(), ok, code, detail); // this device's own copy -- see the MANAGERUI block
}

// Common ending for TRADEQ / SLTPQ / CLOSEQ: answer the bot first (it is waiting), then tell the dashboard.
void finishIdCommand(const char* kind, String id, String side, String symbol, bool ok, const char* code, const char* detail) {
  Serial.printf("[RESULT] %s %s %s -> %s (%s)%s%s\n", kind, side.c_str(), symbol.c_str(), ok ? "OK" : "FAILED", code, strlen(detail) ? " : " : "", detail);
  finishIdCommandReply(id.c_str(), ok, code);
  reportExec(kind, id.c_str(), side, symbol, ok, code, detail);
}

void handleTradeQ(String input) {
  String id = getArgument(input, ',', 1);
  String side = getArgument(input, ',', 2); side.toUpperCase();
  String symbol = getArgument(input, ',', 3); symbol.toUpperCase();
  float usdMargin = getArgument(input, ',', 4).toFloat();
  int leverage = getArgument(input, ',', 5).toInt();
  String tp = getArgument(input, ',', 6);
  String sl = getArgument(input, ',', 7);
  String trailActivePrice = getArgument(input, ',', 8);
  float trailPct = getArgument(input, ',', 9).toFloat();

  if (id.length() == 0 || (side != "BUY" && side != "SELL") || symbol.length() == 0 || usdMargin <= 0.0f || leverage <= 0) {
    Serial.println("[ERROR] TRADEQ command malformed -- ignoring.");
    if (id.length() > 0) finishIdCommand("TRADE", id, side, symbol, false, "BAD", "malformed command");
    return;
  }
  if (haltGateBlocks("TRADE", id, side, symbol)) return; // see the HALTCACHE block -- checked before even trying
  String link = "ym-" + id; // unique per trade; also what makes a retried order safe (see submitOrderReliably)
  bool ok = executeOrderEx(side, symbol, usdMargin, leverage, tp, sl, link);
  char code[8];
  char detail[96];
  strncpy(code, g_execCode, sizeof(code)); code[sizeof(code) - 1] = '\0';
  strncpy(detail, g_execDetail, sizeof(detail)); detail[sizeof(detail) - 1] = '\0';

  if (ok && trailPct > 0.0f && !g_lastOrderWasPaper) {
    String expectedBybitSide = (side == "BUY") ? "Buy" : "Sell";
    Serial.println("[TRADE] Confirming the position is live before setting the trailing stop...");
    bool trailed = false;
    if (waitForPositionToRegister(symbol, expectedBybitSide)) {
      trailed = setTrailingStopEx(symbol, trailActivePrice, trailPct);
      if (!trailed) { snprintf(detail, sizeof(detail), "trailing stop refused: %s", g_execDetail); }
    } else {
      snprintf(detail, sizeof(detail), "position not confirmed in time; trailing stop not set");
    }
    if (!trailed) strncpy(code, "NOTRL", sizeof(code));
  }
  finishIdCommand("TRADE", id, side, symbol, ok, code, detail);
}

void handleSltpQ(String input) {
  String id = getArgument(input, ',', 1);
  String side = getArgument(input, ',', 2); side.toUpperCase();
  String symbol = getArgument(input, ',', 3); symbol.toUpperCase();
  String sl = getArgument(input, ',', 4);
  String tp = getArgument(input, ',', 5);
  if (id.length() == 0 || (side != "BUY" && side != "SELL") || symbol.length() == 0 || (sl.length() == 0 && tp.length() == 0)) {
    Serial.println("[ERROR] SLTPQ command malformed -- ignoring.");
    if (id.length() > 0) finishIdCommand("SLTP", id, side, symbol, false, "BAD", "malformed command");
    return;
  }
  if (haltGateBlocks("SLTP", id, side, symbol)) return; // see the HALTCACHE block -- matches the backend's own /api/trading-stop gate
  String expectedBybitSide = (side == "BUY") ? "Buy" : "Sell";
  String heldSide, heldSize;
  int held = checkHeldPosition(symbol, heldSide, heldSize);
  bool ok = false;
  if (held == -1) execSet("NET", "could not read the open positions");
  else if (held == 0) execSet("NOPOS", "no open position on " + symbol + " to update");
  else if (heldSide != expectedBybitSide) execSet("SIDE", "open position is " + heldSide + ", not " + expectedBybitSide + " -- left alone");
  else ok = updateTpSlEx(symbol, tp, sl);
  finishIdCommand("SLTP", id, side, symbol, ok, g_execCode, g_execDetail);
}

void handleCloseQ(String input) {
  String id = getArgument(input, ',', 1);
  String side = getArgument(input, ',', 2); side.toUpperCase();
  String symbol = getArgument(input, ',', 3); symbol.toUpperCase();
  if (id.length() == 0 || (side != "BUY" && side != "SELL" && side != "ANY") || symbol.length() == 0) { // ANY: the bots' Manual Trade page names only the pair
    Serial.println("[ERROR] CLOSEQ command malformed -- ignoring.");
    if (id.length() > 0) finishIdCommand("CLOSE", id, side, symbol, false, "BAD", "malformed command");
    return;
  }
  if (haltGateBlocks("CLOSE", id, side, symbol)) return; // see the HALTCACHE block -- matches the backend's own /api/order gate (a close is also an order)
  String expectedBybitSide = (side == "BUY") ? "Buy" : ((side == "SELL") ? "Sell" : ""); // "" = close whichever side is open (closePositionEx already treats "" that way)
  bool ok = closePositionEx(symbol, expectedBybitSide, "ymc-" + id);
  finishIdCommand("CLOSE", id, side, symbol, ok, g_execCode, g_execDetail);
}

void printHelp() {
  Serial.println("\n===================== BYBIT RELAY TEST COMMANDS =====================");
  Serial.println("BALANCE                                      -- show USDT balance");
  Serial.println("POS  (or POSITIONS)                          -- list open positions");
  Serial.println("PRICE,<symbol>                                -- show live price");
  Serial.println("INSTRUMENT,<symbol>                           -- show qtyStep/minOrderQty");
  Serial.println("LEV,<symbol>,<leverage>                       -- set leverage only");
  Serial.println("BUY,<symbol>,<usdMargin>,<leverage>,<tp>,<sl> -- open LONG  (tp/sl optional, leave blank to skip)");
  Serial.println("SELL,<symbol>,<usdMargin>,<leverage>,<tp>,<sl>-- open SHORT (tp/sl optional, leave blank to skip)");
  Serial.println("WAKE                                          -- ping the server (use this first if it's been idle -- Render free tier sleeps and can take 30-60s to wake)");
  Serial.println("TRADE,<BUY|SELL>,<symbol>,<usdMargin>,<leverage>,<tp>,<sl>,<trailActivePrice>,<trailPct>");
  Serial.println("                                               -- open + apply trailing stop in one shot (this is what the oracle fleet sends over ESP-NOW; trail args optional)");
  Serial.println("HEARTBEAT,<bot name>                          -- forwards an alive-signal to the backend (the oracle fleet sends this automatically every 60s; not usually typed by hand)");
  Serial.println("TPSL,<symbol>,<tp>,<sl>                       -- update TP/SL on an open position (blank = leave unchanged)");
  Serial.println("TRAIL,<symbol>,<activePrice>,<trailPct>       -- set trailing stop (activePrice may be blank = activate now)");
  Serial.println("CLOSE,<symbol>                                -- close the open position on this symbol");
  Serial.println("HELP                                          -- show this list");
  Serial.println("-----------------------------------------------------------------------");
  Serial.println("Examples:");
  Serial.println("  BUY,BTCUSDT,10,5,70000,60000     -> long BTC, $10 margin, 5x, TP 70000, SL 60000");
  Serial.println("  SELL,ETHUSDT,15,10,,              -> short ETH, $15 margin, 10x, no TP/SL");
  Serial.println("  TRAIL,BTCUSDT,68000,1.5           -> trail starts at $68000, trails 1.5% behind peak");
  Serial.println("  CLOSE,BTCUSDT                     -> close the open BTCUSDT position");
  Serial.println("=========================================================================\n");
}

// --- Central Command Processor ---
void processCommandString(String input) {
  input.trim();
  if (input.length() == 0) return;

  String action = getArgument(input, ',', 0);
  action.toUpperCase();

  if (action == "HELP") {
    printHelp();

  } else if (action == "WAKE") {
    Serial.println("[WAKE] Pinging server -- may take up to 60s if it's been asleep...");
    unsigned long start = millis();
    String res = sendGetRequest("/");
    unsigned long elapsed = millis() - start;
    if (res.length() > 0) Serial.printf("[WAKE] Server responded in %lu ms: %s\n", elapsed, res.c_str());
    else Serial.printf("[WAKE] No response after %lu ms.\n", elapsed);

  } else if (action == "BALANCE") {
    float bal = getAccountBalance();
    if (bal >= 0) {
      Serial.printf("[ACCOUNT] Available to trade: $%.2f USDT", bal);
      if (g_lastEquity >= 0) Serial.printf("  (total equity $%.2f)", g_lastEquity);
      Serial.println();
    } else Serial.println("[ERROR] Could not fetch balance.");

  } else if (action == "POS" || action == "POSITIONS") {
    fetchAndPrintPositions();

  } else if (action == "PRICE") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    float price = getLivePrice(symbol);
    if (price >= 0) Serial.printf("[PRICE] %s = $%.6f\n", symbol.c_str(), price);
    else Serial.println("[ERROR] Could not fetch price.");

  } else if (action == "INSTRUMENT") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    float qtyStep, minQty;
    if (getInstrumentInfo(symbol, qtyStep, minQty)) {
      Serial.printf("[INSTRUMENT] %s | qtyStep=%f | minOrderQty=%f\n", symbol.c_str(), qtyStep, minQty);
    } else {
      Serial.println("[ERROR] Could not fetch instrument info.");
    }

  } else if (action == "LEV") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    int leverage = getArgument(input, ',', 2).toInt();
    if (leverage <= 0) { Serial.println("[ERROR] Invalid leverage."); return; }
    bool ok = setSymbolLeverage(symbol, leverage);
    Serial.println(ok ? "[OK] Leverage set." : "[ERROR] Leverage update failed.");

  } else if (action == "BUY" || action == "SELL") {
    String symbol   = getArgument(input, ',', 1); symbol.toUpperCase();
    float usdMargin = getArgument(input, ',', 2).toFloat();
    int leverage    = getArgument(input, ',', 3).toInt();
    String tp       = getArgument(input, ',', 4);
    String sl       = getArgument(input, ',', 5);
    if (usdMargin <= 0.0 || leverage <= 0) { Serial.println("[ERROR] Invalid USD margin or leverage."); return; }
    bool okBuy = executeOrderEx(action, symbol, usdMargin, leverage, tp, sl, "ymL" + String(millis())); // typed commands carry no id, so one is made up
    Serial.println(okBuy ? "[OK] Order placed (" + String(g_execCode) + ")." : "[FAILED] " + String(g_execCode) + ": " + String(g_execDetail));

  } else if (action == "HEARTBEAT") {
    // REAL FEATURE ADDED at the user's explicit request: an oracle
    // bot's "I'm alive" signal, arriving over ESP-NOW the same way a
    // TRADE command does, forwarded straight to the backend. Silent on
    // success -- printing a line every 60s per bot would flood Serial
    // for no real benefit; a forwarding failure still isn't worth its
    // own log line here, same reasoning as forwardHeartbeat() itself.
    String botName = input.substring(10); // everything after "HEARTBEAT," -- bot names can contain commas' neighbor, a space, so this isn't parsed as a comma-separated arg like other commands
    forwardHeartbeat(botName);

  } else if (action == "PONG") {
    // REAL FEATURE ADDED at the user's explicit request: a reply to an
    // active ping round. Ignored outright if no round is active (a
    // stray or very late PONG after this device already reported that
    // bot as timed out) or if this bot already replied once this round
    // -- a duplicate ESP-NOW delivery shouldn't report the same result
    // twice.
    String botName = input.substring(5); // everything after "PONG,"
    // A PONG that ARRIVED before this round started is a leftover from an
    // earlier round (it sat in the queue): ignore it, or its arrival time
    // would predate the round and wrap around to a nonsense huge number.
    if (pingRoundActive && (long)(currentMessageRxMs - pingRoundStartMs) < 0) {
      Serial.println("[PING]   Got a PONG from '" + botName + "' that arrived before this round started -- stale, ignoring.");
    } else if (pingRoundActive) {
      bool matched = false;
      for (int i = 0; i < ORACLE_COUNT; i++) {
        if (String(PING_BOT_NAMES[i]) == botName && !pingReplied[i]) {
          pingReplied[i] = true;
          // From when the reply ARRIVED, not from when this loop got to it --
          // a loop blocked on another message's HTTPS call would otherwise
          // inflate every ping time it was holding.
          unsigned long elapsed = currentMessageRxMs - pingRoundStartMs;
          Serial.println("[PING]   " + botName + " replied in " + String(elapsed) + "ms");
          reportPingResult(currentPingId, botName, elapsed, false);
          matched = true;
          break;
        }
      }
      if (!matched) Serial.println("[PING]   Got a PONG from '" + botName + "' but that name doesn't match any bot in this round (or it already replied) -- ignoring.");
    } else {
      Serial.println("[PING]   Got a PONG from '" + botName + "' but no ping round is active -- ignoring (likely a late reply after timeout).");
    }

  } else if (action == "TRADEQ") {
    handleTradeQ(input);

  } else if (action == "SLTPQ") {
    handleSltpQ(input);

  } else if (action == "CLOSEQ") {
    handleCloseQ(input);

  } else if (action == "TRADE") {
    // REAL FEATURE ADDED at the user's explicit request: the single
    // command an oracle bot sends over ESP-NOW to open a position AND
    // apply its initial trailing stop in one shot -- reuses executeOrder()
    // and setTrailingStop() exactly as the manually-typed BUY/SELL/TRAIL
    // commands already do, just chained together. trailActivePrice and
    // trailPct are optional (blank trailPct or trailPct<=0 skips the
    // trailing-stop step entirely -- not every relayed trade needs one).
    String side        = getArgument(input, ',', 1); side.toUpperCase(); // BUY or SELL
    String symbol       = getArgument(input, ',', 2); symbol.toUpperCase();
    float usdMargin     = getArgument(input, ',', 3).toFloat();
    int leverage        = getArgument(input, ',', 4).toInt();
    String tp           = getArgument(input, ',', 5);
    String sl            = getArgument(input, ',', 6);
    String trailActivePrice = getArgument(input, ',', 7);
    float trailPct      = getArgument(input, ',', 8).toFloat();

    if ((side != "BUY" && side != "SELL") || usdMargin <= 0.0 || leverage <= 0) {
      Serial.println("[ERROR] TRADE command malformed -- side/usdMargin/leverage invalid.");
      return;
    }
    // Legacy fire-and-forget form (older bots, or typed by hand): same execution as TRADEQ, but no id and no
    // reply to the sender. It now only goes on to the trailing stop if the order was really accepted -- it
    // used to poll for a position that was never attempted and then print a misleading error.
    bool okTrade = executeOrderEx(side, symbol, usdMargin, leverage, tp, sl, "ymL" + String(millis()));
    if (!okTrade) {
      Serial.println("[FAILED] " + String(g_execCode) + ": " + String(g_execDetail));
    } else if (trailPct > 0 && !g_lastOrderWasPaper) {
      String expectedBybitSide = (side == "BUY") ? "Buy" : "Sell";
      Serial.println("[TRADE] Confirming position is live before setting trailing stop...");
      if (waitForPositionToRegister(symbol, expectedBybitSide)) {
        if (!setTrailingStopEx(symbol, trailActivePrice, trailPct)) Serial.println("[ERROR] Trailing stop not set: " + String(g_execDetail));
      } else {
        Serial.printf("[ERROR] %s position never confirmed after %d attempts -- trailing stop NOT set. The order itself may still have gone through with its TP/SL; check POS manually.\n",
                      symbol.c_str(), POSITION_POLL_MAX_ATTEMPTS);
      }
    }

  } else if (action == "TPSL") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    String tp = getArgument(input, ',', 2);
    String sl = getArgument(input, ',', 3);
    bool okTpsl = updateTpSlEx(symbol, tp, sl);
    Serial.println(okTpsl ? "[OK] Updated." : "[FAILED] " + String(g_execCode) + ": " + String(g_execDetail));

  } else if (action == "TRAIL") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    String activePrice = getArgument(input, ',', 2);
    float trailPct = getArgument(input, ',', 3).toFloat();
    bool okTrail = setTrailingStopEx(symbol, activePrice, trailPct);
    Serial.println(okTrail ? "[OK] Trailing stop set." : "[FAILED] " + String(g_execCode) + ": " + String(g_execDetail));

  } else if (action == "CLOSE") {
    String symbol = getArgument(input, ',', 1); symbol.toUpperCase();
    bool okClose = closePositionEx(symbol, "", "ymL" + String(millis()));
    Serial.println(okClose ? "[OK] " + String(g_execCode) + ": " + String(g_execDetail) : "[FAILED] " + String(g_execCode) + ": " + String(g_execDetail));

  } else {
    Serial.println("[ERROR] Unrecognized command. Type HELP for the full list.");
  }
}

// ===== MGRNET: fixed address + Wi-Fi recovery =====
// The manager is always reachable at http://ymmanager.local/ (the bots do the same with tradescanner.local ... tradescanner4.local),
// so nobody has to hunt for its IP. If the Wi-Fi drops, the loop keeps trying to rejoin every 20 s. It deliberately never restarts
// the board: commands waiting for an answer live in RAM, and a reboot could lose one mid-flight.
const char* MANAGER_MDNS_NAME = "ymmanager";
const unsigned long MANAGER_WIFI_RETRY_MS = 20000UL;
unsigned long managerWifiDownSinceMs = 0, managerWifiLastTryMs = 0;
bool managerWifiWasDown = false;
unsigned long managerWifiDropCount = 0;
void managerMdnsStart() {
  MDNS.end();
  if (MDNS.begin(MANAGER_MDNS_NAME)) {
    MDNS.addService("http", "tcp", 80);
    Serial.println("[MANAGER UI] Fixed address: http://" + String(MANAGER_MDNS_NAME) + ".local/");
  } else {
    Serial.println("[MANAGER UI] mDNS name not available -- use the IP address shown above.");
  }
}
void managerWifiWatch() {
  if (WiFi.status() == WL_CONNECTED) {
    if (managerWifiWasDown) {
      managerWifiWasDown = false;
      Serial.println("[WIFI] Back online after " + String((millis() - managerWifiDownSinceMs) / 1000UL) + "s (drop #" + String(managerWifiDropCount) + "), IP " + WiFi.localIP().toString());
      managerMdnsStart(); // the name has to be announced again on the new connection
    }
    return;
  }
  unsigned long now = millis();
  if (!managerWifiWasDown) { managerWifiWasDown = true; managerWifiDownSinceMs = now; managerWifiLastTryMs = now; managerWifiDropCount++; Serial.println("[WIFI] Connection lost -- will keep trying to rejoin (no restart)."); return; }
  if (now - managerWifiLastTryMs >= MANAGER_WIFI_RETRY_MS) {
    managerWifiLastTryMs = now;
    Serial.println("[WIFI] Still down (" + String((now - managerWifiDownSinceMs) / 1000UL) + "s) -- re-joining.");
    WiFi.disconnect();
    WiFi.begin(ssid, password);
  }
}
// ===== MGRNET-END =====

// mgr-2: the numbers that say WHY the manager is failing, shown on its own page (no network call, plain arithmetic on values already in memory).
String managerLastSelfRestartNote = "";
String managerBootReason = "";
String managerHealthHtml() {
  unsigned long nowMs = millis();
  String h = "<div class='card'><p style='font-size:11px;color:var(--mist);margin:0 0 4px;'>Health (for finding out why it fails)</p>";
  auto row = [&](const String& k, const String& v, bool bad) { h += "<div class='row'><div>" + k + "</div><div style='color:" + String(bad ? "var(--short)" : "var(--paper)") + ";'>" + v + "</div></div>"; };
  unsigned long up = nowMs / 1000UL;
  row("Up for", String(up / 3600UL) + "h " + String((up % 3600UL) / 60UL) + "m", false);
  row("Last start", execHtmlEscape(managerBootReason), managerBootReason.indexOf("CRASH") >= 0 || managerBootReason.indexOf("watchdog") >= 0 || managerBootReason.indexOf("BROWNOUT") >= 0);
  if (managerLastSelfRestartNote.length()) row("Self-restart note", execHtmlEscape(managerLastSelfRestartNote), true);
  uint32_t freeHeap = ESP.getFreeHeap(), minHeap = ESP.getMinFreeHeap(), maxBlock = ESP.getMaxAllocHeap();
  row("Free memory now / lowest ever", String(freeHeap / 1024) + " / " + String(minHeap / 1024) + " KB", minHeap < 30000UL);
  row("Largest free block", String(maxBlock / 1024) + " KB" + String(maxBlock < 45000UL ? " (low: secure connections need ~45)" : ""), maxBlock < 45000UL);
  row("Task stack left (lowest)", String((unsigned long)uxTaskGetStackHighWaterMark(NULL)) + " bytes", uxTaskGetStackHighWaterMark(NULL) < 1500);
  String ago = backendEverOk ? String((nowMs - backendLastOkMs) / 1000UL) + " s ago" : String("never since start");
  row("Backend last answered", ago, backendEverOk ? (nowMs - backendLastOkMs) > 300000UL : true);
  row("Backend calls / failed / failing in a row", String(backendCalls) + " / " + String(backendFailTotal) + " / " + String(backendFailStreak), backendFailStreak >= 3);
  row("Longest freeze of the main loop", String(loopLongestGapMs / 1000UL) + " s (" + String(loopStallsOver30s) + " over 30 s)", loopLongestGapMs > 90000UL);
  row("Wi-Fi", String(WiFi.status() == WL_CONNECTED ? "connected, signal " + String(WiFi.RSSI()) + " dBm" : String("DOWN")) + ", " + String(managerWifiDropCount) + " drop(s)", WiFi.status() != WL_CONNECTED || WiFi.RSSI() < -80);
  row("Alive-signals from bots: got / sent on / failed / replaced", String(hbReceived) + " / " + String(hbForwarded) + " / " + String(hbFailed) + " / " + String(hbCoalesced) + " (" + String(hbStale) + " too old)", hbFailed > hbForwarded);
  row("Messages lost: radio queue full / reply queue full", String((unsigned long)espNowDroppedCount) + " / " + String((unsigned long)espNowTxDropped), espNowDroppedCount > 0 || espNowTxDropped > 0);
  h += "</div>";
  return h;
}

// Idle-only self-restart (see healthRestartReason()). Never while a message is queued, a ping round is running, or a command finished in the last 2 minutes.
void managerHealthTick() {
  unsigned long nowMs = millis();
  bool idle = (espNowQueueTail == espNowQueueHead) && !pingRoundActive && (lastCommandMs == 0 || (unsigned long)(nowMs - lastCommandMs) > 120000UL) && hbPendingCount() == 0;
  int why = healthRestartReason(nowMs, idle, WiFi.status() == WL_CONNECTED, ESP.getMaxAllocHeap(), backendFailStreak);
  if (why == 0) return;
  char note[120];
  snprintf(note, sizeof(note), "%s | up %lus | largest block %uB | backend failing in a row %u", why == 1 ? "memory too fragmented for a secure connection" : "backend calls failing while memory is fragmented", nowMs / 1000UL, (unsigned)ESP.getMaxAllocHeap(), (unsigned)backendFailStreak);
  Serial.printf("[HEALTH] Restarting: %s\n", note);
  File f = LittleFS.open("/selfrestart.txt", FILE_WRITE);
  if (f) { f.print(note); f.close(); }
  delay(200);
  ESP.restart();
}
void loadSelfRestartNote() {
  if (LittleFS.exists("/selfrestart.txt")) {
    File f = LittleFS.open("/selfrestart.txt", FILE_READ);
    if (f) { managerLastSelfRestartNote = f.readStringUntil('\n'); f.close(); }
    LittleFS.remove("/selfrestart.txt");
  }
}

void setup() {
  Serial.begin(115200);
  delay(500);

  LittleFS.begin(true); // see the HALTCACHE block -- the manager's first-ever use of persistent storage
  loadHaltCacheFromFlash();
  managerBootReason = resetReasonName((int)esp_reset_reason());   // mgr-2
  loadSelfRestartNote();
  Serial.println("[BOOT] Last start: " + managerBootReason + (managerLastSelfRestartNote.length() ? " | previous self-restart: " + managerLastSelfRestartNote : String("")));

  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);          // modem power-save makes a plugged-in relay miss ESP-NOW frames and answer web requests late
  WiFi.setAutoReconnect(true);
  WiFi.persistent(false);
  WiFi.begin(ssid, password);

  Serial.print("[WIFI] Connecting");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n[WIFI] Connected! IP: " + WiFi.localIP().toString());

  // REAL BUG FOUND while adding the manager's own status page: this device never synced its clock. time(nullptr)
  // would have kept returning a near-zero, meaningless value forever, breaking "ago" timestamps on that page (and
  // any future use of the clock here). Same fix the bots already use for the same reason -- wait up to 10s and
  // report the real outcome either way, since a silent failure here would be a silent failure everywhere else too.
  configTime(0, 0, "pool.ntp.org", "time.nist.gov");
  {
    int ntpAttempts = 0;
    while (time(nullptr) < 1000000000 && ntpAttempts < 20) { delay(500); ntpAttempts++; }
    if (time(nullptr) > 1000000000) Serial.println("[NTP] Time synced OK.");
    else Serial.println("[NTP] FAILED to sync after 10s -- timestamps on the manager's own status page will be wrong until this device's clock is valid.");
  }

  // ESP-NOW init happens AFTER WiFi connects, deliberately -- ESP-NOW
  // rides on whatever channel the WiFi station connection is currently
  // using, so it has to come after WiFi.begin() succeeds, not before.
  if (esp_now_init() == ESP_OK) {
    esp_now_register_recv_cb(onEspNowDataRecv);
    esp_now_register_send_cb(onEspNowDataSent);
    // Replies to the bots (ACK / RES) are sent by their own small task -- see the reliable-relay comment above.
    espNowTxQueue = xQueueCreate(8, sizeof(TxItem));
    xTaskCreatePinnedToCore(espNowTxTask, "espnowtx", 3072, NULL, 3, NULL, 0);
    // Known bots are registered up front so an ACK never has to wait for a peer to be added.
    for (int i = 0; i < ORACLE_COUNT; i++) ensureOraclePeerAdded(i);
    Serial.println("[ESP-NOW] Initialized -- listening for signals from the oracle fleet.");
  } else {
    Serial.println("[ESP-NOW] Initialization FAILED -- oracle bots will not be able to reach this device.");
  }
  Serial.print("[ESP-NOW] This device's MAC address (each oracle bot needs this as its peer): ");
  Serial.println(WiFi.macAddress());

  managerWeb.on("/", handleManagerHome);
  managerWeb.begin();
  managerMdnsStart();
  Serial.println("[MANAGER UI] Serving http://" + WiFi.localIP().toString() + "/");

  Serial.println("\n[TEST HARNESS] Ready. Talking to: " + String(renderServerUrl));
  Serial.println("[NOTE] If the server's been idle a while (Render free tier), send WAKE first and give it up to 60s before running a real command.");
  printHelp();
}

void loop() {
  loopNotePass(millis());   // mgr-2: measures the longest freeze of this loop
  managerWeb.handleClient();
  managerWifiWatch();

  if (Serial.available() > 0) {
    String input = Serial.readStringUntil('\n');
    Serial.println("\n[INPUT: Serial] " + input);
    currentMessageHasSrc = false; // typed at the keyboard: no bot to reply to
    processCommandString(input);
  }

  // Drain ONE queued message per loop pass (processing can block on HTTPS,
  // and the queue holds the rest safely in the meantime).
  if (espNowQueueTail != espNowQueueHead) {
    String input;
    portENTER_CRITICAL(&espNowQueueMux);
    // Anything that moves money or a live position goes ahead of housekeeping (heartbeats, pongs): a
    // heartbeat forward is a slow HTTPS call and must never make a trade wait behind it. Order among
    // the trade-related messages themselves stays first-come-first-served.
    uint8_t pick = espNowQueueTail;
    for (uint8_t i = espNowQueueTail; i != espNowQueueHead; i = (i + 1) % ESPNOW_QUEUE_SIZE) {
      if (isTradeRelatedText(espNowQueue[i].command)) { pick = i; break; }
    }
    if (pick != espNowQueueTail) {
      struct_message tmpMsg;
      unsigned long tmpRx;
      uint8_t tmpSrc[6];
      memcpy(&tmpMsg, &espNowQueue[pick], sizeof(struct_message));
      tmpRx = espNowQueueRxMs[pick];
      memcpy(tmpSrc, espNowQueueSrc[pick], 6);
      memcpy(&espNowQueue[pick], &espNowQueue[espNowQueueTail], sizeof(struct_message));
      espNowQueueRxMs[pick] = espNowQueueRxMs[espNowQueueTail];
      memcpy(espNowQueueSrc[pick], espNowQueueSrc[espNowQueueTail], 6);
      memcpy(&espNowQueue[espNowQueueTail], &tmpMsg, sizeof(struct_message));
      espNowQueueRxMs[espNowQueueTail] = tmpRx;
      memcpy(espNowQueueSrc[espNowQueueTail], tmpSrc, 6);
    }
    input = String(espNowQueue[espNowQueueTail].command);
    currentMessageRxMs = espNowQueueRxMs[espNowQueueTail];
    memcpy(currentMessageSrc, espNowQueueSrc[espNowQueueTail], 6);
    currentMessageHasSrc = true;
    espNowQueueTail = (espNowQueueTail + 1) % ESPNOW_QUEUE_SIZE;
    portEXIT_CRITICAL(&espNowQueueMux);
    Serial.println("\n[INPUT: ESP-NOW] " + input);
    processCommandString(input);
    lastCommandMs = millis();
  }
  if (espNowDroppedCount != espNowDroppedReported) {
    espNowDroppedReported = espNowDroppedCount;
    Serial.println("[ESP-NOW] WARNING: receive queue was full -- " + String(espNowDroppedCount) + " message(s) dropped so far.");
  }

  // SYNC-17: unknown senders (see MGR_SENDER_CHECK): print at most once every 30 s
  static uint32_t unknownReported = 0; static unsigned long unknownPrintMs = 0;
  if (mgrUnknownSenders != unknownReported && (unknownPrintMs == 0 || millis() - unknownPrintMs > 30000UL)) {
    unknownReported = mgrUnknownSenders; unknownPrintMs = millis() ? millis() : 1;
    Serial.println("[SENDER CHECK] " + String((unsigned long)mgrUnknownSenders) + " frame(s) from a MAC that is not one of the four bots; last: " + macToString(mgrLastUnknownMac) +
#if MGR_SENDER_CHECK >= 2
                   " -- DROPPED. If this is one of YOUR bots (board replaced?), put its MAC in oracleMacs[].");
#else
                   " -- log-only mode, nothing dropped. If this is one of YOUR bots, fix its row in oracleMacs[] before switching MGR_SENDER_CHECK to 2.");
#endif
  }

  // mgr-2: one alive-signal per pass, only when no trade / stop update is waiting and the backend is not in its back-off
  if (espNowQueueTail == espNowQueueHead && backendHousekeepingDue(millis())) {
    char hbName[24];
    if (hbTake(hbName, sizeof(hbName), millis())) forwardHeartbeat(String(hbName));
  }

  pollForPingRequest();
  checkPingRoundTimeout();
  managerHealthTick();
  delay(2);   // lets the Wi-Fi / radio tasks and the web page breathe instead of spinning flat out
}
