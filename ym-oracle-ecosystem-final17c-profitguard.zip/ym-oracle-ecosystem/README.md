# YM Oracle ecosystem - build final-17c (final-17b-sync + Profit Guard)

## What final-17c adds (on top of final-17b-sync, nothing removed)
**Profit Guard** from v2.7.2, ported onto this build and extended with a smart layer. **Server only: no firmware change, no reflash.** Everything is **OFF by default**. Full guide: `PROFIT-GUARD.md`.

| Where | Change | Switch / undo |
|---|---|---|
| Server | `relay/profitguard.js` (decision logic) + the Profit Guard loop in `multiuser.js`: watches the master's open trades every ~5 s and only ever RAISES a stop toward profit, on Bybit, for the master and the copy users. Shadow (records only) or Live, separately for fast and swing trades. | Admin console -> Plan & risk -> Profit Guard -> Off |
| Server | The stop clamp: a looser stop (or a stop removal) arriving from a bot is held at the guard's floor. Hooked into BOTH stop routes of this build: `/api/trading-stop` (manager route) and `tradeexec.js` `execSltp` (web route). The v2.7.2 build only had the first. | Guard off = clamp does nothing |
| Server | Smart layer: **breathing room** (a stop is not raised into the trade's own largest pullback), **stall tightening** (+10 points kept per quiet period, max +20), **self-tuning** of the keep shares from the scorecard (Suggest only by default; Auto needs a confirm). Each part has its own switch. | Admin card -> Smart mode |
| Server | New tables `profit_guard_log` and `pg_trades` (additive; nothing existing is altered). | - |

Not taken from v2.7.2 on purpose: its older `server.js` / `admin.html` (this build's fixes stay), and `guardFitClose` (`tradeexec.js` already sizes a close from the real position on Bybit).

Tests: `profitguard.test.js` 20 checks, `integration.test.js` 111 (needs Postgres on 54329), `tradeexec.test.js` 24, `server.test.js` 31, `pages.test.js`, `espnow.test.js` 22, `pipeline.test.js` 23: all pass. **Not run: a real Bybit demo trade.** Run it in Shadow, then on a demo account, before Live.

## What final-17-sync adds (on top of the manager-route build, nothing removed)
| Where | Change | Switch / undo |
|---|---|---|
| Bots (x4) | Send the small ESP-NOW heartbeat to the manager again, next to the full heartbeat to the server. The manager's fleet board and watchdog see every bot; the server keeps the richer data (uptime, memory, reset reason, relay switches). | Delete the `sendHeartbeatToManager();` line in the heartbeat loop |
| Bots (x4) | ACK / RES / PING are accepted only from the manager's MAC. Anyone else in radio range is ignored and counted (`relayRxForeign`). | `#define BOT_ONLY_MANAGER_REPLIES 0` |
| Bots (x4) | A command the manager has not ACKed after 30 s raises ONE private Telegram alert ("MANAGER NOT ANSWERING"), at most once per 5 min. The command keeps being resent as before. | `RELAY_SLOW_ACK_MS` |
| Bots (x4) | A failed MANUAL open no longer flags its pair, so the bot keeps mirroring stops/closes for its own trade on that pair. Manual opens carry an id starting with `M`. Automatic trades are unchanged. | - |
| Bots (x4) | A MANUAL open the manager never ACKed is dropped after 90 s instead of being retried for up to 10 min. Automatic orders still retry for 10 min. | `RELAY_MANUAL_GIVE_UP_MS` |
| Bots (x4) | Alert and log wording says "manager" on the manager route (it said "web server"). | - |
| Manager | Checks every frame's sender against the four bot MACs in `oracleMacs[]`. **Ships in log-only mode** (`MGR_SENDER_CHECK 1`): unknown senders are counted, printed as `[SENDER CHECK]` and shown on the status page, nothing is dropped. | `MGR_SENDER_CHECK 2` = enforce, `0` = off |
| Server | The manager owns each fleet-ping round while it polls `/api/ping-check` (45 s window); the bots only answer when the manager is gone. A late timeout never overwrites a real answer. | - |
| Server | `TRACK_MANAGER` now defaults to ON (the manager is in the trade path again), so a quiet manager raises the offline alert. | `TRACK_MANAGER=false` |

### final-17b: less traffic from the bots to the server
- The 15 s `/api/bot-poll` and the HTTPS ping answer are switched off in all four bots (`#define BOT_POLL_ENABLED 0`). Proof of life now comes from the 3-minute heartbeat (server) plus the ESP-NOW heartbeat the manager forwards; the manager's own 10 s check-in keeps the server awake and runs the fleet ping.
- The heartbeat keeps its 30 s retry. Its timeouts are now 2.5 s connect + 3.5 s read (6 s at most holding the shared network lock, always under the scan's 8 s wait).
- **Ping fleet on the web UI still works, through the manager only.** If the manager is off, the dashboard shows timeouts for all four bots. Set `BOT_POLL_ENABLED 1` and reflash to get the HTTPS fallback back.

### Admin page fix (final-17b)
`/admin` loaded but did nothing because one string in its script contained an unescaped apostrophe, which stops the whole script from running. That text was added with the "ping fleet" panel in the web-route build, before the sync work. Fixed, and `node tests/pages.test.js` now checks that every page script parses.

### Do this before switching the sender check to enforce (`MGR_SENDER_CHECK 2`)
1. Flash the manager and all four bots, let them run for a few minutes.
2. Open the manager page / Serial: no `[SENDER CHECK]` line and no red "Sender check" card means all four MACs in `oracleMacs[]` are right.
3. **MACs:** rows II, III and IV of `oracleMacs[]` are confirmed correct (bot IV is `14:C1:9F:3B:D8:D4`; the old comment naming another MAC was stale and is fixed). Row I (`24:58:7C:91:A0:3C`) is not yet confirmed: read it from bot I's Serial first.
4. Then set `MGR_SENDER_CHECK 2` and reflash the manager only.

### Deploy order
Server first (`relay/`), then the manager, then the four bots one at a time. Any mix of old and new firmware keeps working: the new server and manager accept the old frames, and an old bot simply does not send the extra heartbeat.

### Not changed (still open)
- ESP-NOW is still unencrypted; the sender check is a filter, not authentication.
- The bots' Gmail app passwords, Telegram tokens and the device key sit in the sketches in plain text. Rotate them if any zip has been shared.

### Tests run for this build
- `node tests/espnow.test.js` (21 checks), `node tests/pipeline.test.js` (23), `node relay/tests/tradeexec.test.js` (23): pass.
- `relay/tests/server.test.js` has a new ping-ownership check but needs `npm install` (no network here), so it was syntax-checked only.
- None of the firmware was compiled for an ESP32 or run on hardware: compile one bot and the manager in the Arduino IDE first.

---

# YM Oracle ecosystem

## CURRENT SETUP: rolled back to the manager route for trades
Every bot has `#define RELAY_VIA_HTTPS 0` (line ~295 region further down, next to `RELAY_MANAGER_FALLBACK`). Trades, stop/target updates, closes AND the Manual Trade page now go:

    bot --ESP-NOW--> manager ESP32 --HTTPS--> relay server --Bybit--> exchange
         (same ids, ACK/RES, resends as before)

- The bot no longer opens an HTTPS connection for a trade, so a trade the server has not answered can no longer hold the shared network lock and starve the scan engine's candle fetches.
- Heartbeat, 15 s poll, ping answers and web-ledger reports still go from the bot straight to the server (small calls, unchanged).
- The manager now accepts a close that names only the pair (`CLOSEQ,<id>,ANY,<symbol>`), which is what the Manual Trade page sends. It closes whichever side is open. **Reflash the manager.**
- The manager has the device key in `deviceKey` too. Reflash it before setting `DEVICE_KEY_MODE=enforce`.
- Set `TRACK_MANAGER=true` on the server so it alerts when the manager goes quiet (it posts its own heartbeat).
- To go back to the one-POST web route: set `RELAY_VIA_HTTPS 1` in the bots and reflash. `/api/trade` and `tradeexec.js` stay on the server either way.
- `node tests/espnow.test.js` checks the manager route on the shipped code (11 checks).

(Everything below describes the web route that `RELAY_VIA_HTTPS 1` switches on.)

    bot (x4)  --HTTPS-->  relay server  --Bybit-->  exchange
       |  POST /api/trade       trades, stop updates, closes (answer comes back in the same reply)
       |  POST /api/heartbeat   every 3 min: alive + uptime, memory, last restart reason, build, relay switches
       |  GET  /api/bot-poll    every ~15 s: proof of life + "is a fleet ping waiting for me?"
       |  POST /api/ping-result the bot's own round trip to the server, when a ping is waiting
       +--- the manager ESP32 is NOT in any of these paths (switched off for now; back later for the LCD and buzzer)

| Folder | What it is | Changed? |
|---|---|---|
| `relay/` | The server (Render). `tradeexec.js` + `POST /api/trade`, and now `GET /api/bot-poll` | yes |
| `fleet/oracle1_lf_final16` ... `oracle4_lf_final16` | The four bots. Everything goes to the server themselves | yes (`BUILD_TAG` is `final-16-direct`) |
| `manager/bybit_manager_fixed` | The manager ESP32. Not needed for trading, heartbeats or pings any more | **no** |
| `tests/` | End-to-end pipeline test (bot code -> server code -> bot verdict) | yes |

## What changed in this version
- **Manual Trade page** (open and close) now goes through the same queue real trades use: one HTTPS call to `/api/trade`, retried with the same id until the server answers. The page shows the latest relay result a few seconds after a click. A manual close names only the pair; the server closes whichever side is open (`side: ANY`, close only).
- **Heartbeat** goes from the bot to `/api/heartbeat` itself, with uptime, free memory, reset reason, build and relay switches. This is what feeds the "relay switch is now OFF" and "restarted by CRASH/WATCHDOG/BROWNOUT" alerts, which could not fire before (the manager forwarded only the name).
- **Ping fleet** (dashboard button): each bot picks the round up on its next poll (within ~15 s) and reports its own round trip to the server, TLS handshake included. It measures the path a trade really takes. A bot that did not answer is asked again on its next poll.
- **The 15 s poll also keeps the server awake** (the manager's old 10 s poll did that on a sleeping-prone host).
- **Manager fallback is off** (`RELAY_MANAGER_FALLBACK 0`). An unanswered web try is simply tried again with the same id (1.5 s, 3 s, 6 s, 16 s, then every 30 s) for up to 10 minutes, then a "no answer" alert.
- The server no longer watches `YM ORACLE MANAGER` for going quiet. Set `TRACK_MANAGER=true` on the server to bring that back.

## Deploy order
1. **Server first.** Deploy `relay/`. Set `TRADE_MODE=paper` for the first run. Old bots and the manager keep working (their routes are untouched).
2. **Device key.** Pick one secret. Set it as `DEVICE_API_KEY` on the server AND as `ORACLE_WEB_DEVICE_KEY` (near line 147) in all four bots. Only then set `DEVICE_KEY_MODE=enforce`. A bot with an empty key is refused (401) once enforced, and now that includes its heartbeat and poll.
3. **One bot first.** Flash `oracle1_lf_final16`. Serial should show `[BYBIT RELAY] ... order: done (PAPER)` for a trade, and no `[POLL]` or `[HEARTBEAT]` complaint. The dashboard should show the bot online within a minute, with its build `final-16-direct`.
4. Press "ping fleet" on the dashboard: bot I should answer; the other three show a timeout until flashed.
5. Then the Bybit demo account, then live (`TRADE_MODE=live`), then the other three bots.
6. **Only after all four bots are flashed, unplug the manager.** A bot still on the old firmware sends its heartbeat to the manager and would look offline without it.

## Undo
- Per bot: `#define RELAY_MANAGER_FALLBACK 1` brings the ESP-NOW safety net back. `#define RELAY_VIA_HTTPS 0` returns to the fully old behaviour for trades (ESP-NOW to the manager). The heartbeat and poll stay on the server in both cases; to send the heartbeat to the manager again, call `sendHeartbeatToManager()` in place of `sendHeartbeatToServer()` in the web task.

## Tests
- `node relay/tests/tradeexec.test.js` : 23 server-side execution checks (no packages needed).
- `node tests/pipeline.test.js` : 23 end-to-end checks (needs g++ and node, no packages). It compiles the RELAY-HTTPS block cut out of the shipped `.ino` files, including the new ping-reply, ping-answer and heartbeat helpers.
- `cd relay && npm install && RELAY_DIR=$PWD node tests/server.test.js` : 15 server checks, including the new `/api/bot-poll`. (Without `RELAY_DIR` the test looks in `/home/claude/relay`.)
- The ESP32 firmware itself is NOT compiled by these, and the on-device code (`botServerCall`, `botPollTick`, the Manual Trade handlers) has not been run on hardware. Compile one bot in the Arduino IDE and watch its serial output before flashing all four.
- `relay/tests/integration.test.js` needs a Postgres database, and the two `dashboard*.ui.test.js` files need `jsdom` laid out as they expect; neither was run for this change.
